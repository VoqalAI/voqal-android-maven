package ai.voqal.sdk.security

/**
 * Converts ECDSA signatures between the DER encoding the JCA `SHA256withECDSA` signer
 * produces and the fixed-width raw `R || S` (64 bytes for P-256) encoding JWT ES256
 * requires (RFC 7515 §3.4 / RFC 7518).
 *
 * DER form: `SEQUENCE { INTEGER r, INTEGER s }`, with each INTEGER minimally encoded and
 * sign-extended. Raw form: R and S each left-padded to exactly 32 bytes.
 */
internal object EcdsaSignature {

    private const val COORDINATE_BYTES = 32
    private const val RAW_LENGTH = COORDINATE_BYTES * 2
    private const val DER_SEQUENCE_TAG = 0x30
    private const val DER_INTEGER_TAG = 0x02

    /**
     * Convert a DER-encoded ECDSA signature to fixed-width raw `R || S` (64 bytes).
     *
     * @param der The DER signature from `Signature("SHA256withECDSA")`.
     * @return A 64-byte array: R left-padded to 32 bytes, then S left-padded to 32 bytes.
     * @throws IllegalArgumentException if the input is not a valid two-INTEGER DER sequence.
     */
    fun derToRaw(der: ByteArray): ByteArray {
        var offset = 0
        require(byteAt(der, offset++) == DER_SEQUENCE_TAG) { "DER signature missing SEQUENCE tag" }
        offset = skipLength(der, offset)

        require(byteAt(der, offset++) == DER_INTEGER_TAG) { "DER signature missing R INTEGER tag" }
        val rLength = byteAt(der, offset++)
        val r = der.copyOfRange(offset, offset + rLength)
        offset += rLength

        require(byteAt(der, offset++) == DER_INTEGER_TAG) { "DER signature missing S INTEGER tag" }
        val sLength = byteAt(der, offset++)
        val s = der.copyOfRange(offset, offset + sLength)

        val raw = ByteArray(RAW_LENGTH)
        copyRightAligned(stripLeadingZero(r), raw, 0)
        copyRightAligned(stripLeadingZero(s), raw, COORDINATE_BYTES)
        return raw
    }

    /**
     * Convert a fixed-width raw `R || S` signature back to DER. Used by verifiers (and tests)
     * to feed a JWT signature into the JCA `SHA256withECDSA` verifier.
     *
     * @param raw A 64-byte `R || S` signature.
     * @return The DER-encoded equivalent.
     * @throws IllegalArgumentException if [raw] is not 64 bytes.
     */
    fun rawToDer(raw: ByteArray): ByteArray {
        require(raw.size == RAW_LENGTH) { "Raw signature must be $RAW_LENGTH bytes, was ${raw.size}" }
        val r = toDerInteger(raw.copyOfRange(0, COORDINATE_BYTES))
        val s = toDerInteger(raw.copyOfRange(COORDINATE_BYTES, RAW_LENGTH))
        val body = r + s
        return byteArrayOf(DER_SEQUENCE_TAG.toByte(), body.size.toByte()) + body
    }

    private fun toDerInteger(coordinate: ByteArray): ByteArray {
        var value = stripLeadingZero(coordinate)
        if (value.isEmpty()) value = byteArrayOf(0)
        // DER INTEGERs are signed; prepend 0x00 when the high bit would imply negative.
        if (value[0].toInt() and 0x80 != 0) value = byteArrayOf(0) + value
        return byteArrayOf(DER_INTEGER_TAG.toByte(), value.size.toByte()) + value
    }

    private fun skipLength(der: ByteArray, offset: Int): Int {
        val first = byteAt(der, offset)
        // Short form (high bit clear) is a single length byte; we never emit long-form here.
        require(first and 0x80 == 0) { "Long-form DER length is unsupported for ECDSA signatures" }
        return offset + 1
    }

    private fun stripLeadingZero(value: ByteArray): ByteArray {
        var start = 0
        while (start < value.size - 1 && value[start].toInt() == 0) start++
        return value.copyOfRange(start, value.size)
    }

    private fun copyRightAligned(source: ByteArray, target: ByteArray, blockStart: Int) {
        require(source.size <= COORDINATE_BYTES) {
            "ECDSA coordinate is ${source.size} bytes, exceeds $COORDINATE_BYTES"
        }
        System.arraycopy(
            source, 0, target, blockStart + COORDINATE_BYTES - source.size, source.size
        )
    }

    private fun byteAt(der: ByteArray, index: Int): Int {
        require(index < der.size) { "Truncated DER signature at index $index" }
        return der[index].toInt() and 0xFF
    }
}
