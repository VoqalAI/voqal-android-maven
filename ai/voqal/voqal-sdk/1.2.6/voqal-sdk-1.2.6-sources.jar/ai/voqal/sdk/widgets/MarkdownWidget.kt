package ai.voqal.sdk.widgets

import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.theme.ResolvedTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val BULLET_PREFIX = "- "
private const val BULLET_GLYPH = "•"
private const val BOLD_DELIMITER = "**"
private val BODY_SIZE = 15.sp

/**
 * Renders a [Widget.Markdown] using a minimal, dependency-free subset: `**bold**` inline spans,
 * `- ` bullet lines, and plain paragraphs. Anything else is shown as literal text — the renderer
 * never executes or fetches remote content.
 *
 * Rendered bare (no card chrome) in the secondary text tier, matching the iOS `MarkdownWidgetView`
 * which is plain prose, not a surfaced card.
 */
@Composable
fun MarkdownWidget(widget: Widget.Markdown, theme: ResolvedTheme) {
    val lines = widget.text.split("\n")
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        lines.filter { it.isNotBlank() }.forEach { line ->
            MarkdownLine(line, theme)
        }
    }
}

@Composable
private fun MarkdownLine(line: String, theme: ResolvedTheme) {
    val isBullet = line.trimStart().startsWith(BULLET_PREFIX)
    if (!isBullet) {
        MarkdownText(parseInlineBold(line), theme)
        return
    }
    val content = line.trimStart().removePrefix(BULLET_PREFIX)
    Row {
        Text(text = BULLET_GLYPH, color = theme.textSecondary, fontSize = BODY_SIZE)
        Spacer(Modifier.width(8.dp))
        MarkdownText(parseInlineBold(content), theme)
    }
}

@Composable
private fun MarkdownText(annotated: AnnotatedString, theme: ResolvedTheme) {
    Text(
        text = annotated,
        color = theme.textSecondary,
        fontSize = BODY_SIZE,
        fontWeight = FontWeight.Normal,
        style = TextStyle(textDirection = composeDirectionOf(annotated.text)),
    )
}

/**
 * Convert a single line's `**bold**` spans into an [AnnotatedString]. Unpaired delimiters are
 * treated as literal text so malformed Markdown degrades gracefully rather than swallowing text.
 */
internal fun parseInlineBold(line: String): AnnotatedString = buildAnnotatedString {
    var cursor = 0
    while (cursor < line.length) {
        val open = line.indexOf(BOLD_DELIMITER, cursor)
        if (open < 0) {
            append(line.substring(cursor))
            break
        }
        val close = line.indexOf(BOLD_DELIMITER, open + BOLD_DELIMITER.length)
        if (close < 0) {
            append(line.substring(cursor))
            break
        }
        append(line.substring(cursor, open))
        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
            append(line.substring(open + BOLD_DELIMITER.length, close))
        }
        cursor = close + BOLD_DELIMITER.length
    }
}
