package ai.voqal.sdk.transport

/**
 * The hard request-header contract between the SDK and the engine. Every authenticated
 * request must carry these (the values are resolved per-request — the token is read live).
 *
 * These names must round-trip exactly; the engine routes and authenticates on them.
 */
object VoqalHeaders {

    /** End-user brand auth token (e.g. Paymob). Read live from the delegate every request. */
    const val TOKEN: String = "X-Token"

    /** Environment routing id; `prod-...` to production MCP, `stg-...` to staging/alpha. */
    const val REQUEST_ID: String = "X-Request-ID"

    /** JSON client metadata: `{"country_code":"EGY","user_id":"..."}`. */
    const val CLIENT_METADATA: String = "X-Client-Metadata"

    /** Publishable tenant key (`pk_live_...`); resolves the tenant on the engine. */
    const val VOQAL_KEY: String = "X-Voqal-Key"

    /** Engine-minted session token, sent as `Authorization: Session <token>`. */
    const val AUTHORIZATION: String = "Authorization"

    /** Per-request proof-of-possession JWT (ES256). See [ai.voqal.sdk.security.ProofSigner]. */
    const val PROOF: String = "Voqal-Proof"

    /** Builds the `Authorization` value for a session token. */
    fun sessionAuthorization(sessionToken: String): String = "Session $sessionToken"
}
