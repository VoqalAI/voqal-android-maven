package ai.voqal.sdk.widgets

import ai.voqal.sdk.VoqalTheme
import ai.voqal.sdk.model.ChartType
import ai.voqal.sdk.model.ListRow
import ai.voqal.sdk.model.Trend
import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.theme.ResolvedTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

private val previewTheme: ResolvedTheme =
    ResolvedTheme.resolve(VoqalTheme(), systemIsDark = true)

@Composable
private fun PreviewFrame(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(previewTheme.sheetBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        content()
    }
}

@Preview(backgroundColor = 0xFF111114, showBackground = true)
@Composable
private fun StatWidgetPreview() = PreviewFrame {
    StatWidget(Widget.Stat("Balance", "12,480 EGP", "+3.2%", Trend.UP), previewTheme)
    StatWidget(Widget.Stat("Refunds", "240 EGP", "-1.1%", Trend.DOWN), previewTheme)
}

@Preview(backgroundColor = 0xFF111114, showBackground = true)
@Composable
private fun ListWidgetPreview() = PreviewFrame {
    ListWidgetView(
        Widget.ListWidget(
            title = "Recent transactions",
            rows = listOf(
                ListRow("Coffee Bean", "Today · 9:14", "-85 EGP"),
                ListRow("Payment link", "Yesterday", "+1,200 EGP"),
                ListRow("Settlement", "Mon", "+4,000 EGP"),
            ),
        ),
        previewTheme,
    )
}

@Preview(backgroundColor = 0xFF111114, showBackground = true)
@Composable
private fun ArabicListWidgetPreview() = PreviewFrame {
    ListWidgetView(
        Widget.ListWidget(
            title = "آخر المعاملات",
            rows = listOf(
                ListRow("مقهى", "اليوم · ٩:١٤", "-٨٥ ج.م"),
                ListRow("رابط دفع", "أمس", "+١٢٠٠ ج.م"),
            ),
        ),
        previewTheme,
    )
}

@Preview(backgroundColor = 0xFF111114, showBackground = true)
@Composable
private fun CardWidgetPreview() = PreviewFrame {
    CardWidget(
        Widget.Card(
            title = "Payment link",
            rows = listOf(listOf("Amount", "500 EGP"), listOf("Status", "Active")),
            footer = "Expires in 24h",
        ),
        previewTheme,
    )
}

@Preview(backgroundColor = 0xFF111114, showBackground = true)
@Composable
private fun ProgressWidgetPreview() = PreviewFrame {
    ProgressWidget(
        Widget.Progress(
            "Settlement",
            value = 0.66,
            steps = listOf("Requested", "Processing", "Done"),
            stepActive = 1,
            eta = "~2 min",
        ),
        previewTheme,
    )
}

@Preview(backgroundColor = 0xFF111114, showBackground = true)
@Composable
private fun ChartWidgetPreview() = PreviewFrame {
    ChartWidget(Widget.Chart(ChartType.BARS, listOf(3.0, 7.0, 4.0, 9.0, 5.0), highlight = 3), previewTheme)
    ChartWidget(Widget.Chart(ChartType.LINE, listOf(2.0, 5.0, 3.0, 8.0, 6.0)), previewTheme)
    ChartWidget(Widget.Chart(ChartType.RING, listOf(0.72)), previewTheme)
}

@Preview(backgroundColor = 0xFF111114, showBackground = true)
@Composable
private fun MarkdownWidgetPreview() = PreviewFrame {
    MarkdownWidget(
        Widget.Markdown("Here is your **summary**:\n- First point\n- Second **bold** point\nA closing line."),
        previewTheme,
    )
}

@Preview(backgroundColor = 0xFF111114, showBackground = true)
@Composable
private fun ConfirmWidgetPreview() = PreviewFrame {
    ConfirmWidget(
        Widget.Confirm(
            title = "Send 500 EGP?",
            rows = listOf(listOf("To", "Ahmed"), listOf("Fee", "0 EGP")),
            price = "500 EGP",
            cta = "Send now",
            execute = JsonObject(mapOf("action" to JsonPrimitive("send"))),
        ),
        previewTheme,
        onConfirm = {},
    )
}

@Preview(backgroundColor = 0xFF111114, showBackground = true)
@Composable
private fun FollowAndChipsPreview() = PreviewFrame {
    FollowPill("Show me more", previewTheme, onTap = {})
    SuggestionChips(listOf("What's my balance", "Recent payouts", "Create a link"), previewTheme, onTap = {})
}
