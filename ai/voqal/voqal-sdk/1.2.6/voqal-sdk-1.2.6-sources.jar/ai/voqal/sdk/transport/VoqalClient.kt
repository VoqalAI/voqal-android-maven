package ai.voqal.sdk.transport

import ai.voqal.sdk.VoqalDelegate
import ai.voqal.sdk.model.RenderSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.time.Instant
import java.time.format.DateTimeFormatter

/**
 * The engine HTTP client: streams turns over SSE and runs confirmed actions over `execute`.
 *
 * Attaches the full header contract ([VoqalHeaders]) on every request — reading `X-Token`
 * and metadata live from [delegate], the session token from [sessionStore], and a
 * per-request proof from [proofSigner]. On `401` it silently re-bootstraps the session
 * (once) and replays the request.
 *
 * @param delegate Supplies the live `X-Token` and client metadata.
 * @param sessionStore Supplies the session token; handles 401 silent refresh
 *   ([SessionManagerStore] adapts the production `SessionManager`).
 * @param proofSigner Mints the per-request `Voqal-Proof` ES256 JWT
 *   ([ProofSignerAdapter] adapts the production `ProofSigner`).
 * @param endpoint Resolves route URLs.
 * @param httpClient The shared OkHttp client (connection-pooled; timeouts applied here).
 * @param requestId The environment-routing `X-Request-ID` (e.g. `prod-...`).
 * @param apiKey The publishable `X-Voqal-Key` (`pk_live_...`), or null when unset.
 */
class VoqalClient(
    private val delegate: VoqalDelegate,
    private val sessionStore: SessionTokenStore,
    private val proofSigner: RequestProofSigner,
    private val endpoint: VoqalEndpoint,
    private val httpClient: OkHttpClient,
    private val requestId: String,
    private val apiKey: String?,
) {

    /**
     * Stream one conversational turn from a typed/transcribed message.
     *
     * Emits [RenderEvent]s in order until [RenderEvent.Done]. Attaches all required headers
     * and performs the single 401 silent-refresh retry. The returned flow is cold; collecting
     * it issues the request, and cancelling the collector closes the underlying call.
     *
     * @param message The user's transcript/typed text.
     * @param messages Optional client-supplied conversation history (DB-less mode).
     * @param sessionId The active session id.
     * @return A cold [Flow] that performs the request when collected.
     */
    fun turn(
        message: String,
        messages: List<JsonObject> = emptyList(),
        sessionId: String? = null,
    ): Flow<RenderEvent> = flow {
        // The engine persists each turn against the bootstrap's session id —
        // a null id is a server-side error, so establish the session first.
        if (sessionId == null && sessionStore.currentSessionId() == null) {
            sessionStore.ensureSession()
        }
        val effectiveSessionId = sessionId ?: sessionStore.currentSessionId()
        val bodyText = RequestBodies.turn(message, effectiveSessionId, countryCode(), messages)
        streamSse(endpoint.turn(), bodyText)
    }.flowOn(Dispatchers.IO)

    /**
     * Run an action via `/voqal/execute`.
     *
     * @param execute The opaque execute payload, passed through unchanged.
     * @param sessionId The active session id.
     * @param verified Whether a local passcode/biometric step actually ran. True for an accepted
     *   confirm card (attaches the `auth` envelope); false for a silent, direct tool call such as
     *   add-to-cart (omits `auth` so no passcode attestation is fabricated).
     * @return The decoded [ExecuteResponse].
     */
    suspend fun execute(
        execute: JsonObject,
        sessionId: String? = null,
        verified: Boolean = true,
    ): ExecuteResponse {
        val verifiedAt = if (verified) DateTimeFormatter.ISO_INSTANT.format(Instant.now()) else null
        val effectiveSessionId = sessionId ?: sessionStore.currentSessionId()
        val bodyText = RequestBodies.execute(execute, effectiveSessionId, verifiedAt)
        val responseBody = withContext(Dispatchers.IO) {
            postWithRetry(endpoint.execute(), bodyText)
        }
        return ExecuteResponse.decode(responseBody)
    }

    /**
     * Warm the engine for the next turn by ensuring a session exists; bootstrapping fires the
     * engine's background MCP-warm and prompt-cache prime.
     *
     * Failures surface to the caller (the SDK reports them via diagnostics, not by throwing
     * into the user's turn).
     */
    suspend fun prewarm() {
        sessionStore.ensureSession()
    }

    private suspend fun FlowCollector<RenderEvent>.streamSse(url: String, bodyText: String) {
        var refreshed = false
        while (true) {
            val call = newCall(url, bodyText)
            val response = call.executeOrThrow(url)
            if (response.code == HTTP_UNAUTHORIZED && !refreshed) {
                response.close()
                sessionStore.silentRefresh()
                refreshed = true
                continue
            }
            emitSseEvents(call, response, url)
            return
        }
    }

    private suspend fun FlowCollector<RenderEvent>.emitSseEvents(
        call: Call,
        response: Response,
        url: String,
    ) {
        try {
            if (!response.isSuccessful) {
                throw VoqalTransportException("Turn request to $url failed: HTTP ${response.code}")
            }
            val source = response.body?.source()
                ?: throw VoqalTransportException("Turn response from $url had no body")
            val parser = SseParser()
            while (currentCoroutineContext().isActive && !source.exhausted()) {
                val line = source.readUtf8Line() ?: break
                val sse = parser.accept(line) ?: continue
                val event = RenderEventDecoder.decode(sse) ?: continue
                emit(event)
            }
        } finally {
            // Closing the call cancels the in-flight HTTP read when the collector is cancelled.
            call.cancel()
            response.close()
        }
    }

    private suspend fun postWithRetry(url: String, bodyText: String): String {
        var refreshed = false
        while (true) {
            val response = newCall(url, bodyText).executeOrThrow(url)
            if (response.code == HTTP_UNAUTHORIZED && !refreshed) {
                response.close()
                sessionStore.silentRefresh()
                refreshed = true
                continue
            }
            response.use {
                if (!it.isSuccessful) {
                    throw VoqalTransportException("Request to $url failed: HTTP ${it.code}")
                }
                return it.body?.string()
                    ?: throw VoqalTransportException("Response from $url had no body")
            }
        }
    }

    private fun newCall(url: String, bodyText: String): Call {
        val bodyBytes = bodyText.toByteArray(Charsets.UTF_8)
        return httpClient.newCall(buildRequest(url, bodyBytes))
    }

    private fun Call.executeOrThrow(url: String): Response = try {
        execute()
    } catch (e: IOException) {
        throw VoqalTransportException("Network call to $url failed", e)
    }

    private fun buildRequest(url: String, bodyBytes: ByteArray): Request {
        // htu is the request PATH (e.g. "/v2/voqal"), not the absolute URL —
        // the engine gate verifies the proof against the original request path.
        val proofPath = url.toHttpUrl().encodedPath
        val proof = proofSigner.sign(HTTP_METHOD_POST, proofPath, bodyBytes)
        val builder = Request.Builder()
            .url(url)
            .post(bodyBytes.toRequestBody(JSON_MEDIA_TYPE))
            .header(VoqalHeaders.TOKEN, delegate.getToken())
            .header(VoqalHeaders.REQUEST_ID, requestId)
            .header(VoqalHeaders.PROOF, proof)
            .header(ACCEPT_HEADER, SSE_MEDIA_TYPE)
        delegate.getMetadata()?.let { builder.header(VoqalHeaders.CLIENT_METADATA, it) }
        apiKey?.let { builder.header(VoqalHeaders.VOQAL_KEY, it) }
        sessionStore.currentToken()?.let {
            builder.header(VoqalHeaders.AUTHORIZATION, VoqalHeaders.sessionAuthorization(it))
        }
        return builder.build()
    }

    private fun countryCode(): String? {
        val metadata = delegate.getMetadata() ?: return null
        return try {
            val parsed = RenderSpec.json.decodeFromString(JsonObject.serializer(), metadata)
            (parsed[METADATA_COUNTRY_CODE] as? JsonPrimitive)?.takeIf { it.isString }?.content
        } catch (e: kotlinx.serialization.SerializationException) {
            null
        }
    }

    companion object {
        private const val HTTP_UNAUTHORIZED = 401
        private const val HTTP_METHOD_POST = "POST"
        private const val ACCEPT_HEADER = "Accept"
        private const val SSE_MEDIA_TYPE = "text/event-stream"
        private const val METADATA_COUNTRY_CODE = "country_code"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
