package ai.voqal.sdk.haptics

/**
 * The haptic feedback contract for the assistant experience. A seam (interface) so tests can
 * substitute a spy and assert which cues fired without touching the device vibrator.
 *
 * Each method maps to one experience moment. Implementations must be no-ops when haptics are
 * disabled ([ai.voqal.sdk.VoqalConfiguration.hapticsEnabled]) or unsupported by the device.
 */
interface VoqalHapticsPlaying {

    /**
     * Fired on the press AND release of the hold-to-speak orb — a crisp medium-impact "touch"
     * acknowledging the gesture itself (distinct from [recordingStarted], which marks the mic
     * actually opening after the hold delay).
     */
    fun touch()

    /** Fired when voice recording starts (user began speaking). */
    fun recordingStarted()

    /** Fired when voice recording stops (end of speech / send). */
    fun recordingStopped()

    /** Fired when a transcript arrives from STT. */
    fun transcriptArrived()

    /** Fired when an action needs the user's confirmation (e.g. a confirm card appears). */
    fun actionNeeded()

    /** Fired on a recoverable warning. */
    fun warning()

    /** Fired on an unrecoverable failure. */
    fun failure()
}
