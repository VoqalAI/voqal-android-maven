package ai.voqal.sdk.transport

/**
 * A transport-layer failure: a non-success HTTP status, a missing body, a malformed stream,
 * or an underlying network error.
 *
 * Distinct from serialization and security exceptions so callers (and diagnostics) can tell
 * a network/protocol failure apart from a decode failure or an auth failure.
 *
 * @param message Actionable description: what failed, for which URL, and the status if any.
 * @param cause The underlying error (e.g. an [java.io.IOException]), when there is one.
 */
class VoqalTransportException(
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause)
