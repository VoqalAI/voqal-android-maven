package ai.voqal.sdk.voice

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Decides whether a recorded WAV clip contains audible speech worth sending to the engine.
 *
 * This is a cheap gate that drops empty taps and silence before paying for an upload + STT
 * round-trip. It is intentionally lenient: when in doubt it **fails open** (returns true) so
 * we never silently swallow a real utterance because of a parse quirk.
 *
 * Heuristic ([containsAudibleAudio]):
 * 1. A clip below [MIN_CLIP_BYTES] is too short to be speech, return false.
 * 2. Otherwise scan the PCM16 samples; if any sample's absolute amplitude reaches
 *    [PEAK_THRESHOLD], the clip is audible, return true.
 * 3. On any parsing error, return [FAIL_OPEN_RESULT] (true).
 */
object AudioClipAnalyzer {

    /** Clips shorter than this (header + samples) are treated as non-audible. */
    const val MIN_CLIP_BYTES: Int = 2_000

    /** Minimum absolute Int16 amplitude for a clip to count as audible. */
    const val PEAK_THRESHOLD: Int = 300

    /** Standard WAV PCM header size; samples begin after it. */
    const val WAV_HEADER_BYTES: Int = 44

    /** Result returned when the clip cannot be parsed (lenient by design). */
    const val FAIL_OPEN_RESULT: Boolean = true

    /**
     * Whether [wavBytes] contains audible audio.
     *
     * @param wavBytes The complete WAV clip (44-byte header + PCM16 mono samples).
     * @return true if the clip is long enough and has a sample peaking at/above
     *   [PEAK_THRESHOLD]; false if too short or silent; [FAIL_OPEN_RESULT] on parse error.
     */
    fun containsAudibleAudio(wavBytes: ByteArray): Boolean {
        if (wavBytes.size < MIN_CLIP_BYTES) return false

        return try {
            hasSamplePeakAtOrAbove(wavBytes, PEAK_THRESHOLD)
        } catch (error: RuntimeException) {
            FAIL_OPEN_RESULT
        }
    }

    /** The loudest |sample| in the clip (0..32767). Diagnostic companion to the gate. */
    fun peakAmplitude(wavBytes: ByteArray): Int {
        var peak = 0
        var index = WAV_HEADER_BYTES
        while (index + 1 < wavBytes.size) {
            val sample = ((wavBytes[index + 1].toInt() shl 8) or (wavBytes[index].toInt() and 0xFF))
            val magnitude = kotlin.math.abs(sample.toShort().toInt())
            if (magnitude > peak) peak = magnitude
            index += 2
        }
        return peak
    }

    private fun hasSamplePeakAtOrAbove(wavBytes: ByteArray, threshold: Int): Boolean {
        val samples = ByteBuffer
            .wrap(wavBytes, WAV_HEADER_BYTES, wavBytes.size - WAV_HEADER_BYTES)
            .order(ByteOrder.LITTLE_ENDIAN)
            .asShortBuffer()

        while (samples.hasRemaining()) {
            if (kotlin.math.abs(samples.get().toInt()) >= threshold) return true
        }
        return false
    }
}
