package ai.voqal.sdk.experience

/**
 * Keeps a [VoqalExperienceViewModel] alive across sheet open/close so reopening resumes the
 * conversation instead of resetting to the home glance. The retained instance is dropped after
 * the configured inactivity window, after which the next request builds a fresh one.
 *
 * In-memory only — no conversation state is written to disk (mirrors the iOS retainer; no
 * financial data persisted). The clock is injectable so the timeout is unit-testable without
 * sleeping.
 *
 * Thread-confined: the sheet drives this from the main thread, so no synchronization is needed.
 *
 * @param clock Wall-clock source; defaults to the system clock.
 */
class VoqalConversationRetainer(
    private val clock: ExperienceClock = ExperienceClock.SYSTEM,
) {

    private var retained: VoqalExperienceViewModel? = null
    private var lastActivityAtMillis: Long = Long.MIN_VALUE

    /**
     * Return the retained model if it is still within [timeoutSeconds] of the last activity;
     * otherwise build, retain, and return a fresh one. Either way the activity clock is reset.
     *
     * @param timeoutSeconds Inactivity window after which the conversation resets.
     * @param build Factory for a fresh model when none is reusable.
     * @return The reused or freshly built model.
     */
    fun model(
        timeoutSeconds: Long,
        build: () -> VoqalExperienceViewModel,
    ): VoqalExperienceViewModel {
        val now = clock.nowMillis()
        val timeoutMillis = timeoutSeconds * MILLIS_PER_SECOND
        val current = retained
        if (current != null && now - lastActivityAtMillis < timeoutMillis) {
            lastActivityAtMillis = now
            return current
        }
        val fresh = build()
        retained = fresh
        lastActivityAtMillis = now
        return fresh
    }

    /** Drop the conversation; the next [model] call starts fresh at the home glance. */
    fun reset() {
        retained = null
        lastActivityAtMillis = Long.MIN_VALUE
    }

    private companion object {
        const val MILLIS_PER_SECOND = 1000L
    }
}
