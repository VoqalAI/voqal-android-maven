package ai.voqal.sdk.voice

/**
 * A thin seam over the platform microphone so [WavRecorder]'s WAV assembly and amplitude
 * math can be unit-tested on the JVM without Robolectric or a real `AudioRecord`.
 *
 * The default Android implementation ([AndroidAudioSource]) wraps a fresh `AudioRecord`;
 * tests supply a fake that replays a scripted PCM buffer.
 *
 * Implementations are single-use: [startRecording] then repeated [read] until [stop], then
 * [release]. A released source must not be reused (matching the "fresh recorder per clip"
 * rule).
 */
interface AudioSource {

    /**
     * Whether the source initialized successfully and is ready to record.
     *
     * Mirrors `AudioRecord.getState() == STATE_INITIALIZED`. A `false` here means the audio
     * session could not be opened (e.g. mic in use, permission lost after grant).
     */
    val isInitialized: Boolean

    /** Begin capturing. Must be called once before the first [read]. */
    fun startRecording()

    /**
     * Read the next chunk of PCM16 little-endian bytes into [buffer].
     *
     * @param buffer Destination for raw little-endian PCM16 samples.
     * @return The number of bytes written (`> 0`), `0` when no data is currently available,
     *   or a negative value on error/end-of-stream (the recording loop stops).
     */
    fun read(buffer: ByteArray): Int

    /** Stop capturing. Safe to call more than once. */
    fun stop()

    /** Release all native resources. Safe to call more than once; idempotent. */
    fun release()
}
