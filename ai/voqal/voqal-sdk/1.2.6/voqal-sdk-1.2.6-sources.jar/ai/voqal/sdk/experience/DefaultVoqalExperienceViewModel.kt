package ai.voqal.sdk.experience

import ai.voqal.sdk.VoqalConfiguration
import ai.voqal.sdk.VoqalDelegate
import ai.voqal.sdk.diagnostics.VoqalLog
import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.transport.RenderEvent
import ai.voqal.sdk.transport.VoqalClient
import ai.voqal.sdk.voice.AudioClipAnalyzer
import ai.voqal.sdk.voice.WavRecorder
import android.content.Context
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import java.util.UUID

/**
 * The production [VoqalExperienceViewModel]: folds streamed render events into the visible
 * [Exchange] list, drives the phase machine, and fires haptics at each experience moment.
 *
 * Every collaborator is constructor-injected via a narrow seam so the whole flow is
 * test-fakeable without Android, the network, or a real microphone.
 *
 * @param client The engine client for typed turns and confirmed actions.
 * @param voiceTurnRunner Opens a voice socket per clip and streams its events.
 * @param recorderFactory Creates a fresh [WavRecorder] per voice clip.
 * @param haptics Optional haptic feedback; null disables cues entirely.
 * @param clipAnalyzer Gates silent clips before paying for an upload + STT round-trip.
 * @param config The SDK configuration (drives the home glance + conversation timeout).
 * @param delegate The host bridge; receives upload results and errors.
 */
class DefaultVoqalExperienceViewModel(
    private val client: VoqalClient,
    private val voiceTurnRunner: VoiceTurnRunner,
    private val recorderFactory: RecorderFactory,
    private val haptics: ai.voqal.sdk.haptics.VoqalHapticsPlaying?,
    private val clipAnalyzer: AudioClipAnalyzer = AudioClipAnalyzer,
    private val config: VoqalConfiguration,
    private val delegate: VoqalDelegate,
) : VoqalExperienceViewModel() {

    private val _phase = MutableStateFlow(VoqalPhase.Idle)
    override val phase: StateFlow<VoqalPhase> = _phase.asStateFlow()

    private val _exchanges = MutableStateFlow<List<Exchange>>(emptyList())
    override val exchanges: StateFlow<List<Exchange>> = _exchanges.asStateFlow()

    /** The live recorder for the in-flight voice clip; null when not listening. */
    private var recorder: WavRecorder? = null

    /** The current recorder's amplitude flow for the live waveform, or a flat resting flow. */
    val amplitude: StateFlow<Float>
        get() = recorder?.amplitude ?: RESTING_AMPLITUDE

    /** The in-flight turn job, cancelled on barge-in. */
    private var turnJob: Job? = null

    private var homeLoaded = false

    /**
     * Run the hidden opening glance once: a silent turn that asks for a one-line snapshot,
     * rendered as the home exchange, with the host's pinned CTAs offered as suggestions.
     *
     * @param pinnedCTAs Host-pinned quick-action prompts shown as suggestion chips.
     */
    fun loadHome(pinnedCTAs: List<String> = config.home.pinnedCTAs) {
        if (homeLoaded || !config.home.showAgentGlance) return
        homeLoaded = true

        val index = appendExchange(question = null, isVoice = false)
        _phase.value = VoqalPhase.Thinking
        turnJob = viewModelScope.launch {
            runTurn(client.turn(HOME_GLANCE_PROMPT), index, extraSuggestions = pinnedCTAs)
        }
    }

    override fun send(text: String) {
        val message = text.trim()
        if (message.isEmpty()) return

        cancelInFlightTurn()
        val index = appendExchange(question = message, isVoice = false)
        _phase.value = VoqalPhase.Thinking
        turnJob = viewModelScope.launch { runTurn(client.turn(message), index) }
    }

    override fun startVoice() = startVoice(context = null)

    /**
     * Begin a voice turn, allocating a fresh recorder. Cancels any in-flight answer/TTS first
     * (barge-in) so speaking always interrupts.
     *
     * @param context Host context for microphone capture; null is supported for tests.
     */
    fun startVoice(context: Context?) {
        cancelInFlightTurn()
        haptics?.recordingStarted()

        val fresh = recorderFactory.create()
        recorder = fresh
        fresh.start(context)
        _phase.value = VoqalPhase.Listening
    }

    override fun stopVoiceAndSend() {
        val active = recorder ?: return
        haptics?.recordingStopped()
        val wav = active.stop()
        recorder = null

        val peak = clipAnalyzer.peakAmplitude(wav)
        VoqalLog.event("voice_clip_recorded", mapOf("bytes" to wav.size, "peak" to peak))
        if (!clipAnalyzer.containsAudibleAudio(wav)) {
            dropInaudibleClip()
            return
        }
        val index = appendExchange(question = null, isVoice = true)
        _phase.value = VoqalPhase.Transcribing
        val audioBase64 = java.util.Base64.getEncoder().encodeToString(wav)
        turnJob = viewModelScope.launch {
            runTurn(voiceTurnRunner.run(audioBase64), index, isVoice = true)
        }
    }

    override fun confirm(execute: JsonObject) {
        cancelInFlightTurn()
        val index = appendExchange(question = null, isVoice = false)
        _phase.value = VoqalPhase.Thinking
        turnJob = viewModelScope.launch { runConfirm(execute, index) }
    }

    /**
     * Fire the press/release "touch" haptic for the hold-to-speak orb. Driven by the dock's
     * gesture (press and release), independent of the turn lifecycle.
     */
    fun touch() {
        haptics?.touch()
    }

    /**
     * Silently add a product to the cart from a [Widget.Products] "Add" button. Runs the MCP
     * `add_to_cart` tool directly via `/voqal/execute` — NOT a conversational turn, so it adds no
     * question/answer bubble and triggers no agent reply. The product row shows its own "Added ✓";
     * the user sees the cart only when they ask.
     *
     * Runs in parallel with any in-flight turn and never changes the phase. The execute call is
     * unverified — add-to-cart is a direct tool with no biometric/passcode step, so no auth
     * envelope is attached. Failures are logged (never the token) and otherwise swallowed so a
     * cart tap can't crash the experience.
     *
     * @param productId The product's stable id.
     * @param quantity The chosen quantity (>= 1).
     * @return The [Job] running the silent add, so callers/tests can observe completion. Compose
     *   wiring ignores it.
     */
    fun addToCart(productId: String, quantity: Int): Job {
        val spec = buildJsonObject {
            put("tool", ADD_TO_CART_TOOL)
            putJsonObject("args") {
                put("product_id", productId)
                put("qty", quantity)
            }
        }
        return viewModelScope.launch {
            try {
                client.execute(spec, verified = false)
                VoqalLog.event("cart_add", mapOf("product" to productId, "qty" to quantity))
            } catch (error: Exception) {
                VoqalLog.error("cart_add_failed", error, mapOf("product" to productId))
            }
        }
    }

    private suspend fun runTurn(
        events: Flow<RenderEvent>,
        index: Int,
        isVoice: Boolean = false,
        extraSuggestions: List<String> = emptyList(),
    ) {
        val started = System.currentTimeMillis()
        VoqalLog.event("turn_started", mapOf("requestId" to config.requestId, "isVoice" to isVoice))
        try {
            events.collect { event -> foldEvent(event, index, isVoice, extraSuggestions) }
            finishTurn(started)
        } catch (error: Exception) {
            failTurn(index, error)
        }
    }

    private fun foldEvent(
        event: RenderEvent,
        index: Int,
        isVoice: Boolean,
        extraSuggestions: List<String>,
    ) {
        when (event) {
            is RenderEvent.Transcript -> applyTranscript(event.text, index)
            // TTS is disabled platform-wide: streaming answer text is a *thinking*
            // visual, not a spoken one. Speaking is reserved for actual audio playback.
            is RenderEvent.SpeakDelta -> updateExchange(index) {
                it.copy(answerText = it.answerText + event.text)
            }
            is RenderEvent.Widgets -> applyWidgets(event, index, extraSuggestions)
            is RenderEvent.Follow -> updateExchange(index) { it.copy(follow = event.text) }
            is RenderEvent.Error -> updateExchange(index) { it.copy(error = event.speak) }
            is RenderEvent.Tts -> Unit
            RenderEvent.Done -> if (isVoice) notifyUploadResult(index)
        }
    }

    private fun applyTranscript(text: String, index: Int) {
        updateExchange(index) { it.copy(question = text) }
        haptics?.transcriptArrived()
        _phase.value = VoqalPhase.Thinking
    }

    private fun applyWidgets(event: RenderEvent.Widgets, index: Int, extraSuggestions: List<String>) {
        if (event.widgets.any { it is Widget.Confirm }) haptics?.actionNeeded()
        updateExchange(index) {
            it.copy(widgets = event.widgets, suggestions = mergeSuggestions(event.suggestions, extraSuggestions))
        }
    }

    private suspend fun runConfirm(execute: JsonObject, index: Int) {
        try {
            val response = client.execute(execute)
            VoqalLog.event("execute_done", mapOf("hasSpeak" to (response.speak != null)))
            updateExchange(index) {
                it.copy(
                    answerText = response.speak.orEmpty(),
                    widgets = response.widgets + doneCardWidgets(response.done),
                )
            }
            _phase.value = VoqalPhase.Idle
        } catch (error: Exception) {
            failTurn(index, error)
        }
    }

    /**
     * The engine's execute `done` card is `{type, title, line1?, line2?}` with the
     * shareable link in `line2`. Rendered as a card so the link is visible/copyable.
     */
    private fun doneCardWidgets(done: JsonObject?): List<Widget> {
        if (done == null) return emptyList()
        val title = (done["title"] as? JsonPrimitive)?.takeIf { it.isString }?.content
        val line1 = (done["line1"] as? JsonPrimitive)?.takeIf { it.isString }?.content
        val line2 = (done["line2"] as? JsonPrimitive)?.takeIf { it.isString }?.content
        val rows = buildList {
            line1?.takeIf { it.isNotBlank() }?.let { add(listOf("", it)) }
            line2?.takeIf { it.isNotBlank() }?.let { add(listOf("Link", it)) }
        }
        if (title.isNullOrBlank() || rows.isEmpty()) return emptyList()
        return listOf(Widget.Card(title = title, rows = rows))
    }

    private fun finishTurn(startedAt: Long) {
        VoqalLog.event("turn_finished", mapOf("durationMs" to (System.currentTimeMillis() - startedAt)))
        _phase.value = VoqalPhase.Idle
    }

    private fun failTurn(index: Int, error: Throwable) {
        VoqalLog.error("turn_failed", error, mapOf("requestId" to config.requestId))
        updateExchange(index) {
            it.copy(error = it.error ?: (error.message ?: GENERIC_ERROR))
        }
        haptics?.failure()
        delegate.onError(error)
        _phase.value = VoqalPhase.Idle
    }

    private fun dropInaudibleClip() {
        haptics?.warning()
        appendExchange(question = null, isVoice = true, error = INAUDIBLE_MESSAGE)
        _phase.value = VoqalPhase.Idle
    }

    private fun notifyUploadResult(index: Int) {
        val exchange = _exchanges.value.getOrNull(index) ?: return
        delegate.onUploadResult(exchange.question ?: exchange.answerText)
    }

    private fun cancelInFlightTurn() {
        turnJob?.cancel()
        turnJob = null
    }

    private fun appendExchange(
        question: String?,
        isVoice: Boolean,
        error: String? = null,
    ): Int {
        val exchange = Exchange(
            id = UUID.randomUUID().toString(),
            question = question,
            isVoice = isVoice,
            error = error,
        )
        var index = -1
        _exchanges.update { current ->
            index = current.size
            current + exchange
        }
        return index
    }

    private inline fun updateExchange(index: Int, transform: (Exchange) -> Exchange) {
        _exchanges.update { current ->
            if (index !in current.indices) return@update current
            current.toMutableList().also { it[index] = transform(it[index]) }
        }
    }

    private fun mergeSuggestions(fromEngine: List<String>, pinned: List<String>): List<String> {
        if (pinned.isEmpty()) return fromEngine
        return (fromEngine + pinned).distinct()
    }

    override fun onCleared() {
        cancelInFlightTurn()
        recorder?.let { runCatching { it.stop() } }
        recorder = null
        super.onCleared()
    }

    companion object {
        const val HOME_GLANCE_PROMPT: String =
            "Give me a one-line greeting-ready snapshot of my account right now"

        private const val INAUDIBLE_MESSAGE = "I didn't catch that — please try again."
        private const val GENERIC_ERROR = "Something went wrong. Please try again."
        private const val ADD_TO_CART_TOOL = "add_to_cart"

        private val RESTING_AMPLITUDE = MutableStateFlow(0f).asStateFlow()
    }
}
