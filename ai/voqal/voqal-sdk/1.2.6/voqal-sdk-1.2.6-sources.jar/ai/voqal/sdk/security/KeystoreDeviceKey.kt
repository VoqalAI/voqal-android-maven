package ai.voqal.sdk.security

import java.security.KeyPair
import java.security.PrivateKey
import java.security.PublicKey

/**
 * Default [DeviceKey] implementation. Resolves the device key pair through a [KeyProvider]
 * (Android Keystore in production, in-memory `java.security` in unit tests) and derives the
 * public JWK and RFC 7638 thumbprint from it.
 *
 * The key pair is resolved once and cached; the [KeyProvider] guarantees the same key is
 * returned on every call.
 *
 * @param keyProvider Source of the device key pair. Defaults to the Android Keystore.
 */
internal class KeystoreDeviceKey(
    private val keyProvider: KeyProvider = KeystoreKeyProvider(),
) : DeviceKey {

    private val keyPair: KeyPair by lazy { keyProvider.getOrCreateKeyPair() }

    override fun privateKey(): PrivateKey = keyPair.private

    override fun publicKey(): PublicKey = keyPair.public

    override fun publicJwk(): Map<String, String> =
        EcJwk.publicJwk(keyPair.public.asEcPublicKey())

    override fun publicKeyJwk(): String = JwkJson.encode(publicJwk())

    override fun thumbprint(): String = EcJwk.thumbprint(keyPair.public.asEcPublicKey())
}
