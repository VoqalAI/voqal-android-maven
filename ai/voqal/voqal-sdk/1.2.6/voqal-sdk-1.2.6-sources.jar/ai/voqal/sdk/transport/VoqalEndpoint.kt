package ai.voqal.sdk.transport

/**
 * Resolves the engine's base URL and the absolute URLs for each route.
 *
 * The base URL defaults to [DEFAULT_BASE_URL] and can be overridden via
 * [ai.voqal.sdk.VoqalConfiguration.agentUrl] (used by the demo to target a local engine).
 * Trailing slashes on the base are normalized away so path joining is unambiguous.
 *
 * @property baseUrl The engine base, without a trailing slash.
 */
class VoqalEndpoint(baseUrl: String = DEFAULT_BASE_URL) {

    val baseUrl: String = baseUrl.trimEnd('/')

    init {
        require(this.baseUrl.startsWith("http")) {
            "VoqalEndpoint baseUrl must be an http(s) URL, was '$baseUrl'"
        }
    }

    /** `POST` — one conversational turn (SSE stream of speak deltas, widgets, done). */
    fun turn(): String = baseUrl + PATH_TURN

    /** `POST` — run a confirmed action after biometric/confirm. */
    fun execute(): String = baseUrl + PATH_EXECUTE

    /** `POST` — session bootstrap; mints the session token and warms the engine. */
    fun createSession(): String = baseUrl + PATH_CREATE_SESSION

    /** `WS` — live voice stream (mic frames in, transcript/speak/widgets out). */
    fun stream(): String = toWebSocketScheme(baseUrl) + PATH_STREAM

    private fun toWebSocketScheme(httpUrl: String): String = when {
        httpUrl.startsWith("https") -> "wss" + httpUrl.removePrefix("https")
        httpUrl.startsWith("http") -> "ws" + httpUrl.removePrefix("http")
        else -> httpUrl
    }

    companion object {
        /** Production engine base. Mirrors the iOS SDK's baked `.production` endpoint. */
        const val DEFAULT_BASE_URL: String = "https://api.voqal.ai/v2"

        const val PATH_TURN: String = "/voqal"
        const val PATH_EXECUTE: String = "/voqal/execute"
        const val PATH_CREATE_SESSION: String = "/api/v1/create-session"
        const val PATH_STREAM: String = "/voqal/stream"
    }
}
