package ai.voqal.sdk.security

import java.util.Base64

/**
 * Base64url (RFC 4648 §5) without padding — the encoding required by JWT/JWS and JWK.
 *
 * Uses [java.util.Base64] (pure JVM, available since API 26 / minSdk 28) rather than
 * `android.util.Base64` so the encoding behaves identically in JVM unit tests without
 * Robolectric. The output has no `=` padding and no line wrapping.
 */
internal object Base64Url {

    private val ENCODER = Base64.getUrlEncoder().withoutPadding()

    /**
     * Encode bytes as base64url text with no padding.
     *
     * @param bytes The bytes to encode.
     * @return The base64url string (no `=` padding, no line wrapping).
     */
    fun encode(bytes: ByteArray): String = ENCODER.encodeToString(bytes)
}
