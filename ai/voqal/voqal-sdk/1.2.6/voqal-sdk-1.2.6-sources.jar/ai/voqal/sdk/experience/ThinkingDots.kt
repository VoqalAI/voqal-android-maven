package ai.voqal.sdk.experience

import ai.voqal.sdk.theme.ResolvedTheme
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.StartOffsetType
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp

/**
 * The turn-level "thinking" indicator: three tertiary dots fading 0.3↔1 out of phase — a faithful
 * port of iOS `ThinkingDots`.
 *
 * iOS animates each dot's opacity with `easeInOut(duration: 0.6).repeatForever().delay(0.2 * i)`.
 * SwiftUI's `repeatForever()` (without `autoreverses: false`) reverses, so the dot eases up then
 * back down over a 1.2s cycle; the 0.2s-per-dot delay staggers them. This uses an infinite
 * [RepeatMode.Reverse] tween with a per-dot [StartOffset] to reproduce the same wave.
 *
 * @param theme Resolved theme; the dots use [ResolvedTheme.textTertiary].
 */
@Composable
internal fun ThinkingDots(theme: ResolvedTheme) {
    val transition = rememberInfiniteTransition(label = "thinkingDots")
    Row(horizontalArrangement = Arrangement.spacedBy(DOT_SPACING)) {
        repeat(DOT_COUNT) { index ->
            val opacity by transition.animateFloat(
                initialValue = MIN_OPACITY,
                targetValue = MAX_OPACITY,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = HALF_CYCLE_MILLIS),
                    repeatMode = RepeatMode.Reverse,
                    initialStartOffset = StartOffset(
                        offsetMillis = index * STAGGER_MILLIS,
                        offsetType = StartOffsetType.FastForward,
                    ),
                ),
                label = "dotOpacity",
            )
            androidx.compose.foundation.layout.Box(
                Modifier
                    .size(DOT_SIZE)
                    .alpha(opacity)
                    .clip(CircleShape)
                    .background(theme.textTertiary),
            )
        }
    }
}

private const val DOT_COUNT = 3
private val DOT_SIZE = 6.dp
private val DOT_SPACING = 6.dp
private const val MIN_OPACITY = 0.3f
private const val MAX_OPACITY = 1f
private const val HALF_CYCLE_MILLIS = 600
private const val STAGGER_MILLIS = 200
