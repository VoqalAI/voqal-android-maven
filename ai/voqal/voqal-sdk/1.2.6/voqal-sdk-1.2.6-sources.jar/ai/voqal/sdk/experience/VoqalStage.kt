package ai.voqal.sdk.experience

import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.theme.ResolvedTheme
import ai.voqal.sdk.theme.TextDirection
import ai.voqal.sdk.widgets.WidgetView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection as ComposeTextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.json.JsonObject

/**
 * The present-tense conversation stage — a faithful port of iOS `StageView`.
 *
 * The latest exchange is the hero (its voice answer word-reveals; earlier turns read back as a
 * quiet transcript at 60–70% opacity). When the conversation is empty except for the agent's
 * opening glance, [HomeGlance] renders the designed home page instead of a chat bubble.
 *
 * On Android the home glance is the first exchange (a `question == null` agent turn). It is split
 * out here so it renders as the home page, while all subsequent turns render as exchanges. While
 * that glance turn is still loading, [HomeGlance] shows its skeleton.
 *
 * @param exchanges The conversation, oldest first.
 * @param phase The interaction phase (drives the thinking dots between turns).
 * @param userName Optional display name for the home greeting.
 * @param theme Resolved colors for each text tier and widget surface.
 * @param scrollToTopSignal A monotonically increasing counter; each change scrolls the stage back
 *   to the first exchange (the header history affordance), mirroring iOS `scrollToTopRequest`.
 * @param pinnedCTAs Host-pinned prompts shown on the home glance when the agent glance is off or
 *   has not loaded yet (so the greeting + CTAs always render, matching iOS).
 * @param onSuggestionTap Invoked with a tapped suggestion/follow as the next user message.
 * @param onConfirm Invoked with a confirm widget's opaque execute payload.
 * @param onAddToCart Invoked with `(productId, quantity)` from a products widget's "Add" button.
 */
@Composable
fun VoqalStage(
    exchanges: List<Exchange>,
    phase: VoqalPhase,
    userName: String?,
    theme: ResolvedTheme,
    modifier: Modifier = Modifier,
    scrollToTopSignal: Int = 0,
    pinnedCTAs: List<String> = emptyList(),
    onSuggestionTap: (String) -> Unit,
    onConfirm: (JsonObject) -> Unit,
    onAddToCart: (String, Int) -> Unit = { _, _ -> },
) {
    val home = StageModel.homeGlance(exchanges, pinnedCTAs)
    val turns = StageModel.turns(exchanges)
    val showThinking = (phase == VoqalPhase.Thinking || phase == VoqalPhase.Transcribing) &&
        turns.isNotEmpty()

    val listState = rememberLazyListState()
    val fingerprint = exchanges.size to (exchanges.lastOrNull()?.let {
        it.answerText.length + it.widgets.size + (it.error?.length ?: 0)
    } ?: 0)
    LaunchedEffect(fingerprint) {
        if (exchanges.isNotEmpty()) listState.animateScrollToItem(maxOf(0, listState.layoutInfo.totalItemsCount - 1))
    }
    LaunchedEffect(scrollToTopSignal) {
        if (scrollToTopSignal > 0) listState.animateScrollToItem(0)
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(STAGE_SPACING),
    ) {
        if (home != null) {
            item(key = home.id) {
                HomeGlance(
                    exchange = home,
                    userName = userName,
                    isLoading = phase == VoqalPhase.Thinking && home.widgets.isEmpty() && home.error == null,
                    theme = theme,
                    onSuggestionTap = onSuggestionTap,
                    onConfirm = onConfirm,
                    onAddToCart = onAddToCart,
                )
            }
        }
        items(turns, key = { it.id }) { exchange ->
            ExchangeView(
                exchange = exchange,
                isCurrent = exchange.id == exchanges.lastOrNull()?.id,
                theme = theme,
                onConfirm = onConfirm,
                onFollow = onSuggestionTap,
                onAddToCart = onAddToCart,
            )
        }
        if (showThinking) {
            item(key = "thinking") { ThinkingDots(theme) }
        }
    }
}

@Composable
private fun ExchangeView(
    exchange: Exchange,
    isCurrent: Boolean,
    theme: ResolvedTheme,
    onConfirm: (JsonObject) -> Unit,
    onFollow: (String) -> Unit,
    onAddToCart: (String, Int) -> Unit,
) {
    val rtl = directionRtl(exchange)
    val alignment = if (rtl) Alignment.End else Alignment.Start
    val hasConfirm = exchange.widgets.any { it is Widget.Confirm }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EXCHANGE_SPACING),
        horizontalAlignment = alignment,
    ) {
        exchange.question?.takeIf { it.isNotBlank() }?.let { QuestionRow(it, theme) }
        exchange.error?.let { error ->
            AnswerText(error, isCurrent = true, isVoice = false, rtl = directionRtl(error), theme = theme)
        }
        exchange.answerText.takeIf { it.isNotBlank() }?.let { answer ->
            AnswerText(answer, isCurrent, exchange.isVoice, directionRtl(answer), theme)
        }
        exchange.widgets.forEach { widget ->
            // Product lists stay full-strength and tappable even in scroll-back — you can scroll
            // up to an earlier bundle and keep adding to the cart. Other widgets dim when not the
            // hero. Mirrors iOS StageView.
            val isProducts = widget is Widget.Products
            Box(Modifier.alpha(if (isCurrent || isProducts) 1f else INACTIVE_WIDGET_ALPHA)) {
                WidgetView(widget, theme, onConfirm, onAddToCart)
            }
        }
        if (isCurrent && !hasConfirm) {
            exchange.follow?.takeIf { it.isNotBlank() }?.let { follow ->
                FollowRow(follow, rtl, theme) { onFollow(follow) }
            }
        }
    }
}

/** The question line: a small accent dot + the text in the secondary tier. */
@Composable
private fun QuestionRow(text: String, theme: ResolvedTheme) {
    val rtl = directionRtl(text)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp),
    ) {
        Box(
            Modifier
                .size(5.dp)
                .clip(CircleShape)
                .background(theme.accent),
        )
        Text(
            text = text,
            color = theme.textSecondary,
            fontSize = QUESTION_SIZE,
            fontFamily = VoqalType.DISPLAY,
            fontWeight = VoqalType.MEDIUM,
            letterSpacing = QUESTION_TRACKING,
            style = TextStyle(textDirection = if (rtl) ComposeTextDirection.Rtl else ComposeTextDirection.Ltr),
        )
    }
}

/**
 * The answer, sized by length (short gist = hero, longer = readable). The current voice answer
 * under 90 chars word-reveals; everything else renders as plain text at the matching opacity.
 */
@Composable
private fun AnswerText(
    speak: String,
    isCurrent: Boolean,
    isVoice: Boolean,
    rtl: Boolean,
    theme: ResolvedTheme,
) {
    val size = StageModel.answerSizeSp(speak).sp
    val weight = if (size.value >= 26f) VoqalType.SEMIBOLD else VoqalType.MEDIUM
    val color = if (isCurrent) theme.textPrimary else theme.textSecondary

    if (StageModel.shouldReveal(isCurrent, isVoice, speak)) {
        RevealText(
            text = speak,
            color = color,
            fontSize = size,
            fontWeight = weight,
            rtl = rtl,
            modifier = Modifier.fillMaxWidth(),
        )
    } else {
        Text(
            text = speak,
            color = color,
            fontSize = size,
            fontFamily = VoqalType.DISPLAY,
            fontWeight = weight,
            modifier = Modifier
                .fillMaxWidth()
                .alpha(if (isCurrent) 1f else INACTIVE_ANSWER_ALPHA),
            style = TextStyle(textDirection = if (rtl) ComposeTextDirection.Rtl else ComposeTextDirection.Ltr),
        )
    }
}

/**
 * The agent's recommended next message — an arrow + underlined accent-tinted text, tappable to
 * send it. Mirrors iOS `followPill` (a bottom accent rule, not a chip pill).
 */
@Composable
private fun FollowRow(follow: String, rtl: Boolean, theme: ResolvedTheme, onTap: () -> Unit) {
    val accentRule = theme.accent.copy(alpha = FOLLOW_RULE_ALPHA)
    Row(
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onTap,
            )
            .padding(bottom = 3.dp)
            .drawBehind {
                val y = size.height
                drawLine(
                    color = accentRule,
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = FOLLOW_RULE_THICKNESS_PX,
                )
            },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = if (rtl) "←" else "→",
            color = theme.accent,
            fontSize = FOLLOW_ARROW_SIZE,
            fontWeight = VoqalType.SEMIBOLD,
        )
        Text(
            text = follow,
            color = theme.textPrimary,
            fontSize = FOLLOW_SIZE,
            fontFamily = VoqalType.DISPLAY,
            fontWeight = VoqalType.MEDIUM,
            letterSpacing = FOLLOW_TRACKING,
        )
    }
}

/** An exchange's base direction: the answer decides, else the question (per-element RTL). */
private fun directionRtl(exchange: Exchange): Boolean {
    val answer = exchange.answerText
    return if (answer.isNotBlank()) directionRtl(answer) else directionRtl(exchange.question ?: "")
}

private fun directionRtl(text: String): Boolean = TextDirection.isRtl(text)

private val STAGE_SPACING = 26.dp
private val EXCHANGE_SPACING = 14.dp
private val QUESTION_SIZE = 14.5.sp
private val QUESTION_TRACKING = (-0.2).sp
private const val INACTIVE_ANSWER_ALPHA = 0.6f
private const val INACTIVE_WIDGET_ALPHA = 0.7f
private val FOLLOW_SIZE = 15.sp
private val FOLLOW_TRACKING = (-0.2).sp
private val FOLLOW_ARROW_SIZE = 13.sp
private const val FOLLOW_RULE_ALPHA = 0.35f
private const val FOLLOW_RULE_THICKNESS_PX = 1.5f
