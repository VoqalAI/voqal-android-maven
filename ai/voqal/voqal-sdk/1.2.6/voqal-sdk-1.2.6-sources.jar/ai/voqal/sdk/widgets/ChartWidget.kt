package ai.voqal.sdk.widgets

import ai.voqal.sdk.model.ChartType
import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.theme.ResolvedTheme
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

private val CHART_HEIGHT = 40.dp
private val BAR_GAP = 6.dp
private val BAR_CORNER = 3.dp
private val MIN_BAR_HEIGHT = 3.dp
private val LINE_STROKE = 2.5.dp
private val RING_STROKE = 10.dp

/**
 * Renders a [Widget.Chart] with a Canvas — no charting library, and no card chrome (matching the
 * bare iOS `ChartWidgetView`). Bars scale to the series max at a fixed 40dp band: the highlight
 * index paints in full accent, every other bar in the hairline tier. Line and ring forms (which
 * the iOS data chart never emits but the model allows) keep an accent stroke for forward-compat.
 */
@Composable
fun ChartWidget(widget: Widget.Chart, theme: ResolvedTheme) {
    if (widget.data.isEmpty()) return
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(CHART_HEIGHT),
    ) {
        when (widget.chartType) {
            ChartType.BARS -> drawBars(widget.data, widget.highlight, theme)
            ChartType.LINE -> drawLine(widget.data, theme)
            ChartType.RING -> drawRing(widget.data.first(), theme)
        }
    }
}

private fun DrawScope.drawBars(data: List<Double>, highlight: Int?, theme: ResolvedTheme) {
    val maxValue = data.max().takeIf { it > 0.0 } ?: 1.0
    val gap = BAR_GAP.toPx()
    val barWidth = (size.width - gap * (data.size - 1)) / data.size
    val minHeight = MIN_BAR_HEIGHT.toPx()
    val cornerRadius = CornerRadius(BAR_CORNER.toPx())
    data.forEachIndexed { index, value ->
        val barHeight = maxOf(minHeight, (value / maxValue).toFloat() * size.height)
        val left = index * (barWidth + gap)
        drawRoundRect(
            color = if (index == highlight) theme.accent else theme.hairline,
            topLeft = Offset(left, size.height - barHeight),
            size = Size(barWidth, barHeight),
            cornerRadius = cornerRadius,
        )
    }
}

private fun DrawScope.drawLine(data: List<Double>, theme: ResolvedTheme) {
    val maxValue = data.max().takeIf { it > 0.0 } ?: 1.0
    val stepX = if (data.size > 1) size.width / (data.size - 1) else 0f
    val path = Path()
    data.forEachIndexed { index, value ->
        val x = index * stepX
        val y = size.height - (value / maxValue).toFloat() * size.height
        if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    drawPath(
        path = path,
        color = theme.accent,
        style = Stroke(width = LINE_STROKE.toPx(), cap = StrokeCap.Round),
    )
}

private fun DrawScope.drawRing(value: Double, theme: ResolvedTheme) {
    val fraction = value.coerceIn(0.0, 1.0).toFloat()
    val stroke = Stroke(width = RING_STROKE.toPx(), cap = StrokeCap.Round)
    val inset = RING_STROKE.toPx()
    val diameter = minOf(size.width, size.height) - inset
    val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
    val arcSize = Size(diameter, diameter)
    drawArc(theme.hairline, -90f, 360f, false, topLeft, arcSize, style = stroke)
    drawArc(theme.accent, -90f, 360f * fraction, false, topLeft, arcSize, style = stroke)
}
