package ai.voqal.sdk.model

import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonClassDiscriminator
import kotlinx.serialization.json.JsonObject

/**
 * A single render-spec widget emitted by the agent in the render tail.
 *
 * Polymorphic on the `"type"` discriminator. Unknown widget types decode to [Unknown]
 * rather than throwing, so a newer engine can ship widget types an older SDK ignores
 * gracefully (forward compatibility). See [RenderSpec] for how the array is decoded.
 */
@OptIn(ExperimentalSerializationApi::class)
@JsonClassDiscriminator(RenderSpec.TYPE_DISCRIMINATOR)
@Serializable
sealed class Widget {

    /**
     * A single key metric. e.g. "Balance · 1,200 EGP · +3%".
     *
     * @property label Human-readable metric name.
     * @property value Formatted value string (already localized by the agent).
     * @property delta Optional change indicator (e.g. `"+3%"`).
     * @property trend Optional direction hint for styling the delta.
     */
    @Serializable
    @SerialName("stat")
    data class Stat(
        val label: String,
        val value: String,
        val delta: String? = null,
        val trend: Trend? = null,
    ) : Widget()

    /**
     * A titled list of rows (e.g. recent transactions).
     *
     * @property title Optional section title.
     * @property rows The list rows, rendered top to bottom.
     */
    @Serializable
    @SerialName("list")
    data class ListWidget(
        val title: String? = null,
        val rows: List<ListRow> = emptyList(),
    ) : Widget()

    /**
     * A details card: a title over label/value pairs with an optional footer.
     *
     * @property title Card title.
     * @property rows Label/value pairs, each `[label, value]`.
     * @property footer Optional footer note.
     */
    @Serializable
    @SerialName("card")
    data class Card(
        val title: String,
        val rows: List<List<String>> = emptyList(),
        val footer: String? = null,
    ) : Widget()

    /**
     * A multi-step progress indicator (e.g. settlement in progress).
     *
     * @property title Progress title.
     * @property value Fractional completion in `0.0..1.0`.
     * @property steps Names of the steps, in order.
     * @property stepActive Index of the currently active step (0-based).
     * @property eta Optional human-readable estimate (e.g. `"~2 min"`).
     */
    @Serializable
    @SerialName("progress")
    data class Progress(
        val title: String,
        val value: Double = 0.0,
        val steps: List<String> = emptyList(),
        @SerialName("stepActive") val stepActive: Int? = null,
        val eta: String? = null,
    ) : Widget()

    /**
     * A small data visualization.
     *
     * @property chartType Visual form: `"bars"`, `"line"`, or `"ring"`.
     * @property data The numeric series to plot.
     * @property highlight Optional index of a data point to emphasize.
     */
    @Serializable
    @SerialName("chart")
    data class Chart(
        @SerialName("chartType") val chartType: ChartType,
        val data: List<Double> = emptyList(),
        val highlight: Int? = null,
    ) : Widget()

    /**
     * A block of Markdown prose.
     *
     * @property text Markdown source. The renderer supports a safe subset.
     */
    @Serializable
    @SerialName("markdown")
    data class Markdown(
        val text: String,
    ) : Widget()

    /**
     * A confirmation card gating an action. Tapping the CTA runs [execute] via
     * `/voqal/execute`, after biometric auth when [requiresBiometric] is true.
     *
     * @property title Confirm title (e.g. "Send 500 EGP?").
     * @property rows Label/value detail pairs shown above the CTA.
     * @property cta Action button label.
     * @property execute Opaque action payload the engine replays on confirm. The SDK passes
     *   it through unchanged; it must not be inspected or mutated by the client.
     * @property requiresBiometric When true, the SDK requires device biometric/credential
     *   auth before executing (high-risk actions only).
     */
    @Serializable
    @SerialName("confirm")
    data class Confirm(
        val title: String,
        val rows: List<List<String>> = emptyList(),
        val price: String? = null,
        val cta: String? = null,
        val execute: JsonObject,
        @SerialName("requiresBiometric") val requiresBiometric: Boolean = false,
    ) : Widget()

    /**
     * A shoppable list of products, each with a thumbnail, price, quantity stepper, and an
     * "Add" button. Tapping Add silently runs the MCP `add_to_cart` tool via `/voqal/execute`
     * (no chat bubble, no agent turn).
     *
     * @property title Optional eyebrow title above the list.
     * @property items The products, rendered top to bottom (hairline-separated).
     */
    @Serializable
    @SerialName("products")
    data class Products(
        val title: String? = null,
        val items: List<ProductItem> = emptyList(),
    ) : Widget()

    /**
     * Fallback for any `"type"` the SDK does not recognize. Rendered as nothing.
     * Lets a newer engine add widgets without breaking older clients.
     */
    @Serializable
    @SerialName("__unknown__")
    data object Unknown : Widget()
}

/**
 * A single purchasable product in a [Widget.Products] list.
 *
 * @property id Stable product identifier sent to the `add_to_cart` tool.
 * @property name Display name (wraps up to two lines).
 * @property price Formatted, already-localized price string.
 * @property size Optional variant/size note (e.g. `"500g"`).
 * @property image Optional thumbnail URL; absent shows a hairline placeholder.
 */
@Serializable
data class ProductItem(
    val id: String,
    val name: String,
    val price: String,
    val size: String? = null,
    val image: String? = null,
)

/** A single row in a [Widget.ListWidget]. */
@Serializable
data class ListRow(
    val title: String,
    val meta: String? = null,
    val trailing: String? = null,
)

/** Direction hint for a [Widget.Stat] delta. */
@Serializable
enum class Trend {
    @SerialName("up") UP,

    @SerialName("down") DOWN,

    @SerialName("flat") FLAT,
}

/** Visual form for a [Widget.Chart]. */
@Serializable
enum class ChartType {
    @SerialName("bars") BARS,

    @SerialName("line") LINE,

    @SerialName("ring") RING,
}
