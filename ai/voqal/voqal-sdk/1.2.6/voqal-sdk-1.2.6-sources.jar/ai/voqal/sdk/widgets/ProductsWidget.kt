package ai.voqal.sdk.widgets

import ai.voqal.sdk.model.ProductItem
import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.theme.ResolvedTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/**
 * Renders a [Widget.Products]: an optional eyebrow title over hairline-separated product rows,
 * each with a thumbnail, name, price, an optional size, a quantity stepper, and an "Add" button.
 *
 * Faithful port of the iOS `ProductsWidgetView`/`ProductRow`. Tapping "Add" forwards the product
 * id and chosen quantity to [onAddToCart]; the row then shows "Added ✓" and disables, while the
 * caller performs a silent `add_to_cart` (no chat bubble, no agent turn).
 *
 * @param widget The products payload to render.
 * @param theme Resolved colors/shape.
 * @param onAddToCart Invoked with `(productId, quantity)` when an "Add" button is tapped; null
 *   leaves the button inert.
 */
@Composable
fun ProductsWidget(
    widget: Widget.Products,
    theme: ResolvedTheme,
    onAddToCart: ((String, Int) -> Unit)?,
) {
    WidgetSurface(theme, theme.surface) {
        Column(Modifier.padding(WidgetTokens.CARD_PADDING)) {
            widget.title?.let { title ->
                Eyebrow(title, theme, Modifier.padding(bottom = 10.dp))
            }
            widget.items.forEachIndexed { index, item ->
                if (index > 0) Hairline(theme)
                ProductRow(item, theme, onAddToCart)
            }
        }
    }
}

@Composable
private fun ProductRow(
    item: ProductItem,
    theme: ResolvedTheme,
    onAddToCart: ((String, Int) -> Unit)?,
) {
    // Per-product stepper/added state, keyed by id so it resets when the row is recycled.
    var quantity by remember(item.id) { mutableIntStateOf(1) }
    var added by remember(item.id) { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ROW_VERTICAL_PADDING),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumbnail(item.image, theme)
        Spacer(Modifier.width(12.dp))
        ProductDetails(item, theme, Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Column(
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            QuantityStepper(
                quantity = quantity,
                theme = theme,
                onDecrement = { if (quantity > 1) quantity -= 1 },
                onIncrement = { quantity += 1 },
            )
            AddButton(added, theme) {
                added = true
                onAddToCart?.invoke(item.id, quantity)
            }
        }
    }
}

@Composable
private fun Thumbnail(image: String?, theme: ResolvedTheme) {
    val shape = RoundedCornerShape(THUMBNAIL_RADIUS)
    Box(
        modifier = Modifier
            .size(THUMBNAIL_SIZE)
            .clip(shape)
            .background(theme.hairline, shape)
            .border(WidgetTokens.HAIRLINE_THICKNESS, theme.hairline, shape),
    ) {
        if (image != null) {
            AsyncImage(
                model = image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
private fun ProductDetails(item: ProductItem, theme: ResolvedTheme, modifier: Modifier) {
    Column(modifier) {
        DirectionalText(
            text = item.name,
            color = theme.textPrimary,
            fontSize = NAME_SIZE,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
        )
        Spacer(Modifier.height(3.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            DirectionalText(
                text = item.price,
                color = theme.accent,
                fontSize = PRICE_SIZE,
                fontWeight = FontWeight.SemiBold,
                mono = true,
            )
            item.size?.let { size ->
                DirectionalText(
                    text = size,
                    color = theme.textTertiary,
                    fontSize = SIZE_SIZE,
                    mono = true,
                )
            }
        }
    }
}

@Composable
private fun QuantityStepper(
    quantity: Int,
    theme: ResolvedTheme,
    onDecrement: () -> Unit,
    onIncrement: () -> Unit,
) {
    val capsule = RoundedCornerShape(percent = 50)
    Row(
        modifier = Modifier
            .clip(capsule)
            .border(STEPPER_BORDER, theme.hairline, capsule),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StepGlyph(MINUS_GLYPH, theme, STEP_MINUS_LABEL, onDecrement)
        Text(
            text = "$quantity",
            color = theme.textPrimary,
            fontSize = QTY_SIZE,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(min = QTY_MIN_WIDTH),
        )
        StepGlyph(PLUS_GLYPH, theme, STEP_PLUS_LABEL, onIncrement)
    }
}

@Composable
private fun StepGlyph(glyph: String, theme: ResolvedTheme, label: String, onTap: () -> Unit) {
    Box(
        modifier = Modifier
            .size(width = STEP_WIDTH, height = STEP_HEIGHT)
            .clickable(onClick = onTap)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = glyph,
            color = theme.textPrimary,
            fontSize = STEP_GLYPH_SIZE,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun AddButton(added: Boolean, theme: ResolvedTheme, onTap: () -> Unit) {
    val capsule = RoundedCornerShape(percent = 50)
    val background = if (added) theme.textTertiary else theme.accent
    Box(
        modifier = Modifier
            .clip(capsule)
            .background(background, capsule)
            .clickable(enabled = !added, onClick = onTap)
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .semantics { contentDescription = if (added) ADDED_LABEL else ADD_LABEL },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (added) ADDED_TEXT else ADD_TEXT,
            color = Color.White,
            fontSize = ADD_SIZE,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
        )
    }
}

private val ROW_VERTICAL_PADDING = 10.dp
private val THUMBNAIL_SIZE = 54.dp
private val THUMBNAIL_RADIUS = 11.dp
private val NAME_SIZE = 15.sp
private val PRICE_SIZE = 12.5.sp
private val SIZE_SIZE = 10.sp
private val QTY_SIZE = 14.sp
private val QTY_MIN_WIDTH = 24.dp
private val STEP_WIDTH = 30.dp
private val STEP_HEIGHT = 28.dp
private val STEP_GLYPH_SIZE = 11.sp
private val STEPPER_BORDER = 0.6.dp
private val ADD_SIZE = 11.sp

private const val MINUS_GLYPH = "−"
private const val PLUS_GLYPH = "+"
private const val ADD_TEXT = "Add"
private const val ADDED_TEXT = "Added ✓"

// Accessibility labels.
private const val STEP_MINUS_LABEL = "Decrease quantity"
private const val STEP_PLUS_LABEL = "Increase quantity"
private const val ADD_LABEL = "Add to cart"
private const val ADDED_LABEL = "Added to cart"
