package ai.voqal.sdk.security

import java.math.BigInteger
import java.security.MessageDigest
import java.security.interfaces.ECPublicKey

/**
 * Encodes an EC P-256 public key as a JWK and computes its RFC 7638 thumbprint.
 *
 * The wire contract requires the `x`/`y` coordinates to be the raw 32-byte big-endian field
 * elements, base64url-encoded without padding — NOT the variable-length two's-complement
 * encoding [BigInteger.toByteArray] produces. [coordinate] normalizes to exactly 32 bytes.
 */
internal object EcJwk {

    private const val KEY_TYPE = "EC"
    private const val CURVE = "P-256"
    private const val COORDINATE_BYTES = 32

    /**
     * Build the public JWK for a P-256 key.
     *
     * @param publicKey The EC public key. Must be a P-256 key.
     * @return An ordered JWK map `{kty, crv, x, y}` with base64url-nopad 32-byte coordinates.
     */
    fun publicJwk(publicKey: ECPublicKey): Map<String, String> {
        val point = publicKey.w
        return linkedMapOf(
            "kty" to KEY_TYPE,
            "crv" to CURVE,
            "x" to Base64Url.encode(coordinate(point.affineX)),
            "y" to Base64Url.encode(coordinate(point.affineY)),
        )
    }

    /**
     * Compute the RFC 7638 JWK thumbprint: base64url(SHA-256(canonical JWK JSON)).
     *
     * The canonical form is the required members in lexicographic order with no whitespace:
     * `{"crv":"P-256","kty":"EC","x":"...","y":"..."}`.
     *
     * @param publicKey The EC public key.
     * @return The base64url-encoded SHA-256 thumbprint.
     */
    fun thumbprint(publicKey: ECPublicKey): String {
        val jwk = publicJwk(publicKey)
        val canonical = """{"crv":"${jwk["crv"]}","kty":"${jwk["kty"]}",""" +
            """"x":"${jwk["x"]}","y":"${jwk["y"]}"}"""
        val digest = MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
        return Base64Url.encode(digest)
    }

    /**
     * Convert a field coordinate to a fixed-width 32-byte big-endian array.
     *
     * Strips the sign byte [BigInteger.toByteArray] may prepend and left-pads short values
     * with zeros so the coordinate is always exactly 32 bytes.
     */
    private fun coordinate(value: BigInteger): ByteArray {
        val raw = value.toByteArray()
        return when {
            raw.size == COORDINATE_BYTES -> raw
            raw.size == COORDINATE_BYTES + 1 && raw[0].toInt() == 0 ->
                raw.copyOfRange(1, raw.size)
            raw.size < COORDINATE_BYTES -> ByteArray(COORDINATE_BYTES).also { padded ->
                System.arraycopy(raw, 0, padded, COORDINATE_BYTES - raw.size, raw.size)
            }
            else -> throw IllegalArgumentException(
                "EC coordinate is ${raw.size} bytes, expected at most ${COORDINATE_BYTES + 1}"
            )
        }
    }
}
