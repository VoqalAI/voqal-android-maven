package ai.voqal.sdk.experience

/**
 * The assistant's interaction phase. Drives orb animation, mic state, and which controls are
 * live. Mirrors the iOS experience phase machine.
 *
 * Transitions:
 * `Idle -> Listening` (user starts voice) `-> Transcribing` (clip sent to STT)
 * `-> Thinking` (agent turn running) `-> Speaking` (answer/TTS playing) `-> Idle`.
 * Barge-in: starting voice from [Speaking] cancels playback and returns to [Listening].
 */
enum class VoqalPhase {
    /** No active turn; home glance / resting orb. */
    Idle,

    /** Microphone capturing the user's clip. */
    Listening,

    /** Clip sent; awaiting transcript from STT. */
    Transcribing,

    /** Agent turn in flight. */
    Thinking,

    /** Answer rendering and/or TTS playing. */
    Speaking,
}
