package ai.voqal.sdk.voice

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Pure WAV (canonical 44-byte RIFF/PCM) assembly. No Android dependencies, so the header
 * math is JVM-unit-testable.
 *
 * Layout (little-endian sizes at the two load-bearing offsets):
 * - offset 4:  `fileSize - 8`  (RIFF chunk size = 36 + dataSize)
 * - offset 40: `dataSize`      (the PCM payload length in bytes)
 */
internal object WavFormat {

    /** A WAV file = 44-byte header + the raw PCM16 payload. */
    fun wrap(pcm: ByteArray): ByteArray =
        buildHeader(pcm.size) + pcm

    /**
     * Build the 44-byte canonical WAV header for a PCM payload of [dataSize] bytes.
     *
     * @param dataSize Length of the PCM payload in bytes (must be `>= 0`).
     */
    fun buildHeader(dataSize: Int): ByteArray {
        require(dataSize >= 0) { "WAV dataSize must be non-negative, was $dataSize" }

        val channels = WavRecorder.CHANNEL_COUNT
        val sampleRate = WavRecorder.SAMPLE_RATE_HZ
        val bitsPerSample = WavRecorder.BITS_PER_SAMPLE
        val byteRate = sampleRate * channels * bitsPerSample / BITS_PER_BYTE
        val blockAlign = channels * bitsPerSample / BITS_PER_BYTE

        return ByteBuffer.allocate(WavRecorder.WAV_HEADER_BYTES)
            .order(ByteOrder.LITTLE_ENDIAN)
            .put(RIFF_TAG)
            .putInt(RIFF_CHUNK_OVERHEAD + dataSize)
            .put(WAVE_TAG)
            .put(FMT_TAG)
            .putInt(FMT_CHUNK_SIZE)
            .putShort(PCM_FORMAT)
            .putShort(channels.toShort())
            .putInt(sampleRate)
            .putInt(byteRate)
            .putShort(blockAlign.toShort())
            .putShort(bitsPerSample.toShort())
            .put(DATA_TAG)
            .putInt(dataSize)
            .array()
    }

    private const val BITS_PER_BYTE = 8

    /** Bytes in the header that precede the PCM payload, minus the leading `RIFF<size>`. */
    private const val RIFF_CHUNK_OVERHEAD = 36

    private const val FMT_CHUNK_SIZE = 16
    private const val PCM_FORMAT: Short = 1

    private val RIFF_TAG = "RIFF".toByteArray(Charsets.US_ASCII)
    private val WAVE_TAG = "WAVE".toByteArray(Charsets.US_ASCII)
    private val FMT_TAG = "fmt ".toByteArray(Charsets.US_ASCII)
    private val DATA_TAG = "data".toByteArray(Charsets.US_ASCII)
}
