package ai.voqal.sdk.experience

import ai.voqal.sdk.transport.RenderEvent
import ai.voqal.sdk.voice.WavRecorder
import kotlinx.coroutines.flow.Flow

/**
 * Opens one voice turn for a base64 WAV clip and streams its [RenderEvent]s.
 *
 * A seam over [ai.voqal.sdk.voice.VoiceSocket] so [VoqalExperienceViewModel] depends on a
 * narrow contract (and tests supply a fake flow). The production adapter builds a fresh socket
 * per turn (`VoiceSocket.connect(...).run(audio, requestTts = true)`), reading the live token
 * from the delegate so the socket always carries fresh auth.
 */
fun interface VoiceTurnRunner {

    /**
     * Stream one voice turn.
     *
     * @param audioBase64 The recorded clip as base64 WAV.
     * @return A cold [Flow] of render events for the turn (voice-in implies voice-out TTS).
     */
    fun run(audioBase64: String): Flow<RenderEvent>
}

/**
 * Creates a fresh [WavRecorder] per clip.
 *
 * The recorder must never be reused across clips (Android invalidates the audio session on a
 * background/foreground cycle), so the experience layer asks for a new one on every
 * [VoqalExperienceViewModel.startVoice].
 */
fun interface RecorderFactory {

    /** @return A new, unstarted [WavRecorder]. */
    fun create(): WavRecorder
}

/** Wall-clock source for the conversation retainer, injectable so tests can advance time. */
fun interface ExperienceClock {

    /** @return The current time in milliseconds since the epoch. */
    fun nowMillis(): Long

    companion object {
        /** The default system clock. */
        val SYSTEM: ExperienceClock = ExperienceClock { System.currentTimeMillis() }
    }
}
