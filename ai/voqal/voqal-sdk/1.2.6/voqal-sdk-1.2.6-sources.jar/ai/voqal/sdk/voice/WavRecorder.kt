package ai.voqal.sdk.voice

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.ByteArrayOutputStream
import kotlin.coroutines.coroutineContext

/**
 * Records a single microphone clip as a 16 kHz, PCM 16-bit, mono WAV held in memory.
 *
 * Critical lifecycle rule (mirrors the iOS SDK gotcha): a **fresh [AudioSource] is created
 * per clip and released on [stop]**. An `AudioSource` (and the `AudioRecord` behind it) is
 * never cached across a background/foreground cycle — Android may silently invalidate the
 * audio session, yielding empty or corrupt buffers. Each [start]/[stop] pair owns its own
 * source.
 *
 * The capture loop runs on [Dispatchers.IO] under a [Job] and is cancellation-safe: [stop]
 * cancels it and releases the source in a `finally`, so the native resource is freed even if
 * a read throws.
 *
 * Android-specific surface is confined to [start]; the WAV assembly ([WavFormat]) and the
 * waveform amplitude ([PcmAmplitude]) are pure and unit-testable through the [AudioSource]
 * seam.
 *
 * @param audioSourceFactory Creates a new [AudioSource] per clip. Defaults to the real
 *   `AudioRecord`-backed source; tests inject a fake.
 */
class WavRecorder(
    private val audioSourceFactory: () -> AudioSource = { AndroidAudioSource() },
) {

    private val _amplitude = MutableStateFlow(0f)

    /** Recent normalized peak amplitude (`0f..1f`) for the live UI waveform. */
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val recordedPcm = ByteArrayOutputStream()
    private val lock = Any()

    private var captureJob: Job? = null
    private var audioSource: AudioSource? = null

    /**
     * Begin recording a new clip. Allocates a fresh [AudioSource] and starts the capture
     * loop on [Dispatchers.IO].
     *
     * @param context Host context, reserved for future capture configuration. Nullable so
     *   the capture loop is unit-testable on the JVM through the [AudioSource] seam without a
     *   real Android `Context`; production callers always pass one.
     * @throws IllegalStateException if a recording is already in progress, or the audio
     *   source fails to initialize.
     * @throws SecurityException if `RECORD_AUDIO` has not been granted.
     */
    @Suppress("UNUSED_PARAMETER")
    fun start(context: Context? = null) {
        check(captureJob == null) { "WavRecorder.start called while already recording" }

        recordedPcm.reset()
        _amplitude.value = 0f

        val source = audioSourceFactory()
        check(source.isInitialized) {
            "AudioSource failed to initialize (mic unavailable or session invalidated)"
        }
        audioSource = source

        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        captureJob = scope.launch { captureLoop(source) }
    }

    /**
     * Stop the current recording and return the captured clip as complete WAV bytes.
     *
     * Always releases the [AudioSource] (via a `finally`). Safe to call without a prior
     * [start] — it returns an empty [ByteArray] and does nothing.
     *
     * @return The complete WAV file bytes (44-byte header + PCM16 mono samples), or an empty
     *   array if no recording was in progress.
     */
    fun stop(): ByteArray {
        val job = captureJob ?: return ByteArray(0)

        try {
            runBlocking { job.cancelAndJoin() }
        } finally {
            releaseSource()
            captureJob = null
            _amplitude.value = 0f
        }

        return synchronized(lock) { WavFormat.wrap(recordedPcm.toByteArray()) }
    }

    /** Whether a recording is currently in progress. */
    fun isRecording(): Boolean = captureJob != null

    private suspend fun captureLoop(source: AudioSource) {
        val buffer = ByteArray(READ_BUFFER_BYTES)
        try {
            source.startRecording()
            while (coroutineContext.isActive) {
                val bytesRead = source.read(buffer)
                if (bytesRead < 0) break
                if (bytesRead == 0) continue
                appendChunk(buffer, bytesRead)
            }
        } finally {
            stopSourceQuietly(source)
        }
    }

    private fun appendChunk(buffer: ByteArray, bytesRead: Int) {
        synchronized(lock) { recordedPcm.write(buffer, 0, bytesRead) }
        _amplitude.value = PcmAmplitude.normalizedPeak(buffer, bytesRead)
    }

    private fun stopSourceQuietly(source: AudioSource) {
        runCatching { source.stop() }
    }

    private fun releaseSource() {
        audioSource?.let { source -> runCatching { source.release() } }
        audioSource = null
    }

    companion object {
        const val SAMPLE_RATE_HZ: Int = 16_000
        const val CHANNEL_COUNT: Int = 1
        const val BITS_PER_SAMPLE: Int = 16
        const val WAV_HEADER_BYTES: Int = 44

        /** Fixed read-chunk size for the JVM-side loop; the source floors its native buffer. */
        const val READ_BUFFER_BYTES: Int = 4_096
    }
}
