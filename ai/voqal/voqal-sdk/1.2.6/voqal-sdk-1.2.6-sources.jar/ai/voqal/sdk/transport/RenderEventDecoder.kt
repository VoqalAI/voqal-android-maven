package ai.voqal.sdk.transport

import ai.voqal.sdk.model.RenderSpec
import ai.voqal.sdk.model.Widget
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * Maps the engine's named SSE events onto the [RenderEvent] stream.
 *
 * Event contract (the engine sends these names with a JSON `data:` payload):
 * - `speak`    `{"delta": "..."}`            → [RenderEvent.SpeakDelta]
 * - `widgets`  `{"widgets":[...], "suggestions":[...]?}` → [RenderEvent.Widgets]
 * - `follow`   `{"text":"..."}`              → [RenderEvent.Follow] (dropped if text blank)
 * - `done`     `{}`                          → [RenderEvent.Done]
 *
 * Unknown event names decode to null and are ignored so a newer engine can add events
 * without breaking an older SDK. Widget types the SDK doesn't recognize decode to
 * [Widget.Unknown] (handled by [RenderSpec.json]).
 */
object RenderEventDecoder {

    const val EVENT_SPEAK: String = "speak"
    const val EVENT_WIDGETS: String = "widgets"
    const val EVENT_FOLLOW: String = "follow"
    const val EVENT_DONE: String = "done"

    private const val FIELD_DELTA = "delta"
    private const val FIELD_TEXT = "text"
    private const val FIELD_WIDGETS = "widgets"
    private const val FIELD_SUGGESTIONS = "suggestions"

    /**
     * Decode one SSE event into a [RenderEvent], or null if it carries no event.
     *
     * @param sse The dispatched SSE event (name + JSON data).
     * @return The mapped [RenderEvent], or null for unknown names and blank-follow frames.
     * @throws kotlinx.serialization.SerializationException If a known event's data is not the
     *   expected JSON shape.
     */
    fun decode(sse: SseEvent): RenderEvent? = when (sse.event) {
        EVENT_SPEAK -> RenderEvent.SpeakDelta(stringField(sse.data, FIELD_DELTA))
        EVENT_WIDGETS -> decodeWidgets(sse.data)
        EVENT_FOLLOW -> decodeFollow(sse.data)
        EVENT_DONE -> RenderEvent.Done
        else -> null
    }

    private fun decodeFollow(data: String): RenderEvent? {
        val text = stringField(data, FIELD_TEXT)
        return if (text.isBlank()) null else RenderEvent.Follow(text)
    }

    private fun decodeWidgets(data: String): RenderEvent.Widgets {
        val payload = RenderSpec.json.decodeFromString(JsonObject.serializer(), data)
        val widgetsElement = payload[FIELD_WIDGETS]
        val widgets = if (widgetsElement == null) {
            emptyList<Widget>()
        } else {
            RenderSpec.json.decodeFromJsonElement(ListSerializer(Widget.serializer()), widgetsElement)
        }
        val suggestionsElement = payload[FIELD_SUGGESTIONS]
        val suggestions = if (suggestionsElement == null) {
            emptyList<String>()
        } else {
            RenderSpec.json.decodeFromJsonElement(ListSerializer(String.serializer()), suggestionsElement)
        }
        return RenderEvent.Widgets(widgets, suggestions)
    }

    private fun stringField(data: String, field: String): String {
        val payload = RenderSpec.json.decodeFromString(JsonObject.serializer(), data)
        return (payload[field] as? JsonPrimitive)?.takeIf { it.isString }?.content ?: ""
    }
}
