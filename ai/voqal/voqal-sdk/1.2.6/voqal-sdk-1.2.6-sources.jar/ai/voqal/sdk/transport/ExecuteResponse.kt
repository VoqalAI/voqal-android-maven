package ai.voqal.sdk.transport

import ai.voqal.sdk.model.RenderSpec
import ai.voqal.sdk.model.Widget
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * The decoded result of a confirmed action (`POST /voqal/execute`).
 *
 * The wire shape is `{"done": {...}, "speak": "...?", "widgets": [...]?}`. It is modeled
 * tolerantly: [raw] preserves the full response so callers can read engine-specific fields
 * the SDK doesn't yet know about, while [done], [speak], and [widgets] expose the common
 * fields already parsed.
 *
 * @property raw The full response object, unchanged. Source of truth for unknown fields.
 * @property done The `done` object (action outcome), or null if the engine omitted it.
 * @property speak The optional spoken confirmation message.
 * @property widgets The optional widgets to render after the action (unknown types drop to
 *   [Widget.Unknown]).
 */
data class ExecuteResponse(
    val raw: JsonObject,
    val done: JsonObject?,
    val speak: String?,
    val widgets: List<Widget>,
) {
    companion object {
        private const val FIELD_DONE = "done"
        private const val FIELD_SPEAK = "speak"
        private const val FIELD_WIDGETS = "widgets"

        /**
         * Decode an execute response from its raw JSON body.
         *
         * @param body The full response body text.
         * @return The parsed [ExecuteResponse]; absent optional fields become null/empty.
         * @throws kotlinx.serialization.SerializationException If [body] is not a JSON object.
         */
        fun decode(body: String): ExecuteResponse {
            val raw = RenderSpec.json.decodeFromString(JsonObject.serializer(), body)
            return ExecuteResponse(
                raw = raw,
                done = raw[FIELD_DONE] as? JsonObject,
                speak = (raw[FIELD_SPEAK] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                widgets = decodeWidgets(raw),
            )
        }

        private fun decodeWidgets(raw: JsonObject): List<Widget> {
            val widgetsElement = raw[FIELD_WIDGETS] ?: return emptyList()
            return RenderSpec.json.decodeFromJsonElement(
                kotlinx.serialization.builtins.ListSerializer(Widget.serializer()),
                widgetsElement,
            )
        }
    }
}
