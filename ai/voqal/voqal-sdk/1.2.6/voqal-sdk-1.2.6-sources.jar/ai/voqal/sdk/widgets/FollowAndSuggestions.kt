package ai.voqal.sdk.widgets

import ai.voqal.sdk.theme.ResolvedTheme
import ai.voqal.sdk.theme.TextDirection
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val UNDERLINE_ALPHA = 0.35f
private val FOLLOW_SIZE = 15.sp
private val FOLLOW_TRACKING = (-0.2).sp
private val FOLLOW_ARROW_SIZE = 16.dp
private val UNDERLINE_HEIGHT = 1.5.dp

private val SUGGESTION_SIZE = 19.sp
private val SUGGESTION_TRACKING = (-0.4).sp
private val SUGGESTION_ARROW_SIZE = 18.dp
private val SUGGESTION_ROW_PADDING = 15.dp

/**
 * The agent's recommended next message, shown under an answer. Ported 1:1 from the iOS
 * `StageView.followPill`: a leading accent arrow + the prompt in the primary tier with an
 * accent underline — not a filled chip. Tapping sends [text] as the next user message.
 *
 * @param text The follow-up prompt text (always non-empty; empty follows are dropped upstream).
 * @param theme The resolved theme.
 * @param onTap Invoked with [text] when tapped.
 */
@Composable
fun FollowPill(
    text: String,
    theme: ResolvedTheme,
    onTap: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .wrapContentWidth()
            .clickable { onTap(text) },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = theme.accent,
                modifier = Modifier.size(FOLLOW_ARROW_SIZE),
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = text,
                color = theme.textPrimary,
                fontSize = FOLLOW_SIZE,
                fontWeight = FontWeight.Medium,
                letterSpacing = FOLLOW_TRACKING,
                style = TextStyle(textDirection = composeDirectionOf(text)),
            )
        }
        Spacer(Modifier.height(3.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(UNDERLINE_HEIGHT)
                .background(theme.accent.copy(alpha = UNDERLINE_ALPHA)),
        )
    }
}

/**
 * The "Try saying" suggestion list. Ported from the iOS `HomeGlanceView.SuggestionRow`: each
 * prompt is a full-width, hairline-separated row of quoted text with a trailing arrow — not a
 * wrapping chip cluster. The arrow stays on the trailing edge for both LTR and RTL prompts.
 *
 * @param suggestions The suggestion prompts. Empty list renders nothing.
 * @param theme The resolved theme.
 * @param onTap Invoked with the tapped suggestion as the next user message.
 */
@Composable
fun SuggestionChips(
    suggestions: List<String>,
    theme: ResolvedTheme,
    onTap: (String) -> Unit,
) {
    if (suggestions.isEmpty()) return
    Column(Modifier.fillMaxWidth()) {
        suggestions.forEach { suggestion ->
            SuggestionRow(suggestion, theme, onTap)
        }
    }
}

@Composable
private fun SuggestionRow(
    text: String,
    theme: ResolvedTheme,
    onTap: (String) -> Unit,
) {
    val rtl = TextDirection.of(text) == TextDirection.Direction.RTL
    Column(
        Modifier
            .fillMaxWidth()
            .clickable { onTap(text) },
    ) {
        Hairline(theme)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = SUGGESTION_ROW_PADDING),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = quotedText(text, theme),
                fontSize = SUGGESTION_SIZE,
                fontWeight = FontWeight.Medium,
                letterSpacing = SUGGESTION_TRACKING,
                textAlign = if (rtl) TextAlign.End else TextAlign.Start,
                style = TextStyle(textDirection = composeDirectionOf(text)),
                modifier = Modifier.weight(1f),
            )
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = theme.textTertiary,
                modifier = Modifier.size(SUGGESTION_ARROW_SIZE),
            )
        }
    }
}

/** Builds the quoted prompt: tertiary-tinted curly quotes around the primary-tinted text. */
private fun quotedText(text: String, theme: ResolvedTheme) = buildAnnotatedString {
    withStyle(SpanStyle(color = theme.textTertiary)) { append("“") }
    withStyle(SpanStyle(color = theme.textPrimary)) { append(text) }
    withStyle(SpanStyle(color = theme.textTertiary)) { append("”") }
}
