package ai.voqal.sdk.experience

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * The three dock glyphs drawn as vector paths inside a [DrawScope], matching the iOS SF
 * Symbols used in `VoiceDock` (`keyboard`, `mic.fill`, `arrow.up`). Drawn directly rather than
 * pulling in the extended material-icons font, so weights and colors track the resolved theme.
 *
 * Each function fills the full [DrawScope.size]; callers place them in a sized `Canvas`.
 */

/** A rounded-rectangle keyboard outline with key dots (iOS `keyboard`, regular weight). */
fun DrawScope.drawKeyboard(tint: Color) {
    val outline = Stroke(width = size.minDimension * 0.06f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawRoundRect(
        color = tint,
        topLeft = Offset(size.width * 0.10f, size.height * 0.27f),
        size = Size(size.width * 0.80f, size.height * 0.46f),
        cornerRadius = CornerRadius(size.minDimension * 0.10f),
        style = outline,
    )
    val dotRadius = size.minDimension * 0.028f
    val topRowY = size.height * 0.41f
    val midRowY = size.height * 0.50f
    listOf(0.26f, 0.40f, 0.54f, 0.68f).forEach { fraction ->
        drawCircle(tint, dotRadius, Offset(size.width * fraction, topRowY))
        drawCircle(tint, dotRadius, Offset(size.width * fraction, midRowY))
    }
    drawLine(
        color = tint,
        start = Offset(size.width * 0.34f, size.height * 0.61f),
        end = Offset(size.width * 0.66f, size.height * 0.61f),
        strokeWidth = size.minDimension * 0.05f,
        cap = StrokeCap.Round,
    )
}

/** A filled microphone capsule with a stand (iOS `mic.fill`). */
fun DrawScope.drawMic(tint: Color) {
    val capsuleWidth = size.width * 0.30f
    val capsuleHeight = size.height * 0.44f
    val capsuleLeft = (size.width - capsuleWidth) / 2f
    val capsuleTop = size.height * 0.16f
    val centerX = size.width / 2f
    drawRoundRect(
        color = tint,
        topLeft = Offset(capsuleLeft, capsuleTop),
        size = Size(capsuleWidth, capsuleHeight),
        cornerRadius = CornerRadius(capsuleWidth / 2f),
    )
    val cradleHalf = capsuleWidth * 0.95f
    val cradleTop = capsuleTop + capsuleHeight * 0.55f
    val cradleBottom = size.height * 0.74f
    val cradle = Path().apply {
        moveTo(centerX - cradleHalf, cradleTop)
        cubicTo(
            centerX - cradleHalf, cradleBottom,
            centerX + cradleHalf, cradleBottom,
            centerX + cradleHalf, cradleTop,
        )
    }
    drawPath(cradle, tint, style = Stroke(width = size.minDimension * 0.07f, cap = StrokeCap.Round))
    drawLine(
        color = tint,
        start = Offset(centerX, cradleBottom),
        end = Offset(centerX, size.height * 0.86f),
        strokeWidth = size.minDimension * 0.07f,
        cap = StrokeCap.Round,
    )
}

/** An upward arrow (iOS `arrow.up`, bold). */
fun DrawScope.drawArrowUp(tint: Color) {
    val centerX = size.width / 2f
    val strokeWidth = size.minDimension * 0.13f
    val top = size.height * 0.24f
    val bottom = size.height * 0.76f
    val head = size.width * 0.22f
    drawLine(tint, Offset(centerX, bottom), Offset(centerX, top), strokeWidth = strokeWidth, cap = StrokeCap.Round)
    drawLine(tint, Offset(centerX, top), Offset(centerX - head, top + head), strokeWidth = strokeWidth, cap = StrokeCap.Round)
    drawLine(tint, Offset(centerX, top), Offset(centerX + head, top + head), strokeWidth = strokeWidth, cap = StrokeCap.Round)
}
