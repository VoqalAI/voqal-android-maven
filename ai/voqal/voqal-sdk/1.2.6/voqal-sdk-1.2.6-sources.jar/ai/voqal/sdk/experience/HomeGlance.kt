package ai.voqal.sdk.experience

import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.theme.ResolvedTheme
import ai.voqal.sdk.theme.TextDirection
import ai.voqal.sdk.widgets.WidgetView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDirection as ComposeTextDirection
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.json.JsonObject
import java.util.Calendar

/**
 * The opening glance — a faithful port of iOS `HomeGlanceView`: the hero snapshot card (or a
 * shimmering skeleton while it loads), a time-based two-tone greeting, the snapshot subline, and
 * "Try saying" CTA rows (quoted text + trailing arrow, hairline-separated).
 *
 * On Android the glance is the first [Exchange] (a `question == null` agent turn). Its first
 * widget is the hero card, its [Exchange.answerText] is the subline, and its
 * [Exchange.suggestions] are the CTA prompts.
 *
 * @param exchange The home glance exchange (may be empty while the snapshot loads).
 * @param userName Optional display name for the greeting's second line.
 * @param isLoading True while the snapshot turn is still in flight (drives the skeleton).
 * @param theme Resolved colors.
 * @param onSuggestionTap Invoked with a tapped CTA as the next user message.
 * @param onConfirm Confirm passthrough for the hero widget (unused for glance stats, kept for parity).
 */
@Composable
internal fun HomeGlance(
    exchange: Exchange,
    userName: String?,
    isLoading: Boolean,
    theme: ResolvedTheme,
    onSuggestionTap: (String) -> Unit,
    onConfirm: (JsonObject) -> Unit,
    onAddToCart: (String, Int) -> Unit = { _, _ -> },
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        horizontalAlignment = Alignment.Start,
    ) {
        HeroCard(exchange, isLoading, theme, onConfirm, onAddToCart)
        Greeting(userName, theme)
        Subline(exchange, theme)
        CtaSection(exchange.suggestions, theme, onSuggestionTap)
    }
}

@Composable
private fun HeroCard(
    exchange: Exchange,
    isLoading: Boolean,
    theme: ResolvedTheme,
    onConfirm: (JsonObject) -> Unit,
    onAddToCart: (String, Int) -> Unit,
) {
    val hero = exchange.widgets.firstOrNull()
    when {
        hero != null -> Box(Modifier.padding(bottom = 22.dp)) {
            WidgetView(hero, theme, onConfirm, onAddToCart)
        }
        isLoading -> Column(
            modifier = Modifier.padding(bottom = 22.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Eyebrow("Getting your snapshot", theme)
            SkeletonBlock(theme)
        }
    }
}

@Composable
private fun Greeting(userName: String?, theme: ResolvedTheme) {
    Text(
        text = "${greetingPart()},",
        color = theme.textPrimary,
        fontSize = GREETING_SIZE,
        fontFamily = VoqalType.DISPLAY,
        fontWeight = VoqalType.SEMIBOLD,
        letterSpacing = GREETING_TRACKING,
    )
    if (!userName.isNullOrEmpty()) {
        Text(
            text = "$userName.",
            color = theme.textTertiary,
            fontSize = GREETING_SIZE,
            fontFamily = VoqalType.DISPLAY,
            fontWeight = VoqalType.SEMIBOLD,
            letterSpacing = GREETING_TRACKING,
        )
    }
}

@Composable
private fun Subline(exchange: Exchange, theme: ResolvedTheme) {
    // iOS shows the subline only when the glance actually loaded data (speak + widgets). On
    // Android the equivalent is: the answer text is present and a hero widget rendered.
    val subline = exchange.answerText
    if (subline.isBlank() || exchange.widgets.isEmpty()) return
    Text(
        text = subline,
        color = theme.textSecondary,
        fontSize = SUBLINE_SIZE,
        fontFamily = VoqalType.DISPLAY,
        fontWeight = VoqalType.REGULAR,
        letterSpacing = SUBLINE_TRACKING,
        modifier = Modifier
            .widthIn(max = 300.dp)
            .padding(top = 12.dp),
    )
}

@Composable
private fun CtaSection(
    suggestions: List<String>,
    theme: ResolvedTheme,
    onSuggestionTap: (String) -> Unit,
) {
    if (suggestions.isEmpty()) return
    Box(Modifier.padding(top = 30.dp, bottom = 4.dp)) {
        Eyebrow("Try saying", theme)
    }
    suggestions.forEach { suggestion ->
        SuggestionRow(suggestion, theme) { onSuggestionTap(suggestion) }
    }
    // Closing hairline beneath the last row (matches the trailing Rectangle in iOS).
    Hairline(theme)
}

/** A "Try saying" row: quoted prompt + trailing arrow, with a hairline above. */
@Composable
private fun SuggestionRow(text: String, theme: ResolvedTheme, onTap: () -> Unit) {
    val rtl = TextDirection.isRtl(text)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onTap,
            ),
    ) {
        Hairline(theme)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = quoted(text, theme),
                fontSize = CTA_SIZE,
                fontFamily = VoqalType.DISPLAY,
                fontWeight = VoqalType.MEDIUM,
                letterSpacing = CTA_TRACKING,
                style = TextStyle(
                    textDirection = if (rtl) ComposeTextDirection.Rtl else ComposeTextDirection.Ltr,
                ),
                modifier = Modifier.weight(1f),
            )
            // The arrow stays on the right for every CTA (LTR and RTL alike).
            Text(
                text = ARROW_GLYPH,
                color = theme.textTertiary,
                fontSize = ARROW_SIZE,
            )
        }
    }
}

private fun quoted(text: String, theme: ResolvedTheme): AnnotatedString = buildAnnotatedString {
    withStyle(SpanStyle(color = theme.textTertiary)) { append("“") }
    withStyle(SpanStyle(color = theme.textPrimary)) { append(text) }
    withStyle(SpanStyle(color = theme.textTertiary)) { append("”") }
}

@Composable
private fun Eyebrow(text: String, theme: ResolvedTheme, color: Color = theme.textSecondary) {
    Text(
        text = text.uppercase(),
        color = color,
        fontSize = EYEBROW_SIZE,
        fontFamily = VoqalType.MONO,
        fontWeight = VoqalType.SEMIBOLD,
        letterSpacing = EYEBROW_TRACKING,
    )
}

@Composable
private fun Hairline(theme: ResolvedTheme) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(0.5.dp)
            .background(theme.hairline.copy(alpha = HAIRLINE2_ALPHA)),
    )
}

@Composable
private fun SkeletonBlock(theme: ResolvedTheme) {
    val shape = RoundedCornerShape(theme.cornerRadiusDp.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .height(92.dp)
            .clip(shape)
            .background(theme.surface)
            .border(0.5.dp, theme.hairline, shape),
    )
}

/** The time-based greeting word, matching iOS's hour thresholds (< 12 / < 18 / else). */
private fun greetingPart(): String =
    StageModel.greetingForHour(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))

private val GREETING_SIZE = 34.sp
private val GREETING_TRACKING = (-1).sp
private val SUBLINE_SIZE = 16.sp
private val SUBLINE_TRACKING = (-0.2).sp
private val CTA_SIZE = 19.sp
private val CTA_TRACKING = (-0.4).sp
private val ARROW_SIZE = 16.sp
private val EYEBROW_SIZE = 10.5.sp
private val EYEBROW_TRACKING = 1.2.sp
private const val ARROW_GLYPH = "→"

// iOS uses a distinct `hairline2` token (fainter). The Android ResolvedTheme exposes only one
// `hairline`; the faint variant is ~half its alpha (matching the dark 0.06 vs 0.10 ratio).
private const val HAIRLINE2_ALPHA = 0.6f
