package ai.voqal.sdk.experience

import ai.voqal.sdk.theme.ResolvedTheme
import android.graphics.Bitmap
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private const val SCRIM_ALPHA = 0.48f
private const val SHEET_HEIGHT_FRACTION = 0.96f
private const val DISMISS_DRAG_FRACTION = 0.25f
private const val FLING_VELOCITY_THRESHOLD = 2_400f
private val SHEET_TOP_RADIUS = 28.dp

/**
 * The themed assistant sheet: a dim scrim over a near-full-height card whose every layer is
 * painted with the resolved sheet color (no platform default ever shows through). The header
 * region is the only drag-to-dismiss surface, and the card slides up on first composition.
 *
 * @param model The experience state holder driving phase + exchanges.
 * @param theme Resolved colors/shape for every chrome layer.
 * @param title The brand/host title shown in the header.
 * @param userName Optional display name for the home greeting.
 * @param pinnedCTAs Host-pinned suggestion chips shown on the home glance.
 * @param onDismiss Invoked to close the sheet (drag-down past threshold or close button).
 * @param onRequestMic Ensures RECORD_AUDIO, calling back with the grant result.
 * @param headerIcon Optional brand logo shown in the header in place of the default Voqal orb.
 */
@Composable
fun VoqalSheet(
    model: DefaultVoqalExperienceViewModel,
    theme: ResolvedTheme,
    pinnedCTAs: List<String>,
    onDismiss: () -> Unit,
    onRequestMic: ((Boolean) -> Unit) -> Unit,
    title: String = DEFAULT_TITLE,
    userName: String? = null,
    headerIcon: Bitmap? = null,
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = SCRIM_ALPHA))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss,
            ),
        contentAlignment = Alignment.BottomCenter,
    ) {
        val density = LocalDensity.current
        val sheetHeightPx = with(density) { (maxHeight * SHEET_HEIGHT_FRACTION).toPx() }
        var dragOffsetPx by remember { mutableFloatStateOf(sheetHeightPx) }
        val animatedOffset by animateFloatAsState(dragOffsetPx, label = "sheetOffset")
        val scope = rememberCoroutineScope()

        LaunchedEffect(Unit) { dragOffsetPx = 0f }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(SHEET_HEIGHT_FRACTION)
                .graphicsLayer { translationY = animatedOffset }
                .clip(RoundedCornerShape(topStart = SHEET_TOP_RADIUS, topEnd = SHEET_TOP_RADIUS))
                .background(theme.sheetBackground)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {},
                ),
        ) {
            SheetContent(
                model = model,
                theme = theme,
                title = title,
                userName = userName,
                pinnedCTAs = pinnedCTAs,
                headerIcon = headerIcon,
                onDismiss = onDismiss,
                onRequestMic = onRequestMic,
                onHeaderDrag = { delta -> dragOffsetPx = (dragOffsetPx + delta).coerceAtLeast(0f) },
                onHeaderDragStopped = { velocity ->
                    val dismissed = dragOffsetPx > sheetHeightPx * DISMISS_DRAG_FRACTION ||
                        velocity > FLING_VELOCITY_THRESHOLD
                    if (dismissed) {
                        scope.launch {
                            dragOffsetPx = sheetHeightPx
                            onDismiss()
                        }
                    } else {
                        dragOffsetPx = 0f
                    }
                },
            )
        }
    }
}

@Composable
private fun SheetContent(
    model: DefaultVoqalExperienceViewModel,
    theme: ResolvedTheme,
    title: String,
    userName: String?,
    pinnedCTAs: List<String>,
    headerIcon: Bitmap?,
    onDismiss: () -> Unit,
    onRequestMic: ((Boolean) -> Unit) -> Unit,
    onHeaderDrag: (Float) -> Unit,
    onHeaderDragStopped: (Float) -> Unit,
) {
    val phase by model.phase.collectAsState()
    val exchanges by model.exchanges.collectAsState()
    val amplitude by model.amplitude.collectAsState()
    val context = LocalContext.current

    // History scrolls the stage back to the start; bumped here, consumed by VoqalStage. Held in
    // the UI layer so the frozen ViewModel API stays untouched.
    var scrollToTopSignal by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(theme.sheetBackground),
    ) {
        SheetHeader(
            theme = theme,
            title = title,
            headerIcon = headerIcon,
            showHistory = exchanges.size > 1,
            onHistory = { scrollToTopSignal++ },
            onDismiss = onDismiss,
            onHeaderDrag = onHeaderDrag,
            onHeaderDragStopped = onHeaderDragStopped,
        )
        VoqalStage(
            exchanges = exchanges,
            phase = phase,
            userName = userName,
            theme = theme,
            modifier = Modifier.weight(1f),
            scrollToTopSignal = scrollToTopSignal,
            pinnedCTAs = pinnedCTAs,
            onSuggestionTap = model::send,
            onConfirm = model::confirm,
            onAddToCart = { productId, quantity -> model.addToCart(productId, quantity) },
        )
        VoqalDock(
            phase = phase,
            amplitude = amplitude,
            theme = theme,
            hasPriorExchanges = StageModel.turns(exchanges).isNotEmpty(),
            onTouch = model::touch,
            onStartVoice = {
                onRequestMic { granted ->
                    if (granted) model.startVoice(context) else model.send(MIC_DENIED_PROMPT)
                }
            },
            onStopVoice = model::stopVoiceAndSend,
            onSend = model::send,
        )
    }
}

@Composable
private fun SheetHeader(
    theme: ResolvedTheme,
    title: String,
    headerIcon: Bitmap?,
    showHistory: Boolean,
    onHistory: () -> Unit,
    onDismiss: () -> Unit,
    onHeaderDrag: (Float) -> Unit,
    onHeaderDragStopped: (Float) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(theme.sheetBackground)
            .draggable(
                state = rememberDraggableState { delta -> onHeaderDrag(delta) },
                orientation = Orientation.Vertical,
                onDragStopped = { velocity -> onHeaderDragStopped(velocity) },
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(11.dp))
        Box(
            Modifier
                .width(38.dp)
                .height(5.dp)
                .clip(CircleShape)
                .background(theme.textTertiary.copy(alpha = HANDLE_ALPHA)),
        )
        Spacer(Modifier.height(13.dp))
        HeaderBar(theme, title, headerIcon, showHistory, onHistory, onDismiss)
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun HeaderBar(
    theme: ResolvedTheme,
    title: String,
    headerIcon: Bitmap?,
    showHistory: Boolean,
    onHistory: () -> Unit,
    onDismiss: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (headerIcon != null) HeaderLogo(headerIcon) else BrandOrb(theme)
            Spacer(Modifier.width(9.dp))
            androidx.compose.material3.Text(
                text = title,
                color = theme.textPrimary,
                fontSize = 16.sp,
                fontFamily = VoqalType.DISPLAY,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (showHistory) {
                CircleButton(theme, HISTORY_GLYPH, 13.sp, onHistory)
            }
            CircleButton(theme, CLOSE_GLYPH, 12.sp, onDismiss)
        }
    }
}

/**
 * The default brand mark: an 18dp accent orb with an off-center white radial highlight and a soft
 * accent shadow. The gradient geometry is derived from the actual draw size so it scales with
 * density (highlight at UnitPoint(0.38, 0.34), endRadius 11pt over the 18pt orb).
 */
@Composable
private fun BrandOrb(theme: ResolvedTheme) {
    Box(
        Modifier
            .size(18.dp)
            .shadow(elevation = 5.dp, shape = CircleShape, ambientColor = theme.accent, spotColor = theme.accent)
            .clip(CircleShape)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.White, theme.accent, theme.accent2),
                        center = Offset(size.width * ORB_HIGHLIGHT_FRACTION_X, size.height * ORB_HIGHLIGHT_FRACTION_Y),
                        radius = size.maxDimension * ORB_RADIUS_FRACTION,
                    ),
                )
            },
    )
}

/**
 * The host's brand logo, shown in the header in place of [BrandOrb] when
 * [ai.voqal.sdk.VoqalConfiguration.headerIcon] is set. Rendered WHOLE inside a ~26dp box
 * ([ContentScale.Fit], no corner clip), mirroring iOS — wordmarks and mascot logos aren't round
 * and must not be center-cropped or forced into a squircle.
 */
@Composable
private fun HeaderLogo(bitmap: Bitmap) {
    Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = Modifier.size(HEADER_LOGO_SIZE),
    )
}

@Composable
private fun CircleButton(
    theme: ResolvedTheme,
    glyph: String,
    fontSize: androidx.compose.ui.unit.TextUnit,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(theme.textPrimary.copy(alpha = CIRCLE_BUTTON_ALPHA))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.material3.Text(
            text = glyph,
            color = theme.textSecondary,
            fontSize = fontSize,
            fontWeight = FontWeight.Medium,
        )
    }
}

private val HEADER_LOGO_SIZE = 26.dp

private const val DEFAULT_TITLE = "Voqal"
private const val CLOSE_GLYPH = "✕"
private const val HISTORY_GLYPH = "≡"
private const val MIC_DENIED_PROMPT = "Microphone access is needed for voice. You can type instead."
private const val HANDLE_ALPHA = 0.7f
private const val CIRCLE_BUTTON_ALPHA = 0.06f

// Radial highlight at iOS UnitPoint(0.38, 0.34); endRadius 11pt is 11/18 of the orb's diameter.
private const val ORB_HIGHLIGHT_FRACTION_X = 0.38f
private const val ORB_HIGHLIGHT_FRACTION_Y = 0.34f
private const val ORB_RADIUS_FRACTION = 11f / 18f
