package ai.voqal.sdk.experience

import ai.voqal.sdk.model.Widget

/**
 * One turn in the conversation: the user's input and the agent's rendered answer.
 *
 * Folded incrementally as [ai.voqal.sdk.transport.RenderEvent]s stream in: speak deltas
 * append to [answerText], a widgets frame fills [widgets]/[suggestions], a follow frame fills
 * [follow], and a terminal error fills [error].
 *
 * @property id Stable identifier for list diffing/animation.
 * @property question The user's transcript or typed message; null/blank for an agent-initiated
 *   glance (e.g. the opening home snapshot) or a voice turn before its transcript arrives.
 * @property answerText The agent's spoken/displayed answer text, streamed in incrementally.
 * @property widgets The widgets rendered for this exchange.
 * @property suggestions Follow-up suggestion chips.
 * @property follow Optional single follow-up pill text.
 * @property isVoice Whether this turn originated from voice (drives voice-out/TTS policy).
 * @property error A user-facing error message when the turn failed, else null.
 */
data class Exchange(
    val id: String,
    val question: String?,
    val answerText: String = "",
    val widgets: List<Widget> = emptyList(),
    val suggestions: List<String> = emptyList(),
    val follow: String? = null,
    val isVoice: Boolean = false,
    val error: String? = null,
)
