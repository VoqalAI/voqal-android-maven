package ai.voqal.sdk.experience

import ai.voqal.sdk.VoqalConfiguration
import ai.voqal.sdk.VoqalDelegate
import ai.voqal.sdk.haptics.VoqalHaptics
import ai.voqal.sdk.haptics.VoqalHapticsPlaying
import ai.voqal.sdk.security.KeystoreDeviceKey
import ai.voqal.sdk.security.ProofSigner
import ai.voqal.sdk.security.SessionManager
import ai.voqal.sdk.transport.HttpClients
import ai.voqal.sdk.transport.ProofSignerAdapter
import ai.voqal.sdk.transport.SessionManagerStore
import ai.voqal.sdk.transport.VoqalClient
import ai.voqal.sdk.transport.VoqalEndpoint
import ai.voqal.sdk.voice.VoiceSocket
import ai.voqal.sdk.voice.WavRecorder
import android.content.Context
import android.os.Build
import android.os.VibratorManager
import okhttp3.OkHttpClient

/**
 * The assembled engine + security stack for one configuration, built once and reused.
 *
 * Wires the concrete security implementations ([SessionManager], [ProofSigner]) behind the
 * transport's narrow seams and exposes the collaborators the experience layer needs:
 * a [VoqalClient], a per-clip [VoiceTurnRunner], and a [RecorderFactory]. The live [delegate]
 * is held here (not passed through an Intent) so [VoqalSheetActivity] can read fresh
 * credentials.
 *
 * @property config The configuration this stack was built for.
 * @property delegate The host bridge supplying live token/metadata and callbacks.
 * @property client The engine HTTP/SSE client.
 * @property sessionManager Owns the session token lifecycle (used to warm + read session id).
 */
internal class VoqalSession private constructor(
    val config: VoqalConfiguration,
    val delegate: VoqalDelegate,
    private val endpoint: VoqalEndpoint,
    private val httpClient: OkHttpClient,
    val sessionManager: SessionManager,
    val client: VoqalClient,
) {

    /** Open the session ahead of a real turn so the first turn skips the cold start. */
    suspend fun prewarm() {
        client.prewarm()
    }

    /** A runner that builds a fresh voice socket per clip, reading the live token each time. */
    fun voiceTurnRunner(): VoiceTurnRunner = VoiceTurnRunner { audioBase64 ->
        VoiceSocket.connect(
            endpoint = endpoint,
            httpClient = httpClient,
            token = delegate.getToken(),
            apiKey = config.apiKey.orEmpty(),
            requestId = config.requestId,
            clientMetadata = delegate.getMetadata(),
            sessionId = sessionManager.currentSessionId(),
        ).run(audioBase64, requestTts = false)  // TTS disabled platform-wide — never bill synthesis
    }

    /** A factory for fresh per-clip recorders (never reuse a recorder across clips). */
    fun recorderFactory(): RecorderFactory = RecorderFactory { WavRecorder() }

    /** Build the device-backed haptics, honoring the host's haptics-enabled flag. */
    fun haptics(context: Context): VoqalHapticsPlaying =
        VoqalHaptics(resolveVibrator(context), enabled = config.hapticsEnabled)

    private fun resolveVibrator(context: Context) =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(VibratorManager::class.java))?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(android.os.Vibrator::class.java)
        }

    companion object {
        /**
         * Build a stack for [config] + [delegate]. The OkHttp client is connection-pooled and
         * shared across turns, execute, and session bootstrap.
         */
        fun build(config: VoqalConfiguration, delegate: VoqalDelegate): VoqalSession {
            val endpoint = VoqalEndpoint(config.agentUrl ?: VoqalEndpoint.DEFAULT_BASE_URL)
            val httpClient = HttpClients.create()
            val deviceKey = KeystoreDeviceKey()
            val sessionManager = SessionManager(
                deviceKey = deviceKey,
                delegate = delegate,
                endpoint = endpoint,
                apiKey = config.apiKey.orEmpty(),
                requestId = config.requestId,
                httpClient = httpClient,
            )
            val client = VoqalClient(
                delegate = delegate,
                sessionStore = SessionManagerStore(sessionManager),
                proofSigner = ProofSignerAdapter(ProofSigner(deviceKey)),
                endpoint = endpoint,
                httpClient = httpClient,
                requestId = config.requestId,
                apiKey = config.apiKey,
            )
            return VoqalSession(config, delegate, endpoint, httpClient, sessionManager, client)
        }
    }
}

/**
 * Process-wide holder for the live [VoqalSession] and the model retainer.
 *
 * [VoqalSheetActivity] cannot receive the session/delegate through an Intent (they are not
 * serializable), so the SDK facade publishes them here and the activity reads them back.
 * The stack is cached and reused while the configuration is unchanged.
 */
internal object VoqalSessionHolder {

    @Volatile
    private var session: VoqalSession? = null

    val retainer = VoqalConversationRetainer()

    /** The currently published session, or null before [ensure]. */
    fun current(): VoqalSession? = session

    /**
     * Return the cached session if it matches [config] + [delegate]; otherwise build, cache,
     * and reset the conversation so the new tenant/credentials start clean.
     */
    @Synchronized
    fun ensure(config: VoqalConfiguration, delegate: VoqalDelegate): VoqalSession {
        val existing = session
        if (existing != null && existing.config == config && existing.delegate === delegate) {
            return existing
        }
        retainer.reset()
        return VoqalSession.build(config, delegate).also { session = it }
    }
}
