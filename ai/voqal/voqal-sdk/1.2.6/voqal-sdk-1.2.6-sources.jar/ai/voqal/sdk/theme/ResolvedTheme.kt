package ai.voqal.sdk.theme

import ai.voqal.sdk.VoqalTheme
import androidx.compose.ui.graphics.Color

/**
 * A fully resolved color/shape set for the assistant sheet, derived from a [VoqalTheme] and
 * the current system dark-mode state.
 *
 * This is the Android port of the iOS `ResolvedTheme`: the SDK owns every chrome layer, so
 * the renderer must never fall back to platform defaults. All surfaces, hairlines, and text
 * tiers are defined here so light/dark are pixel-consistent with iOS.
 *
 * @property accent Primary accent color (from [VoqalTheme.accent]).
 * @property accent2 Secondary accent; defaults to [accent] when none provided.
 * @property sheetBackground The sheet's base fill.
 * @property surface Translucent surface used for elevated cards.
 * @property surfaceSolid Opaque surface for fully-occluding cards.
 * @property hairline Divider/border color.
 * @property textPrimary Primary text tier.
 * @property textSecondary Secondary (~58% opacity) text tier.
 * @property textTertiary Tertiary (~30% opacity) text tier.
 * @property cornerRadiusDp Corner radius in dp (from [VoqalTheme.radius]).
 * @property isDark Whether this resolved theme is the dark variant.
 */
data class ResolvedTheme(
    val accent: Color,
    val accent2: Color,
    val sheetBackground: Color,
    val surface: Color,
    val surfaceSolid: Color,
    val hairline: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val cornerRadiusDp: Float,
    val isDark: Boolean,
) {
    companion object {
        // Dark palette.
        private val DARK_SHEET_BACKGROUND = Color(0xFF111114)
        private val DARK_SURFACE = Color.White.copy(alpha = 0.06f)
        private val DARK_SURFACE_SOLID = Color(0xFF1F1F23)
        private val DARK_HAIRLINE = Color.White.copy(alpha = 0.10f)
        private val DARK_TEXT_PRIMARY = Color(0xFFF5F5F7)
        private val DARK_TEXT_SECONDARY = Color(0xFFF5F5F7).copy(alpha = 0.58f)
        private val DARK_TEXT_TERTIARY = Color(0xFFF5F5F7).copy(alpha = 0.30f)

        // Light palette.
        private val LIGHT_SHEET_BACKGROUND = Color(0xFFF7F7F9)
        private val LIGHT_SURFACE = Color.White
        private val LIGHT_SURFACE_SOLID = Color.White
        private val LIGHT_HAIRLINE = Color(0xFF101013).copy(alpha = 0.10f)
        private val LIGHT_TEXT_PRIMARY = Color(0xFF101013)
        private val LIGHT_TEXT_SECONDARY = Color(0xFF101013).copy(alpha = 0.58f)
        private val LIGHT_TEXT_TERTIARY = Color(0xFF101013).copy(alpha = 0.30f)

        /**
         * Resolve a [VoqalTheme] against the current system dark-mode flag.
         *
         * Honors the theme's explicit [VoqalTheme.Appearance]; [VoqalTheme.Appearance.AUTO]
         * defers to [systemIsDark].
         *
         * @param theme The configured theme.
         * @param systemIsDark Whether the system is currently in dark mode.
         * @return The fully resolved color/shape set.
         */
        fun resolve(theme: VoqalTheme, systemIsDark: Boolean): ResolvedTheme {
            val useDark = when (theme.appearance) {
                VoqalTheme.Appearance.DARK -> true
                VoqalTheme.Appearance.LIGHT -> false
                VoqalTheme.Appearance.AUTO -> systemIsDark
            }
            val accent = parseHexColor(theme.accent)
            val accent2 = theme.accent2?.let(::parseHexColor) ?: accent
            return if (useDark) {
                dark(accent, accent2, theme.radius)
            } else {
                light(accent, accent2, theme.radius)
            }
        }

        private fun dark(accent: Color, accent2: Color, radius: Float) = ResolvedTheme(
            accent = accent,
            accent2 = accent2,
            sheetBackground = DARK_SHEET_BACKGROUND,
            surface = DARK_SURFACE,
            surfaceSolid = DARK_SURFACE_SOLID,
            hairline = DARK_HAIRLINE,
            textPrimary = DARK_TEXT_PRIMARY,
            textSecondary = DARK_TEXT_SECONDARY,
            textTertiary = DARK_TEXT_TERTIARY,
            cornerRadiusDp = radius,
            isDark = true,
        )

        private fun light(accent: Color, accent2: Color, radius: Float) = ResolvedTheme(
            accent = accent,
            accent2 = accent2,
            sheetBackground = LIGHT_SHEET_BACKGROUND,
            surface = LIGHT_SURFACE,
            surfaceSolid = LIGHT_SURFACE_SOLID,
            hairline = LIGHT_HAIRLINE,
            textPrimary = LIGHT_TEXT_PRIMARY,
            textSecondary = LIGHT_TEXT_SECONDARY,
            textTertiary = LIGHT_TEXT_TERTIARY,
            cornerRadiusDp = radius,
            isDark = false,
        )

        /**
         * Parse a `#RRGGBB` or `#AARRGGBB` hex string into a Compose [Color].
         *
         * @param hex The hex color string (leading `#` optional).
         * @return The parsed color.
         * @throws IllegalArgumentException if [hex] is not 6 or 8 hex digits.
         */
        fun parseHexColor(hex: String): Color {
            val cleaned = hex.removePrefix("#")
            require(cleaned.length == 6 || cleaned.length == 8) {
                "Color hex must be RRGGBB or AARRGGBB, was '$hex'"
            }
            val withAlpha = if (cleaned.length == 6) "FF$cleaned" else cleaned
            return Color(withAlpha.toLong(radix = 16))
        }
    }
}
