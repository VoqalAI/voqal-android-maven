package ai.voqal.sdk.transport

import ai.voqal.sdk.model.RenderSpec
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject

/**
 * Builds the JSON request bodies for the engine endpoints, matching the production contract.
 *
 * Kept pure (no I/O, no SDK state) so the exact wire shape is unit-testable in isolation.
 */
internal object RequestBodies {

    private const val MODE_TEXT = "text"
    private const val AUTH_METHOD_PASSCODE = "passcode"

    /**
     * Build the `POST /voqal` body.
     *
     * Shape: `{"transcript":..., "mode":"text", "context":{"sessionId":..., "country_code":...},
     * "messages":[...]}`. `country_code` is omitted when not present in metadata.
     *
     * @param transcript The user's text.
     * @param sessionId The active session id, or null.
     * @param countryCode The country code from client metadata, or null.
     * @param messages Client-supplied conversation history.
     */
    fun turn(
        transcript: String,
        sessionId: String?,
        countryCode: String?,
        messages: List<JsonObject>,
    ): String {
        val body = buildJsonObject {
            put("transcript", transcript)
            put("mode", MODE_TEXT)
            putJsonObject("context") {
                if (sessionId != null) put("sessionId", sessionId)
                if (countryCode != null) put("country_code", countryCode)
            }
            put("messages", JsonArray(messages))
        }
        return RenderSpec.json.encodeToString(JsonObject.serializer(), body)
    }

    /**
     * Build the `POST /voqal/execute` body.
     *
     * Shape: `{"execute":<spec>, "auth":{"method":"passcode","verifiedAt":<ISO8601 UTC>}?,
     * "context":{"sessionId":...}}`. The execute spec is passed through unchanged.
     *
     * The `auth` envelope is emitted ONLY for verified actions (a confirm card the user accepted
     * after a local passcode/biometric step). Silent, direct tool calls (e.g. add-to-cart) pass
     * [verifiedAtIso] as null so no passcode attestation is fabricated for a step that never ran.
     *
     * @param execute The opaque execute payload from the confirm widget.
     * @param sessionId The active session id, or null.
     * @param verifiedAtIso The ISO-8601 UTC timestamp of the local passcode verification, or null
     *   for an unverified/silent action (omits the `auth` envelope entirely).
     */
    fun execute(execute: JsonObject, sessionId: String?, verifiedAtIso: String?): String {
        val body = buildJsonObject {
            put("execute", execute)
            if (verifiedAtIso != null) {
                putJsonObject("auth") {
                    put("method", AUTH_METHOD_PASSCODE)
                    put("verifiedAt", verifiedAtIso)
                }
            }
            putJsonObject("context") {
                if (sessionId != null) put("sessionId", sessionId)
            }
        }
        return RenderSpec.json.encodeToString(JsonObject.serializer(), body)
    }
}
