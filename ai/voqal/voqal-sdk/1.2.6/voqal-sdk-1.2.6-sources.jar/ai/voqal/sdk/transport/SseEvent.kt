package ai.voqal.sdk.transport

/**
 * One dispatched Server-Sent Event: an event name and its accumulated data payload.
 *
 * Produced by [SseParser] when a blank line terminates an event block. The [event] name
 * defaults to `"message"` per the SSE spec when no `event:` field was present; [data] is the
 * newline-joined value of all `data:` lines in the block.
 *
 * @property event The SSE event name (the value after `event:`), or `"message"` if absent.
 * @property data The event payload (all `data:` lines joined by `\n`).
 */
data class SseEvent(
    val event: String,
    val data: String,
) {
    companion object {
        /** SSE default event name when no `event:` field is supplied. */
        const val DEFAULT_EVENT_NAME: String = "message"
    }
}
