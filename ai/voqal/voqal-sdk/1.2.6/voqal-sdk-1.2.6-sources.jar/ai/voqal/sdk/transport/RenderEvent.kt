package ai.voqal.sdk.transport

import ai.voqal.sdk.model.Widget

/**
 * A single decoded event from a streaming turn (SSE) or the voice socket.
 *
 * One turn produces a sequence: zero or more [SpeakDelta]s (and/or a [Transcript]), then a
 * [Widgets] frame, optionally [Follow] and [Tts], terminated by [Done] (or [Error]). The
 * experience layer folds these into the visible exchange.
 */
sealed class RenderEvent {

    /**
     * An incremental chunk of the spoken/displayed answer text.
     *
     * @property text The delta to append to the answer so far.
     */
    data class SpeakDelta(val text: String) : RenderEvent()

    /**
     * The recognized transcript of the user's voice input (voice turns only).
     *
     * @property text The full transcript.
     */
    data class Transcript(val text: String) : RenderEvent()

    /**
     * The widget array for this turn, plus any follow-up suggestion chips.
     *
     * @property widgets The widgets to render, in order.
     * @property suggestions Optional follow-up prompt suggestions.
     */
    data class Widgets(
        val widgets: List<Widget>,
        val suggestions: List<String> = emptyList(),
    ) : RenderEvent()

    /**
     * A single follow-up line rendered as a pill.
     *
     * @property text The follow-up text. Never null here; an empty wire value decodes to no
     *   event (see the socket/SSE decoders), so a present [Follow] always carries text.
     */
    data class Follow(val text: String) : RenderEvent()

    /**
     * Text-to-speech audio for the answer (when the turn requested voice-out).
     *
     * @property audioBase64 Base64-encoded WAV audio to play.
     */
    data class Tts(val audioBase64: String) : RenderEvent()

    /**
     * A turn-level error carrying a speakable message.
     *
     * @property speak The user-facing message to show/speak.
     */
    data class Error(val speak: String) : RenderEvent()

    /** Terminal event: the turn is complete. */
    data object Done : RenderEvent()
}
