package ai.voqal.sdk.security

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * Serializes string/JSON maps to compact JSON objects for proof JWT segments and the
 * create-session body. Uses kotlinx-serialization so encoding matches the rest of the SDK.
 */
internal object JwkJson {

    /**
     * Encode a flat string map as a compact JSON object, preserving insertion order.
     *
     * @param map The map to encode (e.g. a JWK).
     * @return Compact JSON, e.g. `{"kty":"EC","crv":"P-256","x":"…","y":"…"}`.
     */
    fun encode(map: Map<String, String>): String {
        val members: Map<String, JsonElement> = map.mapValues { JsonPrimitive(it.value) }
        return SecurityJson.instance.encodeToString(JsonObject.serializer(), JsonObject(members))
    }
}
