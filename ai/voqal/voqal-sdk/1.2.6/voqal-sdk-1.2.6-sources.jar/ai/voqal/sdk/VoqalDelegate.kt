package ai.voqal.sdk

/**
 * The host app's bridge to the SDK. The integrator implements this to supply live
 * credentials and to observe results.
 *
 * Contract: [getToken] and [getMetadata] are read **live on every request** — the SDK
 * never caches them — because end-user auth tokens rotate roughly every five minutes.
 * Implementations must therefore always return the freshest value they hold.
 */
interface VoqalDelegate {

    /**
     * The end-user's brand (e.g. Paymob) auth token, sent as the `X-Token` header.
     *
     * Called on every engine request. Must return a currently-valid token; returning a
     * stale token causes the engine's MCP call to fail auth.
     *
     * @return The live auth token. Must not be blank.
     */
    fun getToken(): String

    /**
     * Optional client metadata, sent as the `X-Client-Metadata` header.
     *
     * @return A JSON object string such as `{"country_code":"EGY","user_id":"123"}`, or
     *   null when the host has no metadata to attach.
     */
    fun getMetadata(): String?

    /**
     * Called when a voice recording has been uploaded and the engine returned a result.
     *
     * @param result The raw result payload (typically the transcript or a status string).
     */
    fun onUploadResult(result: String) {}

    /**
     * Called when an unrecoverable error occurs during a turn or session bootstrap.
     *
     * @param error The error. Inspect for type to drive host-side telemetry or UI.
     */
    fun onError(error: Throwable) {}
}
