package ai.voqal.sdk.experience

import ai.voqal.sdk.diagnostics.VoqalLog
import ai.voqal.sdk.theme.ResolvedTheme
import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.remember
import androidx.core.content.ContextCompat

/**
 * The full-screen assistant surface, presented by [ai.voqal.sdk.VoqalSDK.present].
 *
 * The SDK owns all chrome: the window is made fully transparent in code (so no platform white
 * ever flashes behind the Compose sheet), and [VoqalSheet] draws the scrim, the themed
 * bottom card, and the header drag-to-dismiss. The live session/delegate are read from
 * [VoqalSessionHolder] (they can't ride an Intent), and the model is resolved through the
 * conversation retainer so reopening within the timeout resumes the chat.
 */
class VoqalSheetActivity : ComponentActivity() {

    private var requestMicPermission: ((Boolean) -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        requestMicPermission?.invoke(granted)
        requestMicPermission = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        makeWindowTransparent()

        val session = VoqalSessionHolder.current()
        if (session == null) {
            VoqalLog.error("sheet_no_session")
            finish()
            return
        }

        setContent {
            val isDark = resolveIsDark(session)
            val theme = remember(session.config.theme, isDark) {
                ResolvedTheme.resolve(session.config.theme, isDark)
            }
            val model = remember(session) { resolveModel(session) }

            VoqalSheet(
                model = model,
                theme = theme,
                pinnedCTAs = session.config.home.pinnedCTAs,
                onDismiss = ::finishWithoutAnimation,
                onRequestMic = ::ensureMicPermission,
                userName = session.config.home.userName,
                headerIcon = session.config.headerIcon,
            )
        }
    }

    private fun resolveModel(session: VoqalSession): DefaultVoqalExperienceViewModel {
        val model = VoqalSessionHolder.retainer.model(session.config.conversationTimeoutSeconds) {
            buildModel(session)
        } as DefaultVoqalExperienceViewModel
        model.loadHome()
        return model
    }

    private fun buildModel(session: VoqalSession): DefaultVoqalExperienceViewModel =
        DefaultVoqalExperienceViewModel(
            client = session.client,
            voiceTurnRunner = session.voiceTurnRunner(),
            recorderFactory = session.recorderFactory(),
            haptics = session.haptics(applicationContext),
            config = session.config,
            delegate = session.delegate,
        )

    /**
     * Ensure RECORD_AUDIO before starting voice. Invokes [onResult] with the grant outcome,
     * synchronously when already granted, else after the system prompt.
     */
    private fun ensureMicPermission(onResult: (Boolean) -> Unit) {
        val alreadyGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (alreadyGranted) {
            onResult(true)
            return
        }
        requestMicPermission = onResult
        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun resolveIsDark(session: VoqalSession): Boolean = when (session.config.theme.appearance) {
        ai.voqal.sdk.VoqalTheme.Appearance.DARK -> true
        ai.voqal.sdk.VoqalTheme.Appearance.LIGHT -> false
        ai.voqal.sdk.VoqalTheme.Appearance.AUTO -> systemDarkFallback()
    }

    private fun finishWithoutAnimation() {
        finish()
        overridePendingTransition(0, 0)
    }

    private fun makeWindowTransparent() {
        window.setBackgroundDrawable(ColorDrawable(AndroidColor.TRANSPARENT))
    }

    companion object {
        /** Intent extra key for the request correlation id. */
        const val EXTRA_REQUEST_ID: String = "ai.voqal.sdk.REQUEST_ID"
    }
}

/** Read the system dark-mode flag from resources (composition-free helper). */
private fun ComponentActivity.systemDarkFallback(): Boolean {
    val uiMode = resources.configuration.uiMode and
        android.content.res.Configuration.UI_MODE_NIGHT_MASK
    return uiMode == android.content.res.Configuration.UI_MODE_NIGHT_YES
}
