package ai.voqal.sdk.transport

import ai.voqal.sdk.security.ProofSigner
import ai.voqal.sdk.security.SessionManager

/**
 * The session-token contract the transport needs: read the current token, ensure one
 * exists, and force a fresh one after a `401`.
 *
 * Declared in the transport package so [VoqalClient] depends on a narrow seam (not the
 * concrete [SessionManager]). [SessionManagerStore] adapts the real security implementation;
 * tests supply a fake that drives a mock create-session endpoint.
 */
interface SessionTokenStore {

    /** The current session token, or null if none has been established. */
    fun currentToken(): String?

    /** The current session id (from create-session), or null before bootstrap. */
    fun currentSessionId(): String?

    /** Ensure a valid session exists, bootstrapping one if necessary; returns the token. */
    suspend fun ensureSession(): String

    /** Discard the current token and re-bootstrap; returns the freshly minted token. */
    suspend fun silentRefresh(): String
}

/**
 * The proof contract the transport needs: sign one request into a `Voqal-Proof` JWT.
 *
 * Lets [VoqalClient] depend on a narrow seam rather than the concrete [ProofSigner].
 */
interface RequestProofSigner {

    /**
     * Sign a proof JWT binding the request method, URI, and body.
     *
     * @param httpMethod The HTTP method (e.g. `"POST"`).
     * @param requestUri The full request URI.
     * @param body The exact request body bytes.
     * @return The compact-serialized signed JWT.
     */
    fun sign(httpMethod: String, requestUri: String, body: ByteArray): String
}

/** Adapts the production [SessionManager] to the transport's [SessionTokenStore] seam. */
class SessionManagerStore(private val sessionManager: SessionManager) : SessionTokenStore {
    override fun currentToken(): String? = sessionManager.currentToken()
    override fun currentSessionId(): String? = sessionManager.currentSessionId()
    override suspend fun ensureSession(): String = sessionManager.ensureSession()
    override suspend fun silentRefresh(): String = sessionManager.silentRefresh()
}

/** Adapts the production [ProofSigner] to the transport's [RequestProofSigner] seam. */
class ProofSignerAdapter(private val proofSigner: ProofSigner) : RequestProofSigner {
    override fun sign(httpMethod: String, requestUri: String, body: ByteArray): String =
        proofSigner.sign(httpMethod, requestUri, body)
}
