package ai.voqal.sdk.diagnostics

import java.util.concurrent.CopyOnWriteArrayList

/**
 * Central diagnostics hub. Fans out structured events and errors to every registered
 * [VoqalLogSink].
 *
 * This is intentionally a process-wide object (the SDK is a singleton facade). Sinks are
 * stored in a copy-on-write list so emission is lock-free on the hot path while registration
 * remains thread-safe. A failing sink is isolated: its exception is caught so one bad sink
 * cannot break diagnostics for the others.
 */
object VoqalLog {

    private val sinks = CopyOnWriteArrayList<VoqalLogSink>()

    /**
     * Register a sink. Duplicate registrations are allowed (the host owns dedup).
     *
     * @param sink The sink to receive subsequent events/errors.
     */
    fun addSink(sink: VoqalLogSink) {
        sinks.add(sink)
    }

    /** Remove all registered sinks. Primarily for tests. */
    fun clearSinks() {
        sinks.clear()
    }

    /**
     * Emit a structured event to all sinks.
     *
     * @param name Stable event name in snake_case.
     * @param fields Structured context. Never include secrets or PII.
     */
    fun event(name: String, fields: Map<String, Any?> = emptyMap()) {
        for (sink in sinks) {
            runCatching { sink.event(name, fields) }
        }
    }

    /**
     * Emit an error to all sinks.
     *
     * @param name Stable error name in snake_case.
     * @param throwable The error, if available.
     * @param fields Structured context. Never include secrets or PII.
     */
    fun error(name: String, throwable: Throwable? = null, fields: Map<String, Any?> = emptyMap()) {
        for (sink in sinks) {
            runCatching { sink.error(name, throwable, fields) }
        }
    }
}
