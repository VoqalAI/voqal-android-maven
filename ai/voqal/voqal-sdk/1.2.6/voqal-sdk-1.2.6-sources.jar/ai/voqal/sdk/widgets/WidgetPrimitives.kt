package ai.voqal.sdk.widgets

import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.theme.ResolvedTheme
import ai.voqal.sdk.theme.TextDirection
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection as ComposeTextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.json.JsonObject

/**
 * Shared visual primitives and constants for the Voqal widget set.
 *
 * These mirror the iOS SwiftUI design language 1:1: a 16dp card padding, a mono uppercase
 * "eyebrow" label ramp, hairline borders, an accent-gradient progress bar, and monospaced
 * numerals for values. Nothing here hardcodes a color — every surface and text tier is read
 * from [ResolvedTheme], so one widget set looks native in any host theme.
 */
internal object WidgetTokens {
    val CARD_PADDING = 16.dp
    val ROW_SPACING = 12.dp

    /** Hairline borders/separators are 0.5px on iOS; the nearest crisp Android value. */
    val HAIRLINE_THICKNESS = 0.5.dp

    /** A list widget never renders more than this many rows, matching the iOS cap. */
    const val MAX_LIST_ROWS = 6

    // iOS Eyebrow: SF Mono, uppercase, 10.5pt, semibold, tracking 1.2.
    val EYEBROW_SIZE = 10.5.sp
    val EYEBROW_TRACKING = 1.2.sp

    // Text tiers used across widgets (display sizes mirror VoqalFont.display calls).
    val STAT_VALUE_SIZE = 30.sp
    val STAT_VALUE_TRACKING = (-0.8).sp
    val DELTA_SIZE = 12.5.sp
    val ROW_LABEL_SIZE = 14.sp
    val FOOTER_SIZE = 12.sp
    val PROGRESS_BAR_HEIGHT = 4.dp
}

/**
 * A full-width rounded card: surface fill, a 0.5px hairline border, theme corner radius, and —
 * in light mode only — a soft drop shadow. Faithful port of the iOS `voqalCard()` modifier.
 *
 * @param theme Resolved theme supplying the radius, hairline, and dark/light flag.
 * @param fill Surface color painted behind [content] (translucent surface or opaque surfaceSolid).
 * @param modifier Additional modifiers applied after the standard chrome.
 * @param content Card body, laid out inside the clipped surface.
 */
@Composable
internal fun WidgetSurface(
    theme: ResolvedTheme,
    fill: Color,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(theme.cornerRadiusDp.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(if (theme.isDark) Modifier else Modifier.shadow(10.dp, shape, clip = false))
            .clip(shape)
            .background(fill, shape)
            .border(WidgetTokens.HAIRLINE_THICKNESS, theme.hairline, shape),
    ) {
        content()
    }
}

/**
 * The opaque "review" surface used by the confirm card: a fixed 22dp radius (not the theme
 * radius), [ResolvedTheme.surfaceSolid] fill, a 0.5px hairline border, and a pronounced drop
 * shadow. Faithful port of the iOS `ConfirmWidget` chrome.
 */
@Composable
internal fun ConfirmSurface(
    theme: ResolvedTheme,
    content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(CONFIRM_RADIUS)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(CONFIRM_SHADOW, shape, clip = false)
            .clip(shape)
            .background(theme.surfaceSolid, shape)
            .border(WidgetTokens.HAIRLINE_THICKNESS, theme.hairline, shape),
    ) {
        content()
    }
}

private val CONFIRM_RADIUS = 22.dp
private val CONFIRM_SHADOW = 30.dp

/** A horizontal hairline separator drawn in the theme's divider color. */
@Composable
internal fun Hairline(theme: ResolvedTheme, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(WidgetTokens.HAIRLINE_THICKNESS)
            .background(theme.hairline),
    )
}

/**
 * The iOS "Eyebrow": a mono, uppercased, letter-spaced caption used as a label across widgets.
 *
 * @param text Caption text; uppercased here so callers pass natural casing.
 * @param theme Resolved theme (supplies the default [ResolvedTheme.textSecondary] color).
 * @param color Optional override tier (e.g. accent for an active step or badge).
 */
@Composable
internal fun Eyebrow(
    text: String,
    theme: ResolvedTheme,
    modifier: Modifier = Modifier,
    color: Color = theme.textSecondary,
) {
    Text(
        text = text.uppercase(),
        modifier = modifier,
        color = color,
        fontSize = WidgetTokens.EYEBROW_SIZE,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = WidgetTokens.EYEBROW_TRACKING,
        style = TextStyle(textDirection = composeDirectionOf(text)),
    )
}

/**
 * The themed progress bar: a hairline track with an accent→accent2 gradient fill clamped to
 * `0..1`. Matches the iOS `VoqalBar` (height 4, capsule track, leading gradient).
 */
@Composable
internal fun VoqalBar(value: Double, theme: ResolvedTheme) {
    val fraction = value.coerceIn(0.0, 1.0).toFloat()
    val capsule = RoundedCornerShape(percent = 50)
    Box(
        Modifier
            .fillMaxWidth()
            .height(WidgetTokens.PROGRESS_BAR_HEIGHT)
            .clip(capsule)
            .background(theme.hairline),
    ) {
        Box(
            Modifier
                .fillMaxWidth(fraction)
                .height(WidgetTokens.PROGRESS_BAR_HEIGHT)
                .clip(capsule)
                .background(Brush.horizontalGradient(listOf(theme.accent, theme.accent2))),
        )
    }
}

/**
 * Map a string's detected script direction to a Compose [ComposeTextDirection].
 *
 * Per-element: an Arabic string lays out RTL even inside an otherwise-LTR list, matching the
 * iOS bidi behavior where an answer follows its own script.
 */
internal fun composeDirectionOf(text: String): ComposeTextDirection =
    when (TextDirection.of(text)) {
        TextDirection.Direction.RTL -> ComposeTextDirection.Rtl
        TextDirection.Direction.LTR -> ComposeTextDirection.Ltr
    }

/**
 * A text element whose layout direction is resolved per-string via [TextDirection], so an
 * Arabic value lays out RTL even inside an otherwise-LTR widget.
 *
 * @param text The string to render.
 * @param color Text color (always a [ResolvedTheme] tier — never hardcoded by callers).
 * @param mono Use monospaced digits (iOS `monospacedDigit()`), e.g. for numeric values.
 */
@Composable
internal fun DirectionalText(
    text: String,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    fontWeight: FontWeight? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textAlign: TextAlign? = null,
    mono: Boolean = false,
    maxLines: Int = Int.MAX_VALUE,
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontWeight = fontWeight,
        fontFamily = if (mono) FontFamily.Monospace else null,
        letterSpacing = letterSpacing,
        textAlign = textAlign,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        style = TextStyle(textDirection = composeDirectionOf(text)),
    )
}

/**
 * The full-width CTA shown at the bottom of a [Widget.Confirm]. Carries no biometric iconography
 * by design (plain "Confirm"). Matches the iOS treatment: a high-contrast button — black on white
 * in light mode, white on black in dark mode — with a 15dp radius and 52dp height; tapping
 * forwards the opaque execute payload to [onConfirm].
 *
 * @param widget The confirm widget supplying the CTA label and execute payload.
 * @param onConfirm Invoked with [Widget.Confirm.execute] on tap; null makes the CTA inert.
 */
@Composable
internal fun ConfirmButton(
    widget: Widget.Confirm,
    theme: ResolvedTheme,
    onConfirm: ((JsonObject) -> Unit)?,
) {
    val label = widget.cta?.takeIf { it.isNotBlank() } ?: DEFAULT_CONFIRM_CTA
    val shape: Shape = RoundedCornerShape(CTA_RADIUS)
    val background = if (theme.isDark) Color.White else Color.Black
    val foreground = if (theme.isDark) Color.Black else Color.White
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(CTA_HEIGHT)
            .clip(shape)
            .background(background, shape)
            .clickable(enabled = onConfirm != null) { onConfirm?.invoke(widget.execute) },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = foreground,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

private const val DEFAULT_CONFIRM_CTA = "Confirm"
private val CTA_HEIGHT = 52.dp
private val CTA_RADIUS = 15.dp
