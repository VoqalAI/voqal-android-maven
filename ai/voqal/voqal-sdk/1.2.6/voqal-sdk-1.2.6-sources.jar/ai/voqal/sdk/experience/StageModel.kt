package ai.voqal.sdk.experience

/**
 * Pure presentation logic for [VoqalStage], extracted so it is unit-testable without a Compose
 * runtime. Mirrors the iOS `StageView`/`HomeGlanceView` decisions: which exchange is the home
 * glance, which are conversation turns, and how an answer is sized by its length.
 */
internal object StageModel {

    /** Length thresholds (chars) for the answer type ramp, matching iOS `answerSize`. */
    const val ANSWER_HERO_MAX = 70
    const val ANSWER_READABLE_MAX = 160

    /** Answer sizes (sp values), matching iOS 27 / 21 / 17. */
    const val ANSWER_HERO_SP = 27f
    const val ANSWER_READABLE_SP = 21f
    const val ANSWER_LONG_SP = 17f

    /** Below this char count a current voice answer word-reveals (iOS uses `< 90`). */
    const val REVEAL_CHAR_LIMIT = 90

    /** A glance is the agent-initiated opening turn: no question and not a voice turn. */
    fun isGlance(exchange: Exchange): Boolean = exchange.question == null && !exchange.isVoice

    /**
     * The home page exchange to render, or null once a real conversation has started.
     *
     * The agent glance, when present, is the first exchange. When it is absent (glance disabled or
     * not yet appended) a synthetic empty glance carries the pinned CTAs so the greeting + "Try
     * saying" rows still render — matching iOS's always-present home view.
     */
    fun homeGlance(exchanges: List<Exchange>, pinnedCTAs: List<String>): Exchange? {
        val first = exchanges.firstOrNull()
        if (first != null && isGlance(first)) return first
        if (exchanges.isEmpty()) {
            return Exchange(id = SYNTHETIC_HOME_ID, question = null, suggestions = pinnedCTAs)
        }
        return null
    }

    /** The conversation turns shown below the home page (everything but the leading glance). */
    fun turns(exchanges: List<Exchange>): List<Exchange> =
        if (exchanges.firstOrNull()?.let(::isGlance) == true) exchanges.drop(1) else exchanges

    /** The answer's display size in sp, chosen by length (short gist = hero, longer = readable). */
    fun answerSizeSp(text: String): Float = when {
        text.length < ANSWER_HERO_MAX -> ANSWER_HERO_SP
        text.length < ANSWER_READABLE_MAX -> ANSWER_READABLE_SP
        else -> ANSWER_LONG_SP
    }

    /** Whether the current voice answer should word-reveal rather than render instantly. */
    fun shouldReveal(isCurrent: Boolean, isVoice: Boolean, text: String): Boolean =
        isCurrent && isVoice && text.length < REVEAL_CHAR_LIMIT

    /** The home greeting word for a given 24-hour clock hour (iOS thresholds: < 12 / < 18 / else). */
    fun greetingForHour(hour: Int): String = when {
        hour < 12 -> "Good morning"
        hour < 18 -> "Good afternoon"
        else -> "Good evening"
    }

    const val SYNTHETIC_HOME_ID = "home-synthetic"
}
