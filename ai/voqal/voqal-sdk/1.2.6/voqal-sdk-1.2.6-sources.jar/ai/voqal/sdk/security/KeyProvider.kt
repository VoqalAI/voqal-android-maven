package ai.voqal.sdk.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.ECGenParameterSpec

/**
 * Supplies the device EC P-256 key pair. The seam exists so production uses the hardware
 * Android Keystore while JVM unit tests inject an in-memory `java.security` key pair (no
 * Robolectric, no device).
 *
 * Implementations must be idempotent: the first call generates the key, later calls return
 * the same one.
 */
internal interface KeyProvider {

    /**
     * Get the existing device key pair, generating it once if absent.
     *
     * @return The device EC P-256 key pair.
     */
    fun getOrCreateKeyPair(): KeyPair
}

/**
 * Production [KeyProvider] backed by the Android Keystore. The private key is
 * non-exportable and hardware-backed where available.
 */
internal class KeystoreKeyProvider(
    private val alias: String = DeviceKey.KEY_ALIAS,
) : KeyProvider {

    override fun getOrCreateKeyPair(): KeyPair {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        loadExisting(keyStore)?.let { return it }
        return generate()
    }

    private fun loadExisting(keyStore: KeyStore): KeyPair? {
        val privateKey = keyStore.getKey(alias, null) as? PrivateKey ?: return null
        val publicKey = keyStore.getCertificate(alias)?.publicKey ?: return null
        return KeyPair(publicKey, privateKey)
    }

    private fun generate(): KeyPair {
        val generator = KeyPairGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_EC, ANDROID_KEYSTORE
        )
        generator.initialize(buildSpec())
        return generator.generateKeyPair()
    }

    private fun buildSpec(): KeyGenParameterSpec =
        KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
            .setAlgorithmParameterSpec(ECGenParameterSpec(DeviceKey.CURVE))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .build()

    private companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
    }
}

/**
 * JVM [KeyProvider] backed by `java.security`, for unit tests. Generates a P-256 key pair
 * once and caches it in memory.
 */
internal class InMemoryKeyProvider : KeyProvider {

    private val keyPair: KeyPair by lazy {
        KeyPairGenerator.getInstance("EC").apply {
            initialize(ECGenParameterSpec(DeviceKey.CURVE))
        }.generateKeyPair()
    }

    override fun getOrCreateKeyPair(): KeyPair = keyPair
}

internal fun PublicKey.asEcPublicKey(): java.security.interfaces.ECPublicKey =
    this as? java.security.interfaces.ECPublicKey
        ?: throw IllegalStateException("Device key is not an EC public key: ${this.algorithm}")
