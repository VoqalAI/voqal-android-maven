package ai.voqal.sdk.voice

import ai.voqal.sdk.model.RenderSpec
import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.transport.RenderEvent
import ai.voqal.sdk.transport.VoqalEndpoint
import ai.voqal.sdk.transport.VoqalHeaders
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener

/**
 * One WebSocket per voice turn against `WS /voqal/stream`.
 *
 * Protocol: on open, send the clip as `{"type":"audio","audioBase64":...}` then
 * `{"type":"end","tts":<bool>}`. Incoming text frames are decoded by [decodeFrame] into
 * [RenderEvent]s; `done` closes the socket (1000), an error or socket failure emits
 * [RenderEvent.Error] then completes. Cancelling the [run] flow closes the socket.
 *
 * @param endpoint Resolves the `wss://…/voqal/stream` URL.
 * @param httpClient Shared OkHttp client (connection-pooled).
 * @param headers The request headers to attach (built once per [connect]).
 */
class VoiceSocket private constructor(
    private val endpoint: VoqalEndpoint,
    private val httpClient: OkHttpClient,
    private val headers: Map<String, String>,
) {

    /**
     * Open the socket and stream one voice turn for [audioBase64].
     *
     * Sends the audio + end frames on open, then emits decoded events until
     * [RenderEvent.Done] or [RenderEvent.Error]. Completing or cancelling the returned flow
     * closes the socket.
     *
     * @param audioBase64 The recorded clip as base64 WAV.
     * @param requestTts When true, the `end` frame requests TTS voice-out.
     * @return A cold [Flow] that opens the socket when collected.
     */
    fun run(audioBase64: String, requestTts: Boolean = false): Flow<RenderEvent> = callbackFlow {
        val request = buildRequest()
        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(audioFrame(audioBase64))
                webSocket.send(endFrame(requestTts))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val event = decodeFrame(text) ?: return
                trySend(event)
                if (event is RenderEvent.Done) {
                    webSocket.close(NORMAL_CLOSURE, null)
                    close()
                } else if (event is RenderEvent.Error) {
                    close()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                trySend(RenderEvent.Error(t.message ?: "voice socket failed"))
                close()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                close()
            }
        }

        val socket = httpClient.newWebSocket(request, listener)
        awaitClose { socket.cancel() }
    }

    private fun buildRequest(): Request {
        val builder = Request.Builder().url(endpoint.stream())
        headers.forEach { (name, value) -> builder.addHeader(name, value) }
        return builder.build()
    }

    companion object {
        const val FRAME_TYPE_AUDIO: String = "audio"
        const val FRAME_TYPE_END: String = "end"

        const val FRAME_TYPE_TRANSCRIPT: String = "transcript"
        const val FRAME_TYPE_SPEAK: String = "speak"
        const val FRAME_TYPE_WIDGETS: String = "widgets"
        const val FRAME_TYPE_FOLLOW: String = "follow"
        const val FRAME_TYPE_TTS: String = "tts"
        const val FRAME_TYPE_ERROR: String = "error"
        const val FRAME_TYPE_DONE: String = "done"

        /** Session id header for the live socket (the engine reads it off the upgrade). */
        const val SESSION_ID: String = "X-Session-ID"

        private const val NORMAL_CLOSURE: Int = 1000

        private const val KEY_TYPE = "type"
        private const val KEY_AUDIO_BASE64 = "audioBase64"
        private const val KEY_TTS = "tts"
        private const val KEY_TEXT = "text"
        private const val KEY_DELTA = "delta"
        private const val KEY_WIDGETS = "widgets"
        private const val KEY_SUGGESTIONS = "suggestions"
        private const val KEY_SPEAK = "speak"

        /**
         * Open a socket for one turn, attaching the full header contract.
         *
         * Headers with a null/blank value are omitted (e.g. an absent session id), so an
         * unauthenticated probe doesn't send empty header lines.
         */
        fun connect(
            endpoint: VoqalEndpoint,
            httpClient: OkHttpClient,
            token: String,
            apiKey: String,
            requestId: String,
            clientMetadata: String?,
            sessionId: String?,
        ): VoiceSocket {
            val headers = buildMap {
                put(VoqalHeaders.TOKEN, token)
                put(VoqalHeaders.VOQAL_KEY, apiKey)
                put(VoqalHeaders.REQUEST_ID, requestId)
                clientMetadata?.takeIf { it.isNotBlank() }
                    ?.let { put(VoqalHeaders.CLIENT_METADATA, it) }
                sessionId?.takeIf { it.isNotBlank() }?.let { put(SESSION_ID, it) }
            }
            return VoiceSocket(endpoint, httpClient, headers)
        }

        private fun audioFrame(audioBase64: String): String = buildJsonObject {
            put(KEY_TYPE, JsonPrimitive(FRAME_TYPE_AUDIO))
            put(KEY_AUDIO_BASE64, JsonPrimitive(audioBase64))
        }.toString()

        private fun endFrame(requestTts: Boolean): String = buildJsonObject {
            put(KEY_TYPE, JsonPrimitive(FRAME_TYPE_END))
            put(KEY_TTS, JsonPrimitive(requestTts))
        }.toString()

        /**
         * Decode one incoming text frame into a [RenderEvent].
         *
         * Pure and side-effect free for unit testing. Returns `null` (drop the frame) for:
         * non-JSON / empty input, an unknown `type`, or a `follow` frame whose text is
         * null/blank (so the UI never shows an empty follow pill).
         *
         * @param json The raw text frame.
         * @return The decoded event, or `null` to ignore the frame.
         */
        fun decodeFrame(json: String): RenderEvent? {
            val obj = parseObject(json) ?: return null
            return when (obj.stringField(KEY_TYPE)) {
                FRAME_TYPE_TRANSCRIPT -> obj.stringField(KEY_TEXT)?.let(RenderEvent::Transcript)
                FRAME_TYPE_SPEAK -> obj.stringField(KEY_DELTA)?.let(RenderEvent::SpeakDelta)
                FRAME_TYPE_WIDGETS -> decodeWidgets(obj)
                FRAME_TYPE_FOLLOW -> decodeFollow(obj)
                FRAME_TYPE_TTS -> obj.stringField(KEY_AUDIO_BASE64)?.let(RenderEvent::Tts)
                FRAME_TYPE_ERROR -> obj.stringField(KEY_SPEAK)?.let(RenderEvent::Error)
                FRAME_TYPE_DONE -> RenderEvent.Done
                else -> null
            }
        }

        private fun decodeFollow(obj: JsonObject): RenderEvent? {
            val text = obj.stringField(KEY_TEXT)?.takeIf { it.isNotBlank() } ?: return null
            return RenderEvent.Follow(text)
        }

        private fun decodeWidgets(obj: JsonObject): RenderEvent {
            val widgets: List<Widget> = obj[KEY_WIDGETS]?.let { element ->
                element.jsonArray.map { RenderSpec.json.decodeFromJsonElement<Widget>(it) }
            } ?: emptyList()
            val suggestions = obj[KEY_SUGGESTIONS]?.jsonArray
                ?.mapNotNull { it.jsonPrimitive.contentOrNull }
                ?: emptyList()
            return RenderEvent.Widgets(widgets, suggestions)
        }

        private fun parseObject(json: String): JsonObject? =
            runCatching { RenderSpec.json.parseToJsonElement(json).jsonObject }.getOrNull()

        private fun JsonObject.stringField(key: String): String? =
            this[key]?.let { runCatching { it.jsonPrimitive.contentOrNull }.getOrNull() }
    }
}
