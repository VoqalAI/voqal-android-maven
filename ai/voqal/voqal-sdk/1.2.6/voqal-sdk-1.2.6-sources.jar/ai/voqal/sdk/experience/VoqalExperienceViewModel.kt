package ai.voqal.sdk.experience

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.JsonObject

/**
 * The experience state holder: owns the phase machine and the list of [Exchange]s, and turns
 * user intents into engine turns.
 *
 * UI observes [phase] and [exchanges]; it never mutates them directly. All transitions go
 * through the intent methods below. Barge-in semantics: [startVoice] from
 * [VoqalPhase.Speaking] cancels the in-flight answer/TTS and claims [VoqalPhase.Listening].
 *
 * Implementation owns: collecting [ai.voqal.sdk.transport.RenderEvent]s, folding them into
 * the active [Exchange], driving haptics, and TTS playback.
 */
abstract class VoqalExperienceViewModel : ViewModel() {

    /** The current interaction phase. */
    abstract val phase: StateFlow<VoqalPhase>

    /** The conversation so far, oldest first. */
    abstract val exchanges: StateFlow<List<Exchange>>

    /**
     * Send a typed message. Typed turns stay silent (no TTS), per the voice-in/voice-out
     * policy.
     *
     * @param text The user's typed message. Blank input is ignored.
     */
    abstract fun send(text: String)

    /**
     * Begin a voice turn. Starts the microphone and moves to [VoqalPhase.Listening].
     * Cancels any in-flight answer/TTS first (barge-in).
     */
    abstract fun startVoice()

    /**
     * Stop the microphone and send the captured clip. Drops the clip silently if
     * [ai.voqal.sdk.voice.AudioClipAnalyzer] judges it inaudible.
     */
    abstract fun stopVoiceAndSend()

    /**
     * Execute a confirmed action from a [ai.voqal.sdk.model.Widget.Confirm].
     *
     * @param execute The opaque execute payload, passed through to the engine unchanged.
     */
    abstract fun confirm(execute: JsonObject)
}
