package ai.voqal.sdk.security

import kotlinx.serialization.json.Json

/**
 * The shared kotlinx-serialization [Json] instance for the security package: proof JWT
 * segments, the create-session request/response, and JWK encoding.
 *
 * Tolerates unknown response fields (forward compatibility with a newer engine) and emits
 * compact output (no pretty-printing) so JWT/proof byte sequences stay deterministic.
 */
internal object SecurityJson {

    val instance: Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = false
    }
}
