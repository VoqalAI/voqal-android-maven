package ai.voqal.sdk.theme

/**
 * Per-element text-direction detection.
 *
 * Voqal is a bidirectional product: an answer's direction follows the **answer's** script,
 * not the question's. So every rendered string is classified independently — an Arabic
 * answer to an English question lays out RTL, and vice versa.
 *
 * Rule: a string is RTL if its first strongly-directional character is Arabic or Hebrew.
 * Neutral leading characters (digits, punctuation, whitespace, symbols) are skipped until a
 * strongly-directional character is found. A string with no strong character defaults to LTR.
 */
object TextDirection {

    /** Layout direction for a rendered string. */
    enum class Direction { LTR, RTL }

    /**
     * Classify [text] by its first strongly-directional character.
     *
     * @param text The string to classify.
     * @return [Direction.RTL] if the first strong char is Arabic/Hebrew, else [Direction.LTR].
     */
    fun of(text: String): Direction {
        var index = 0
        while (index < text.length) {
            val codePoint = text.codePointAt(index)
            when (strengthOf(codePoint)) {
                Strength.RTL -> return Direction.RTL
                Strength.LTR -> return Direction.LTR
                Strength.NEUTRAL -> Unit
            }
            index += Character.charCount(codePoint)
        }
        return Direction.LTR
    }

    /** Convenience predicate equivalent to `of(text) == Direction.RTL`. */
    fun isRtl(text: String): Boolean = of(text) == Direction.RTL

    private enum class Strength { LTR, RTL, NEUTRAL }

    private fun strengthOf(codePoint: Int): Strength = when {
        isRtlScript(codePoint) -> Strength.RTL
        isLtrScript(codePoint) -> Strength.LTR
        else -> Strength.NEUTRAL
    }

    private fun isRtlScript(codePoint: Int): Boolean =
        codePoint in HEBREW_RANGE ||
            codePoint in ARABIC_BLOCK ||
            codePoint in ARABIC_SUPPLEMENT ||
            codePoint in ARABIC_EXTENDED_A ||
            codePoint in ARABIC_PRESENTATION_A ||
            codePoint in ARABIC_PRESENTATION_B

    private fun isLtrScript(codePoint: Int): Boolean =
        codePoint in BASIC_LATIN_UPPER ||
            codePoint in BASIC_LATIN_LOWER ||
            codePoint in LATIN_SUPPLEMENT_LETTERS

    private val HEBREW_RANGE = 0x0590..0x05FF
    private val ARABIC_BLOCK = 0x0600..0x06FF
    private val ARABIC_SUPPLEMENT = 0x0750..0x077F
    private val ARABIC_EXTENDED_A = 0x08A0..0x08FF
    private val ARABIC_PRESENTATION_A = 0xFB50..0xFDFF
    private val ARABIC_PRESENTATION_B = 0xFE70..0xFEFF

    private val BASIC_LATIN_UPPER = 0x0041..0x005A
    private val BASIC_LATIN_LOWER = 0x0061..0x007A
    private val LATIN_SUPPLEMENT_LETTERS = 0x00C0..0x024F
}
