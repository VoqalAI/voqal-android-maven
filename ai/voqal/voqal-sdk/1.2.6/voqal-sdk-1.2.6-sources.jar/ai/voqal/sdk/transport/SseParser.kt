package ai.voqal.sdk.transport

/**
 * A line-oriented Server-Sent Events parser (the `text/event-stream` wire format).
 *
 * Fed one raw line at a time via [accept]; emits a complete [SseEvent] whenever a blank line
 * terminates an event block. Implements the subset of the SSE spec the engine uses:
 *
 * - `event: <name>` sets the event name for the current block.
 * - `data: <value>` appends a payload line (multiple `data:` lines join with `\n`).
 * - A line starting with `:` is a comment and is ignored (used as a keep-alive heartbeat).
 * - A blank line dispatches the accumulated block (name defaults to `"message"`).
 *
 * The parser is stateful and single-threaded by design: drive it from one reader loop. A
 * leading space after the field colon is stripped per the spec (`data: x` → `x`).
 */
class SseParser {

    private var eventName: String? = null
    private val dataLines = mutableListOf<String>()

    /**
     * Feed one line (without its trailing newline) into the parser.
     *
     * @param line The raw SSE line.
     * @return A completed [SseEvent] when this line was a dispatching blank line and a block
     *   was pending; otherwise null.
     */
    fun accept(line: String): SseEvent? {
        if (line.isEmpty()) {
            return dispatch()
        }
        if (line.startsWith(COMMENT_PREFIX)) {
            return null
        }
        consumeField(line)
        return null
    }

    private fun consumeField(line: String): Unit {
        val colonIndex = line.indexOf(':')
        val field = if (colonIndex == -1) line else line.substring(0, colonIndex)
        val rawValue = if (colonIndex == -1) "" else line.substring(colonIndex + 1)
        val value = rawValue.removePrefix(" ")
        when (field) {
            FIELD_EVENT -> eventName = value
            FIELD_DATA -> dataLines.add(value)
        }
    }

    private fun dispatch(): SseEvent? {
        if (eventName == null && dataLines.isEmpty()) {
            return null
        }
        val event = SseEvent(
            event = eventName ?: SseEvent.DEFAULT_EVENT_NAME,
            data = dataLines.joinToString("\n"),
        )
        reset()
        return event
    }

    private fun reset() {
        eventName = null
        dataLines.clear()
    }

    companion object {
        private const val COMMENT_PREFIX = ":"
        private const val FIELD_EVENT = "event"
        private const val FIELD_DATA = "data"
    }
}
