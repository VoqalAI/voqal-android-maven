package ai.voqal.sdk.security

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import java.security.MessageDigest
import java.security.Signature
import java.util.UUID

/**
 * Mints a per-request proof-of-possession JWT (ES256), sent as the `Voqal-Proof` header.
 *
 * The proof binds each request to the device key so a stolen session token alone is
 * useless. The engine verifies the signature against the public key it recorded at session
 * bootstrap (the `cnf.jkt` thumbprint) and checks the bound method/URI/body hash.
 *
 * JWT shape (the engine ignores `typ`; it verifies `alg`, the embedded `jwk`, the
 * signature, and the bound claims — see voqal-engine `security/proof.py`):
 * - Header: `{"alg":"ES256","typ":"JWT","jwk":<device public JWK>}`.
 * - Claims:
 *   - `htm`: the HTTP method (e.g. `"POST"`).
 *   - `htu`: the full request URI/path (including the `/v2` prefix — the engine verifies
 *     against the original client path).
 *   - `bhash`: `base64url(sha256(request_body_bytes))`.
 *   - `iat`: issued-at epoch seconds.
 *   - `jti`: a unique nonce (replay protection).
 *
 * @param deviceKey The device key used to sign the proof.
 */
class ProofSigner(private val deviceKey: DeviceKey) {

    /**
     * Build and sign a proof JWT for a single request.
     *
     * @param httpMethod The HTTP method, e.g. `"POST"`. Bound as the `htm` claim.
     * @param requestUri The full request URI. Bound as the `htu` claim.
     * @param body The exact request body bytes (empty for bodiless requests). Hashed into
     *   the `bhash` claim so the engine can detect tampering.
     * @return The compact-serialized signed JWT string.
     */
    fun sign(httpMethod: String, requestUri: String, body: ByteArray): String {
        val signingInput = buildSigningInput(httpMethod, requestUri, body)
        val signature = Base64Url.encode(signRaw(signingInput.toByteArray(Charsets.US_ASCII)))
        return "$signingInput.$signature"
    }

    private fun buildSigningInput(httpMethod: String, requestUri: String, body: ByteArray): String {
        val header = Base64Url.encode(encodeHeader().toByteArray(Charsets.UTF_8))
        val claims = Base64Url.encode(encodeClaims(httpMethod, requestUri, body).toByteArray(Charsets.UTF_8))
        return "$header.$claims"
    }

    private fun encodeHeader(): String {
        val jwk = JsonObject(deviceKey.publicJwk().mapValues { JsonPrimitive(it.value) })
        val header = buildJsonObject {
            put("alg", JsonPrimitive(ALGORITHM))
            put("typ", JsonPrimitive(TOKEN_TYPE))
            put("jwk", jwk)
        }
        return SecurityJson.instance.encodeToString(JsonObject.serializer(), header)
    }

    private fun encodeClaims(httpMethod: String, requestUri: String, body: ByteArray): String {
        val claims = buildJsonObject {
            put("htm", JsonPrimitive(httpMethod))
            put("htu", JsonPrimitive(requestUri))
            put("bhash", JsonPrimitive(bodyHash(body)))
            put("iat", JsonPrimitive(System.currentTimeMillis() / MILLIS_PER_SECOND))
            put("jti", JsonPrimitive(UUID.randomUUID().toString()))
        }
        return SecurityJson.instance.encodeToString(JsonObject.serializer(), claims)
    }

    private fun bodyHash(body: ByteArray): String {
        val digest = MessageDigest.getInstance(DIGEST_ALGORITHM).digest(body)
        return Base64Url.encode(digest)
    }

    private fun signRaw(signingInput: ByteArray): ByteArray {
        val signer = Signature.getInstance(JCA_SIGNATURE_ALGORITHM).apply {
            initSign(deviceKey.privateKey())
            update(signingInput)
        }
        return EcdsaSignature.derToRaw(signer.sign())
    }

    companion object {
        const val ALGORITHM: String = "ES256"
        const val TOKEN_TYPE: String = "JWT"

        private const val JCA_SIGNATURE_ALGORITHM = "SHA256withECDSA"
        private const val DIGEST_ALGORITHM = "SHA-256"
        private const val MILLIS_PER_SECOND = 1000L
    }
}
