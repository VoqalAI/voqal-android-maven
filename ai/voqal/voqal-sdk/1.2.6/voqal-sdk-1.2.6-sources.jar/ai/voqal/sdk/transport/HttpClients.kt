package ai.voqal.sdk.transport

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Builds the shared [OkHttpClient] for the SDK with the engine's timeout contract.
 *
 * SSE turns are long-lived, so the read timeout is generous; the connect timeout stays
 * tight to fail fast on an unreachable engine. The same connection-pooled client is reused
 * for turns, execute, and session bootstrap.
 */
object HttpClients {

    /** Connect timeout: fail fast when the engine is unreachable. */
    const val CONNECT_TIMEOUT_SECONDS: Long = 30

    /** Read timeout: long enough for a streaming SSE turn to complete. */
    const val READ_TIMEOUT_SECONDS: Long = 90

    /**
     * Create the SDK's OkHttp client with the connect/read timeouts the engine expects.
     *
     * @return A connection-pooled [OkHttpClient] configured for SSE turns and execute calls.
     */
    fun create(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .build()
}
