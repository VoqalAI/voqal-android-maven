package ai.voqal.sdk.experience

import ai.voqal.sdk.theme.ResolvedTheme
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameMillis
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** The faithful port of iOS `VoiceOrb`: 13 reactive wave bars over a soft accent glow. */
private const val BAR_COUNT = 13

/** Bar width as a fraction of [VoiceOrb] size (iOS `size * 0.05`). */
private const val BAR_WIDTH_FRACTION = 0.05f

/** Inter-bar spacing as a fraction of size (iOS `size * 0.028`). */
private const val BAR_SPACING_FRACTION = 0.028f

/** Bar-stack height as a fraction of size (iOS `size * 0.62`). */
private const val BAR_AREA_FRACTION = 0.62f

/** The orb's overall width is 1.25x its height (iOS `frame(width: size * 1.25, height: size)`). */
private const val ORB_WIDTH_FACTOR = 1.25f

/**
 * The living voice orb — a 1:1 port of iOS `VoiceOrb`. One visual language (the wave) and four
 * live states (idle, listening, transcribing/thinking, speaking), driven by a continuous frame
 * clock plus a simulated amplitude so motion never stalls. The real mic level replaces the
 * simulator while listening.
 *
 * @param phase The current interaction phase, selecting the animation regime.
 * @param theme Resolved colors; the bars use the [ResolvedTheme.accent]→[ResolvedTheme.accent2]
 *   gradient.
 * @param size The orb height. Width is [ORB_WIDTH_FACTOR] times this.
 * @param liveAmplitude Real mic level (`0f..1f`) used while listening; `0f` falls back to the
 *   simulator.
 * @param modifier Layout modifier for the orb.
 */
@Composable
fun VoiceOrb(
    phase: VoqalPhase,
    theme: ResolvedTheme,
    size: Dp,
    liveAmplitude: Float = 0f,
    modifier: Modifier = Modifier,
) {
    val elapsedMillis = rememberFrameClock()
    val active = phase == VoqalPhase.Listening || phase == VoqalPhase.Speaking
    val thinking = phase == VoqalPhase.Transcribing || phase == VoqalPhase.Thinking
    val amplitude = orbAmplitude(phase, elapsedMillis, liveAmplitude)
    val barGradient = remember(theme.accent, theme.accent2) {
        Brush.verticalGradient(listOf(theme.accent, theme.accent2))
    }

    Canvas(modifier = modifier.size(width = size * ORB_WIDTH_FACTOR, height = size)) {
        drawGlow(theme.accent, amplitude)
        drawWaveBars(barGradient, amplitude, active, thinking, elapsedMillis.toDouble())
    }
}

/** A monotonically increasing millisecond clock that ticks every animation frame. */
@Composable
private fun rememberFrameClock(): Long {
    var elapsedMillis by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        val startMillis = withFrameMillis { it }
        while (true) {
            withFrameMillis { frameMillis -> elapsedMillis = frameMillis - startMillis }
        }
    }
    return elapsedMillis
}

/**
 * Organic `0f..1f` energy: the real mic level while listening, else the simulated waveform
 * (a 1:1 port of the iOS `amplitude(at:)` formula). Resting (idle/thinking) returns `0f`.
 */
private fun orbAmplitude(phase: VoqalPhase, elapsedMillis: Long, liveAmplitude: Float): Float {
    if (phase == VoqalPhase.Listening && liveAmplitude > 0f) {
        return liveAmplitude.coerceIn(0f, 1f)
    }
    val active = phase == VoqalPhase.Listening || phase == VoqalPhase.Speaking
    if (!active) return 0f

    val t = elapsedMillis.toDouble()
    val base = 0.5 + 0.5 * sin(t / 220)
    val flick = 0.5 + 0.5 * sin(t / 70 + sin(t / 400) * 3)
    val energy = base * 0.55 + flick * 0.45 * (0.6 + 0.4 * sin(t / 130))
    return max(0.12, min(1.0, energy)).toFloat()
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGlow(accent: Color, amplitude: Float) {
    val glowAlpha = (0.18f + amplitude * 0.18f).coerceIn(0f, 1f)
    val glowWidth = size.width
    val glowHeight = size.height * 0.9f
    val radius = size.height * 0.6f
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(accent.copy(alpha = glowAlpha), Color.Transparent),
            center = Offset(size.width / 2f, size.height / 2f),
            radius = radius,
        ),
        topLeft = Offset((size.width - glowWidth) / 2f, (size.height - glowHeight) / 2f),
        size = Size(glowWidth, glowHeight),
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawWaveBars(
    barBrush: Brush,
    amplitude: Float,
    active: Boolean,
    thinking: Boolean,
    elapsedMillis: Double,
) {
    val orbSize = size.height
    val barWidth = orbSize * BAR_WIDTH_FRACTION
    val spacing = orbSize * BAR_SPACING_FRACTION
    val areaHeight = orbSize * BAR_AREA_FRACTION
    val totalWidth = BAR_COUNT * barWidth + (BAR_COUNT - 1) * spacing
    var x = (size.width - totalWidth) / 2f
    val centerY = size.height / 2f

    for (index in 0 until BAR_COUNT) {
        val barHeight = barFraction(index, amplitude, active, thinking, elapsedMillis) * areaHeight
        drawRoundRect(
            brush = barBrush,
            topLeft = Offset(x, centerY - barHeight / 2f),
            size = Size(barWidth, barHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2f),
        )
        x += barWidth + spacing
    }
}

/** The per-bar height fraction (`0f..1f`), a 1:1 port of the iOS `barHeight(_:)` formula. */
private fun barFraction(
    index: Int,
    amplitude: Float,
    active: Boolean,
    thinking: Boolean,
    elapsedMillis: Double,
): Float {
    val seed = 0.35 + 0.65 * abs(sin(index * 1.7))
    val center = 1.0 - abs(index - (BAR_COUNT - 1) / 2.0) / ((BAR_COUNT - 1) / 2.0)
    val height = when {
        active -> 0.16 + amplitude * (0.45 + 0.55 * center) * seed
        thinking -> 0.2 + 0.25 * abs(sin(elapsedMillis / 220 + index * 0.6))
        else -> 0.16 + 0.06 * sin(elapsedMillis / 600 + index)
    }
    return max(0.12, min(1.0, height)).toFloat()
}
