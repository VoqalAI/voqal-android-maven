package ai.voqal.sdk.experience

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/**
 * The shared type ramp and motion constants, ported 1:1 from the iOS `VoqalFont` enum and the
 * default SwiftUI spring used throughout the experience views.
 *
 * iOS uses SF Pro Display for voice copy and SF Mono for eyebrow labels/numerals. On Android the
 * platform default ([FontFamily.Default], ~Roboto) stands in for SF Pro Display and
 * [FontFamily.Monospace] for SF Mono — the closest system equivalents, matching the "use the
 * platform's native UI font" intent of the iOS `.system(design:)` calls.
 *
 * iOS `Font.Weight` maps to Compose [FontWeight] one-for-one. iOS `tracking` (absolute point
 * letter spacing) maps to Compose `letterSpacing` expressed in `sp`, since both are absolute and
 * 1pt ≈ 1sp at the text's own size.
 */
internal object VoqalType {

    val DISPLAY: FontFamily = FontFamily.Default
    val MONO: FontFamily = FontFamily.Monospace

    /** iOS `.semibold`. */
    val SEMIBOLD: FontWeight = FontWeight.SemiBold

    /** iOS `.medium`. */
    val MEDIUM: FontWeight = FontWeight.Medium

    /** iOS `.regular`. */
    val REGULAR: FontWeight = FontWeight.Normal

    /**
     * The default SwiftUI `withAnimation { }` spring used for the sheet's structural transitions
     * (scroll, content reveal). Translated per the project's calibration:
     * `spring(dampingRatio = 0.825, stiffness = StiffnessMediumLow)`.
     */
    fun <T> structuralSpring() = spring<T>(
        dampingRatio = 0.825f,
        stiffness = Spring.StiffnessMediumLow,
    )
}
