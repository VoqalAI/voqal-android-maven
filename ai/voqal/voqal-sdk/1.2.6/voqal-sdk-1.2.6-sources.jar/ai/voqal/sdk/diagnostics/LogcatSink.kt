package ai.voqal.sdk.diagnostics

import android.util.Log

/**
 * Default [VoqalLogSink] that writes to Android Logcat under the `Voqal` tag.
 *
 * Installed automatically by [ai.voqal.sdk.VoqalSDK.setup]. Events log at INFO, errors at
 * ERROR. Field maps are rendered compactly; callers are responsible for keeping secrets out.
 */
class LogcatSink(private val tag: String = DEFAULT_TAG) : VoqalLogSink {

    override fun event(name: String, fields: Map<String, Any?>) {
        Log.i(tag, format(name, fields))
    }

    override fun error(name: String, throwable: Throwable?, fields: Map<String, Any?>) {
        Log.e(tag, format(name, fields), throwable)
    }

    private fun format(name: String, fields: Map<String, Any?>): String =
        if (fields.isEmpty()) name else "$name ${fields.entries.joinToString(prefix = "{", postfix = "}")}"

    companion object {
        const val DEFAULT_TAG: String = "Voqal"
    }
}
