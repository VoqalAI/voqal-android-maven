package ai.voqal.sdk

import android.graphics.Bitmap

/**
 * Immutable configuration for the Voqal SDK, supplied once via [VoqalSDK.setup].
 *
 * Everything the SDK needs to talk to the engine and theme the experience lives here.
 * Tokens are intentionally NOT part of this object — they rotate frequently and are read
 * live from the [VoqalDelegate] on every request.
 *
 * @property requestId Environment-routing request id. The engine routes by prefix:
 *   `"prod-..."` to production MCP, `"stg-..."` to staging/alpha MCP. Required.
 * @property apiKey Publishable tenant key (`"pk_live_..."`). Resolves the tenant on the
 *   engine; when the engine enforces `require_api_key`, a missing/unknown key yields 401.
 * @property agentUrl Optional engine base URL override. Defaults to
 *   [VoqalEndpoint.DEFAULT_BASE_URL] (`https://api.voqal.ai/v2`) when null. Used by the
 *   demo to point at a local engine.
 * @property theme Visual theme (accent, appearance, corner radius).
 * @property home Home-glance configuration shown when the sheet first opens.
 * @property hapticsEnabled When false, all haptic feedback is suppressed.
 * @property conversationTimeoutSeconds Idle window after which the conversation is reset.
 *   Defaults to two hours (7200s).
 * @property headerIcon Optional brand logo rendered in the sheet header in place of the default
 *   Voqal orb. Null falls back to the bundled orb. A [Bitmap] keeps it host-flexible (load from
 *   any source — resource, asset, network).
 */
data class VoqalConfiguration(
    val requestId: String,
    val apiKey: String? = null,
    val agentUrl: String? = null,
    val theme: VoqalTheme = VoqalTheme(),
    val home: VoqalHome = VoqalHome(),
    val hapticsEnabled: Boolean = true,
    val conversationTimeoutSeconds: Long = DEFAULT_CONVERSATION_TIMEOUT_SECONDS,
    val headerIcon: Bitmap? = null,
) {
    init {
        require(requestId.isNotBlank()) { "VoqalConfiguration.requestId must not be blank" }
        require(conversationTimeoutSeconds > 0) {
            "VoqalConfiguration.conversationTimeoutSeconds must be positive, was $conversationTimeoutSeconds"
        }
    }

    companion object {
        const val DEFAULT_CONVERSATION_TIMEOUT_SECONDS: Long = 7200
    }
}

/**
 * Visual theming for the assistant sheet.
 *
 * @property accent Primary accent color as a hex string (e.g. `"#2d5bff"`). The voice orb,
 *   active states, and primary CTAs use it.
 * @property accent2 Optional secondary accent for gradients/highlights; falls back to [accent].
 * @property appearance Light, dark, or system-driven ([Appearance.AUTO]).
 * @property radius Corner radius in dp for cards and the sheet's top corners.
 */
data class VoqalTheme(
    val accent: String = DEFAULT_ACCENT,
    val accent2: String? = null,
    val appearance: Appearance = Appearance.AUTO,
    val radius: Float = DEFAULT_RADIUS_DP,
) {
    /** Requested color scheme. [AUTO] follows the system setting at present-time. */
    enum class Appearance { LIGHT, DARK, AUTO }

    companion object {
        const val DEFAULT_ACCENT: String = "#2d5bff"
        const val DEFAULT_RADIUS_DP: Float = 20f
    }
}

/**
 * Home-glance configuration: what the user sees the instant the sheet opens, before
 * they speak or type.
 *
 * @property userName Optional display name used in the greeting ("Hi, {userName}").
 * @property pinnedCTAs Quick-action prompts rendered as tappable chips on the home view.
 * @property showAgentGlance When true, the SDK requests a live snapshot from the agent on
 *   open so the home view shows current state (e.g. balance) rather than a static greeting.
 */
data class VoqalHome(
    val userName: String? = null,
    val pinnedCTAs: List<String> = emptyList(),
    val showAgentGlance: Boolean = true,
)
