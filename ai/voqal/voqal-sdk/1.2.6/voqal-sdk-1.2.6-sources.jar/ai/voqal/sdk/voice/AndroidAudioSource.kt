package ai.voqal.sdk.voice

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder

/**
 * The production [AudioSource]: a freshly allocated `AudioRecord` reading 16 kHz PCM16 mono
 * from the `VOICE_RECOGNITION` source.
 *
 * A new instance is created per clip by [WavRecorder]; it is never cached across a
 * background/foreground cycle, which can silently invalidate the audio session and yield
 * empty buffers (the same gotcha the iOS SDK hit).
 *
 * @throws SecurityException if `RECORD_AUDIO` has not been granted (thrown by `AudioRecord`).
 */
internal class AndroidAudioSource : AudioSource {

    private val bufferBytes: Int = resolveBufferBytes()

    private val record: AudioRecord = AudioRecord(
        MediaRecorder.AudioSource.VOICE_RECOGNITION,
        WavRecorder.SAMPLE_RATE_HZ,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT,
        bufferBytes,
    )

    override val isInitialized: Boolean
        get() = record.state == AudioRecord.STATE_INITIALIZED

    /** The read buffer size the recording loop should use, never below the OS minimum. */
    val readBufferBytes: Int = bufferBytes

    override fun startRecording() = record.startRecording()

    override fun read(buffer: ByteArray): Int = record.read(buffer, 0, buffer.size)

    override fun stop() {
        if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
            record.stop()
        }
    }

    override fun release() = record.release()

    private companion object {
        /** Floor for the capture buffer; the OS minimum is often smaller and starves reads. */
        const val MIN_BUFFER_FLOOR_BYTES = 4_096

        fun resolveBufferBytes(): Int {
            val osMinimum = AudioRecord.getMinBufferSize(
                WavRecorder.SAMPLE_RATE_HZ,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
            )
            if (osMinimum == AudioRecord.ERROR || osMinimum == AudioRecord.ERROR_BAD_VALUE) {
                return MIN_BUFFER_FLOOR_BYTES
            }
            return maxOf(osMinimum, MIN_BUFFER_FLOOR_BYTES)
        }
    }
}
