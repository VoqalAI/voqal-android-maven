package ai.voqal.sdk.experience

import ai.voqal.sdk.theme.ResolvedTheme
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Dock layout (ported 1:1 from iOS VoiceDock.swift / design sheet.jsx VqDock + VqTextBar).
private val DOCK_HORIZONTAL_PADDING = 22.dp
private val DOCK_TOP_PADDING = 8.dp
private val DOCK_BOTTOM_PADDING = 18.dp
private val DIVIDER_HEIGHT = 0.5.dp
private val ORB_ROW_HEIGHT = 104.dp

// Keyboard / mic-toggle circle.
private val KEYBOARD_CIRCLE_SIZE = 46.dp
private const val KEYBOARD_GLYPH_FRACTION = 0.46f
private val HAIRLINE_WIDTH = 0.5.dp

// Voice orb: the resting size and the larger size while listening/speaking.
private val ORB_SIZE_RESTING = 86.dp
private val ORB_SIZE_BIG = 106.dp
private const val ORB_SCALE_BIG = 1.05f
private const val ORB_SCALE_RESTING = 1f
private const val ORB_SCALE_HOLDING = 1.12f

// iOS fires the press haptic, then waits ~130ms before opening the mic so the buzz lands before
// the audio session activates. A release inside this window cancels the start (a too-quick tap
// never records). Ported from VoiceDock.swift's holdTask.
private const val HOLD_START_DELAY_MS = 130L

// Caption beneath the orb (iOS mono 10pt, tracking 1.3, uppercase).
private val CAPTION_SIZE = 10.sp
private val CAPTION_TRACKING = 1.3.sp
private val CAPTION_TOP_OFFSET = (-2).dp

// Text-input bar.
private val TEXT_BAR_SPACING = 10.dp
private val TEXT_MIC_CIRCLE_SIZE = 44.dp
private const val TEXT_MIC_GLYPH_FRACTION = 0.5f
private val INPUT_PILL_HEIGHT = 46.dp
private val INPUT_PILL_LEADING_PADDING = 16.dp
private val INPUT_PILL_TRAILING_PADDING = 6.dp
private val INPUT_FIELD_TO_SEND_SPACING = 8.dp
private val SEND_BUTTON_SIZE = 34.dp
private const val SEND_GLYPH_FRACTION = 0.5f
private const val SEND_DISABLED_OPACITY = 0.35f
private val INPUT_TEXT_SIZE = 16.sp

private const val TEXT_MIC_SHADOW_ALPHA = 0.5f
private val TEXT_MIC_SHADOW_RADIUS = 6.dp

/**
 * The bottom dock — a faithful port of the design's VqDock: a keyboard circle on the left, the
 * [VoiceOrb] centered, and the phase label below. The orb is **hold-to-speak**: press and hold to
 * record, release to send; the circle switches to a text-input bar with a send button.
 *
 * Voice mode is shown for every phase; tapping the keyboard circle flips to text mode, where a
 * gradient mic circle flips back. Holding the orb fires a press "touch" haptic immediately, opens
 * the mic after a short delay, and on release fires a second touch and sends — matching iOS
 * `VoiceDock`.
 *
 * @param phase The current interaction phase, selecting the orb regime and caption.
 * @param amplitude Live normalized mic level (`0f..1f`); drives the orb while listening.
 * @param theme Resolved colors for every dock layer.
 * @param onTouch Fire the press/release "touch" haptic (called on both press and release).
 * @param onStartVoice Begin a voice turn (mic permission ensured by the caller).
 * @param onStopVoice Stop the mic and send the captured clip.
 * @param onSend Send a typed message.
 * @param hasPriorExchanges Whether the conversation already has turns; selects the idle caption
 *   ("HOLD TO ASK AGAIN" vs "HOLD TO SPEAK"), mirroring iOS `stateLabel`.
 */
@Composable
fun VoqalDock(
    phase: VoqalPhase,
    amplitude: Float,
    theme: ResolvedTheme,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onSend: (String) -> Unit,
    onTouch: () -> Unit = {},
    hasPriorExchanges: Boolean = false,
) {
    var typing by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(theme.sheetBackground)
            .drawBehind {
                drawRect(
                    color = theme.hairline,
                    size = size.copy(height = DIVIDER_HEIGHT.toPx()),
                )
            }
            .padding(
                start = DOCK_HORIZONTAL_PADDING,
                end = DOCK_HORIZONTAL_PADDING,
                top = DOCK_TOP_PADDING,
                bottom = DOCK_BOTTOM_PADDING,
            ),
    ) {
        if (typing) {
            TextInputBar(
                theme = theme,
                onSwitchToVoice = { typing = false },
                onSend = onSend,
            )
        } else {
            VoiceRow(
                phase = phase,
                amplitude = amplitude,
                theme = theme,
                hasPriorExchanges = hasPriorExchanges,
                onSwitchToText = { typing = true },
                onTouch = onTouch,
                onStartVoice = onStartVoice,
                onStopVoice = onStopVoice,
            )
        }
    }
}

@Composable
private fun VoiceRow(
    phase: VoqalPhase,
    amplitude: Float,
    theme: ResolvedTheme,
    hasPriorExchanges: Boolean,
    onSwitchToText: () -> Unit,
    onTouch: () -> Unit,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
) {
    val big = phase == VoqalPhase.Listening || phase == VoqalPhase.Speaking
    val orbSize = if (big) ORB_SIZE_BIG else ORB_SIZE_RESTING
    var holding by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = when {
            holding -> ORB_SCALE_HOLDING
            big -> ORB_SCALE_BIG
            else -> ORB_SCALE_RESTING
        },
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "orbScale",
    )
    val scope = rememberCoroutineScope()
    // The hold gesture runs in a `pointerInput(Unit)` that captures its lambdas once; keep the
    // captured references pointing at the latest callbacks so a recomposed dock never fires a
    // stale seam.
    val latestTouch by rememberUpdatedState(onTouch)
    val latestStart by rememberUpdatedState(onStartVoice)
    val latestStop by rememberUpdatedState(onStopVoice)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(ORB_ROW_HEIGHT),
            contentAlignment = Alignment.Center,
        ) {
            KeyboardCircle(
                theme = theme,
                onTap = onSwitchToText,
                modifier = Modifier.align(Alignment.CenterStart),
            )
            VoiceOrb(
                phase = phase,
                theme = theme,
                size = orbSize,
                liveAmplitude = if (phase == VoqalPhase.Listening) amplitude else 0f,
                modifier = Modifier
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .semantics { contentDescription = orbActionLabel(phase) }
                    .holdToSpeak(
                        scope = scope,
                        onTouch = { latestTouch() },
                        onStartVoice = { latestStart() },
                        onStopVoice = { latestStop() },
                        onHoldingChange = { holding = it },
                    ),
            )
        }
        Text(
            text = captionFor(phase, hasPriorExchanges),
            color = theme.textTertiary,
            fontFamily = VoqalType.MONO,
            fontWeight = VoqalType.SEMIBOLD,
            fontSize = CAPTION_SIZE,
            letterSpacing = CAPTION_TRACKING,
            modifier = Modifier.offset(y = CAPTION_TOP_OFFSET),
        )
    }
}

/**
 * Press-and-hold to talk, ported 1:1 from iOS `VoiceDock`'s `DragGesture(minimumDistance: 0)`:
 *
 * - On the first pointer-down: fire the touch haptic immediately, then start the mic after
 *   [HOLD_START_DELAY_MS] (cancellable, so a too-quick release never records).
 * - The gesture tracks the pointer anywhere — even if it drifts OFF the small orb — and ends ONLY
 *   on a real pointer-up. (`detectTapGestures` would cancel the press on a bounds-exit and stop
 *   recording mid-utterance; `awaitEachGesture` + watching `pressed` does not.)
 * - On release: cancel a still-pending start, fire the touch haptic again, and stop+send. When
 *   the mic never opened, [onStopVoice] is a no-op (the experience guards a null recorder).
 *
 * @param scope The composition scope hosting the cancellable hold delay.
 */
private fun Modifier.holdToSpeak(
    scope: CoroutineScope,
    onTouch: () -> Unit,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onHoldingChange: (Boolean) -> Unit,
): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        onHoldingChange(true)
        onTouch()
        val startJob = scope.launch {
            delay(HOLD_START_DELAY_MS)
            onStartVoice()
        }
        // Keep the hold alive until every pointer lifts, regardless of where the finger moves.
        do {
            val event = awaitPointerEvent()
        } while (event.changes.any { it.pressed })
        startJob.cancel()
        onHoldingChange(false)
        onTouch()
        onStopVoice()
    }
}

@Composable
private fun KeyboardCircle(theme: ResolvedTheme, onTap: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(KEYBOARD_CIRCLE_SIZE)
            .clip(CircleShape)
            .background(theme.surface)
            .border(HAIRLINE_WIDTH, theme.hairline, CircleShape)
            .semantics { contentDescription = KEYBOARD_LABEL }
            .noRippleClickable(onClick = onTap),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(KEYBOARD_CIRCLE_SIZE * KEYBOARD_GLYPH_FRACTION)) {
            drawKeyboard(theme.textSecondary)
        }
    }
}

@Composable
private fun TextInputBar(
    theme: ResolvedTheme,
    onSwitchToVoice: () -> Unit,
    onSend: (String) -> Unit,
) {
    var draft by remember { mutableStateOf("") }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(TEXT_BAR_SPACING),
    ) {
        GradientMicCircle(theme = theme, onTap = onSwitchToVoice)
        InputPill(
            draft = draft,
            theme = theme,
            modifier = Modifier.weight(1f),
            onChange = { draft = it },
            onSend = {
                if (draft.isNotBlank()) {
                    onSend(draft)
                    draft = ""
                }
            },
        )
    }
}

@Composable
private fun GradientMicCircle(theme: ResolvedTheme, onTap: () -> Unit) {
    Box(
        modifier = Modifier
            .size(TEXT_MIC_CIRCLE_SIZE)
            .shadow(
                elevation = TEXT_MIC_SHADOW_RADIUS,
                shape = CircleShape,
                ambientColor = theme.accent.copy(alpha = TEXT_MIC_SHADOW_ALPHA),
                spotColor = theme.accent.copy(alpha = TEXT_MIC_SHADOW_ALPHA),
            )
            .clip(CircleShape)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.White, theme.accent, theme.accent2),
                        center = Offset(size.width * 0.38f, size.height * 0.34f),
                        radius = size.maxDimension,
                    ),
                )
            }
            .semantics { contentDescription = VOICE_MODE_LABEL }
            .noRippleClickable(onClick = onTap),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(TEXT_MIC_CIRCLE_SIZE * TEXT_MIC_GLYPH_FRACTION)) {
            drawMic(Color.White)
        }
    }
}

@Composable
private fun InputPill(
    draft: String,
    theme: ResolvedTheme,
    modifier: Modifier,
    onChange: (String) -> Unit,
    onSend: () -> Unit,
) {
    Row(
        modifier = modifier
            .height(INPUT_PILL_HEIGHT)
            .clip(CircleShape)
            .background(theme.surface)
            .border(HAIRLINE_WIDTH, theme.hairline, CircleShape)
            .padding(start = INPUT_PILL_LEADING_PADDING, end = INPUT_PILL_TRAILING_PADDING),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(INPUT_FIELD_TO_SEND_SPACING),
    ) {
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (draft.isEmpty()) {
                Text(
                    text = INPUT_PLACEHOLDER,
                    color = theme.textTertiary,
                    fontFamily = VoqalType.DISPLAY,
                    fontSize = INPUT_TEXT_SIZE,
                )
            }
            BasicTextField(
                value = draft,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(
                    color = theme.textPrimary,
                    fontFamily = VoqalType.DISPLAY,
                    fontSize = INPUT_TEXT_SIZE,
                ),
                cursorBrush = SolidColor(theme.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        SendButton(theme = theme, enabled = draft.isNotBlank(), onTap = onSend)
    }
}

@Composable
private fun SendButton(theme: ResolvedTheme, enabled: Boolean, onTap: () -> Unit) {
    Box(
        modifier = Modifier
            .size(SEND_BUTTON_SIZE)
            .graphicsLayer { alpha = if (enabled) 1f else SEND_DISABLED_OPACITY }
            .clip(CircleShape)
            .background(theme.textPrimary)
            .semantics { contentDescription = SEND_LABEL }
            .noRippleClickable(enabled = enabled, onClick = onTap),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(SEND_BUTTON_SIZE * SEND_GLYPH_FRACTION)) {
            drawArrowUp(theme.sheetBackground)
        }
    }
}

/** A clickable with no ripple, so the orb and circles stay visually pristine (matches iOS plain). */
@Composable
private fun Modifier.noRippleClickable(enabled: Boolean = true, onClick: () -> Unit): Modifier {
    val interactionSource = remember { MutableInteractionSource() }
    return clickable(
        interactionSource = interactionSource,
        indication = null,
        enabled = enabled,
        onClick = onClick,
    )
}

/** The orb's accessibility action label, ported from iOS `accessibilityLabel` ("Hold to talk"). */
private fun orbActionLabel(phase: VoqalPhase): String = ORB_TALK_LABEL

/**
 * The uppercase mono caption for [phase], ported from iOS `stateLabel`. Idle reads "HOLD TO SPEAK"
 * for a fresh conversation, or "HOLD TO ASK AGAIN" once there are prior exchanges.
 */
private fun captionFor(phase: VoqalPhase, hasPriorExchanges: Boolean): String = when (phase) {
    VoqalPhase.Listening -> LISTENING_LABEL
    VoqalPhase.Transcribing -> TRANSCRIBING_LABEL
    VoqalPhase.Thinking -> THINKING_LABEL
    VoqalPhase.Speaking -> SPEAKING_LABEL
    VoqalPhase.Idle -> if (hasPriorExchanges) HOLD_TO_ASK_AGAIN_LABEL else HOLD_TO_SPEAK_LABEL
}

// Captions are uppercased to match the iOS `.textCase(.uppercase)` mono eyebrow.
private const val LISTENING_LABEL = "LISTENING…"
private const val TRANSCRIBING_LABEL = "TRANSCRIBING…"
private const val THINKING_LABEL = "THINKING…"
private const val SPEAKING_LABEL = "SPEAKING…"
private const val HOLD_TO_SPEAK_LABEL = "HOLD TO SPEAK"
private const val HOLD_TO_ASK_AGAIN_LABEL = "HOLD TO ASK AGAIN"
private const val INPUT_PLACEHOLDER = "Message Voqal"

// Accessibility labels (ported from iOS accessibilityLabel/accessibilityIdentifier).
private const val ORB_TALK_LABEL = "Hold to talk"
private const val KEYBOARD_LABEL = "Type"
private const val VOICE_MODE_LABEL = "Voice"
private const val SEND_LABEL = "Send"
