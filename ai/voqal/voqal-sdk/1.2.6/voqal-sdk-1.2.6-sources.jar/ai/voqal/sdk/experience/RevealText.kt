package ai.voqal.sdk.experience

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/**
 * The present-tense answer, revealed word-by-word as it is "spoken" — a faithful port of iOS
 * `RevealText` and the `vqWord` keyframe.
 *
 * Per word: opacity 0→1, blur 4→0, translationY 3→0, eased with `easeOut` over 0.5s, staggered
 * 0.05s per word index. Each word's resting/base state is fully visible; the entrance animates
 * FROM hidden, so if the animation is skipped the text stays legible (matching the iOS "appeared"
 * gate). Words wrap like text with 4dp line spacing.
 *
 * The composable is keyed on [text] so a new answer remounts and re-reveals from the start.
 *
 * @param text The answer to reveal.
 * @param color The resolved primary text color.
 * @param fontSize The answer size (chosen by the caller from the answer's length).
 * @param fontWeight The answer weight.
 * @param rtl Whether to lay the words out right-to-left.
 * @param modifier Layout modifier from the caller.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun RevealText(
    text: String,
    color: Color,
    fontSize: TextUnit,
    fontWeight: FontWeight,
    rtl: Boolean,
    modifier: Modifier = Modifier,
) {
    key(text) {
        val words = remember(text) { splitWords(text) }
        FlowRow(
            modifier = modifier.fillMaxWidth(),
        ) {
            words.forEachIndexed { index, word ->
                RevealWord(
                    word = word,
                    index = index,
                    color = color,
                    fontSize = fontSize,
                    fontWeight = fontWeight,
                    rtl = rtl,
                )
            }
        }
    }
}

@Composable
private fun RevealWord(
    word: String,
    index: Int,
    color: Color,
    fontSize: TextUnit,
    fontWeight: FontWeight,
    rtl: Boolean,
) {
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        scope.launch {
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = REVEAL_DURATION_MILLIS,
                    delayMillis = (index * REVEAL_STAGGER_MILLIS),
                    easing = EaseOutCubic,
                ),
            )
        }
    }
    val p = progress.value
    androidx.compose.material3.Text(
        text = word,
        color = color,
        fontSize = fontSize,
        fontFamily = FontFamily.Default,
        fontWeight = fontWeight,
        style = TextStyle(
            textDirection = if (rtl) TextDirection.Rtl else TextDirection.Ltr,
        ),
        modifier = Modifier
            .graphicsLayer {
                alpha = p
                translationY = (1f - p) * REVEAL_TRANSLATION_PX
            }
            .blur(radius = REVEAL_BLUR_RADIUS * (1f - p)),
    )
}

/**
 * Split into words preserving a trailing space on every word but the last, so the FlowRow keeps
 * inter-word gaps while animating each word independently. Mirrors iOS's non-breaking-space join.
 */
private fun splitWords(text: String): List<String> {
    val parts = text.split(" ")
    return parts.mapIndexed { i, part -> if (i < parts.lastIndex) "$part " else part }
}

private const val REVEAL_DURATION_MILLIS = 500
private const val REVEAL_STAGGER_MILLIS = 50
private val REVEAL_TRANSLATION_PX = 3.dp.value
private val REVEAL_BLUR_RADIUS = 4.dp

private val EaseOutCubic = androidx.compose.animation.core.CubicBezierEasing(0.215f, 0.61f, 0.355f, 1f)
