package ai.voqal.sdk.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * The parsed render tail of one agent turn: a spoken answer plus the widgets to draw and
 * optional follow-up suggestions.
 *
 * The agent emits the spoken answer, then a `===render===` separator, then a JSON object
 * matching this shape. Splitting the raw stream is the transport layer's job; this type is
 * the decoded result.
 *
 * @property speak The spoken/displayed answer text.
 * @property widgets The widgets to render, in order. Unknown types decode to
 *   [Widget.Unknown] and are dropped by the renderer.
 * @property suggestions Optional follow-up prompt suggestions (chips).
 * @property follow Optional single follow-up line shown as a pill.
 */
@Serializable
data class RenderSpec(
    val speak: String = "",
    val widgets: List<Widget> = emptyList(),
    val suggestions: List<String> = emptyList(),
    val follow: String? = null,
) {
    companion object {
        /**
         * The canonical JSON codec for all render-spec types.
         *
         * - [Json.ignoreUnknownKeys]: tolerate new fields from a newer engine.
         * - [Json.coerceInputValues]: fall back to defaults for malformed scalars.
         * - A polymorphic default deserializer maps unknown `"type"` discriminators to
         *   [Widget.Unknown] instead of throwing.
         */
        val json: Json = Json {
            ignoreUnknownKeys = true
            coerceInputValues = true
            isLenient = true
            classDiscriminator = TYPE_DISCRIMINATOR
            serializersModule = kotlinx.serialization.modules.SerializersModule {
                polymorphicDefaultDeserializer(Widget::class) { Widget.Unknown.serializer() }
            }
        }

        /** The JSON key that selects the concrete [Widget] subtype. */
        const val TYPE_DISCRIMINATOR: String = "type"
    }
}
