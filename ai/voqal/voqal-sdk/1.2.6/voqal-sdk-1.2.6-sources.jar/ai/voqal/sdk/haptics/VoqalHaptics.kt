package ai.voqal.sdk.haptics

import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * Device-backed [VoqalHapticsPlaying] implementation using the platform [Vibrator].
 *
 * When [enabled] is false, every cue is a no-op — the host disables haptics via
 * [ai.voqal.sdk.VoqalConfiguration.hapticsEnabled]. Cue intensities are tuned per moment
 * (a short tick for recording edges, a sharper double for failures).
 *
 * Every vibration is wrapped in a `try/catch`: some devices report a vibrator but throw when
 * actually vibrating (OEM quirks, permission edge cases), and a haptic cue must never crash a
 * voice turn.
 *
 * minSdk is 28, so [VibrationEffect.createOneShot]/[VibrationEffect.createWaveform] are always
 * available; no legacy `vibrate(long)` path is needed.
 *
 * @param vibrator The platform vibrator, or null when the device has none.
 * @param enabled Whether haptics are active.
 */
class VoqalHaptics(
    private val vibrator: Vibrator?,
    private val enabled: Boolean = true,
) : VoqalHapticsPlaying {

    override fun touch() {
        // EFFECT_CLICK is the medium-impact system "touch" (matching iOS's medium impact) on API
        // 29+; createOneShot is the minSdk-28 fallback (createPredefined is API 29).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrateGuarded { VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK) }
        } else {
            oneShot(TOUCH_TICK_MS, TOUCH_AMPLITUDE)
        }
    }

    override fun recordingStarted() = oneShot(LIGHT_TICK_MS, LIGHT_AMPLITUDE)

    override fun recordingStopped() = oneShot(LIGHT_TICK_MS, LIGHT_AMPLITUDE)

    override fun transcriptArrived() = waveform(DOUBLE_TICK_TIMINGS, DOUBLE_TICK_AMPLITUDES)

    override fun actionNeeded() = oneShot(MEDIUM_PULSE_MS, MEDIUM_AMPLITUDE)

    override fun warning() = waveform(DOUBLE_BUZZ_TIMINGS, DOUBLE_BUZZ_AMPLITUDES)

    override fun failure() = oneShot(HEAVY_PULSE_MS, HEAVY_AMPLITUDE)

    private fun oneShot(durationMs: Long, amplitude: Int) {
        vibrateGuarded { VibrationEffect.createOneShot(durationMs, amplitude) }
    }

    private fun waveform(timings: LongArray, amplitudes: IntArray) {
        vibrateGuarded { VibrationEffect.createWaveform(timings, amplitudes, NO_REPEAT) }
    }

    private inline fun vibrateGuarded(effect: () -> VibrationEffect) {
        val device = vibrator ?: return
        if (!enabled || !device.hasVibrator()) return
        try {
            device.vibrate(effect())
        } catch (error: RuntimeException) {
            // OEM vibrators occasionally throw despite reporting hasVibrator(); a missed cue
            // must never surface to the user as a crash.
        }
    }

    companion object {
        private const val NO_REPEAT = -1

        // Medium-impact "touch" fallback for API 28 (no createPredefined): short and crisp.
        private const val TOUCH_TICK_MS = 18L
        private const val TOUCH_AMPLITUDE = 160

        private const val LIGHT_TICK_MS = 12L
        private const val LIGHT_AMPLITUDE = 70

        private const val MEDIUM_PULSE_MS = 28L
        private const val MEDIUM_AMPLITUDE = 150

        private const val HEAVY_PULSE_MS = 55L
        private const val HEAVY_AMPLITUDE = 255

        private val DOUBLE_TICK_TIMINGS = longArrayOf(0L, 12L, 60L, 12L)
        private val DOUBLE_TICK_AMPLITUDES = intArrayOf(0, 70, 0, 70)

        private val DOUBLE_BUZZ_TIMINGS = longArrayOf(0L, 40L, 80L, 40L)
        private val DOUBLE_BUZZ_AMPLITUDES = intArrayOf(0, 180, 0, 180)
    }
}
