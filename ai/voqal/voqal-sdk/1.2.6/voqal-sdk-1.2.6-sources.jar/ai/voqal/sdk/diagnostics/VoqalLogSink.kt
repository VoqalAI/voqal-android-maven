package ai.voqal.sdk.diagnostics

/**
 * A diagnostics output target. Implement this to forward Voqal events/errors to an
 * observability backend (Sentry, Datadog, etc.).
 *
 * Implementations must be non-blocking and must never throw — [VoqalLog] calls every sink
 * on the SDK's hot paths and swallows nothing on their behalf.
 *
 * Sinks must NOT log secrets: tokens, proofs, and PII are scrubbed by callers, but sinks
 * should also avoid persisting raw [fields] verbatim where that risk exists.
 */
interface VoqalLogSink {

    /**
     * Receive a structured event.
     *
     * @param name Stable event name in snake_case (e.g. `"turn_started"`).
     * @param fields Structured context (counts, durations, ids). Never secrets.
     */
    fun event(name: String, fields: Map<String, Any?>)

    /**
     * Receive an error.
     *
     * @param name Stable error name in snake_case (e.g. `"turn_failed"`).
     * @param throwable The error, if one is available.
     * @param fields Structured context to aid debugging.
     */
    fun error(name: String, throwable: Throwable?, fields: Map<String, Any?>)
}
