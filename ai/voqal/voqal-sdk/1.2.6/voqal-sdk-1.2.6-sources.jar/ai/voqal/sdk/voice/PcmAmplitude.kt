package ai.voqal.sdk.voice

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * Pure PCM16 amplitude math for the live waveform: the normalized peak of a buffer.
 *
 * Kept free of Android types so the recorder's UI-facing amplitude can be unit-tested by
 * feeding raw Int16 bytes through the [AudioSource] seam.
 */
internal object PcmAmplitude {

    /** Largest magnitude an Int16 sample can have; used to normalize the peak to `0..1`. */
    const val MAX_INT16_MAGNITUDE: Float = 32_768f

    /**
     * The peak absolute amplitude of the first [byteCount] bytes of [pcm], normalized to
     * `0..1`.
     *
     * @param pcm Little-endian PCM16 bytes.
     * @param byteCount Valid byte length within [pcm] (e.g. the bytes a read returned).
     * @return The normalized peak in `0f..1f`; `0f` for an empty/odd-only buffer.
     */
    fun normalizedPeak(pcm: ByteArray, byteCount: Int): Float {
        val usableBytes = byteCount.coerceIn(0, pcm.size)
        val sampleCount = usableBytes / Short.SIZE_BYTES
        if (sampleCount == 0) return 0f

        val samples = ByteBuffer.wrap(pcm, 0, sampleCount * Short.SIZE_BYTES)
            .order(ByteOrder.LITTLE_ENDIAN)
            .asShortBuffer()

        var peak = 0
        while (samples.hasRemaining()) {
            val magnitude = abs(samples.get().toInt())
            if (magnitude > peak) peak = magnitude
        }
        return (peak / MAX_INT16_MAGNITUDE).coerceIn(0f, 1f)
    }
}
