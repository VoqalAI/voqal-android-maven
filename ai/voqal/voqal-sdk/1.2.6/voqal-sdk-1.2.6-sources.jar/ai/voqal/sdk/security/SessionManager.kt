package ai.voqal.sdk.security

import ai.voqal.sdk.VoqalDelegate
import ai.voqal.sdk.transport.VoqalEndpoint
import ai.voqal.sdk.transport.VoqalHeaders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Owns the session lifecycle: bootstraps a session token from the engine, holds it, and
 * silently refreshes it on `401`.
 *
 * Bootstrap (`POST /api/v1/create-session`):
 * - Body: `{"public_key": <device JWK>, "metadata": <delegate metadata>}`.
 * - Headers: the standard contract (`X-Token`, `X-Request-ID`, `X-Voqal-Key`,
 *   `X-Client-Metadata`).
 * - Response: `201` with `{"session_token": "...", "session_id": "..."}`, the token bound to
 *   the device key (`cnf.jkt`).
 *
 * Refresh policy: when a request returns `401`, [silentRefresh] re-bootstraps once; the
 * caller then retries the original request exactly once. A second `401` is surfaced as an
 * error.
 *
 * Thread-safety: concurrent [ensureSession] callers share a single in-flight bootstrap (one
 * HTTP round-trip) via [bootstrapMutex].
 *
 * @param deviceKey Provides the public JWK and signing key for bootstrap.
 * @param delegate Supplies the live `X-Token` and metadata for bootstrap.
 * @param endpoint Resolves the create-session URL.
 * @param apiKey The publishable `pk_live_…` tenant key (`X-Voqal-Key`).
 * @param requestId The environment-routing request id (`X-Request-ID`).
 * @param httpClient The OkHttp client used for the bootstrap call.
 */
class SessionManager(
    private val deviceKey: DeviceKey,
    private val delegate: VoqalDelegate,
    private val endpoint: VoqalEndpoint = VoqalEndpoint(),
    private val apiKey: String = "",
    private val requestId: String = "",
    private val httpClient: OkHttpClient = OkHttpClient(),
) {

    @Volatile
    private var sessionToken: String? = null

    @Volatile
    private var sessionId: String? = null

    private val bootstrapMutex = Mutex()

    /**
     * The current session token, or null if no session has been established yet.
     *
     * @return The active session token, or null.
     */
    fun currentToken(): String? = sessionToken

    /**
     * The current session id, or null if no session has been established yet.
     *
     * @return The active session id, or null.
     */
    fun currentSessionId(): String? = sessionId

    /**
     * Ensure a valid session exists, bootstrapping one if necessary.
     *
     * Idempotent and safe to call concurrently: a single in-flight bootstrap is shared by
     * concurrent callers, so N concurrent callers trigger exactly one HTTP round-trip.
     *
     * @return The active session token.
     * @throws SessionBootstrapException if create-session fails or returns no token.
     */
    suspend fun ensureSession(): String {
        currentToken()?.let { return it }
        return bootstrapMutex.withLock {
            currentToken() ?: bootstrap()
        }
    }

    /**
     * Force a fresh session after a `401`. Discards the current token and re-bootstraps.
     *
     * @return The newly minted session token.
     * @throws SessionBootstrapException if create-session fails or returns no token.
     */
    suspend fun silentRefresh(): String {
        invalidate()
        return ensureSession()
    }

    /** Clear the cached session so the next [ensureSession] re-bootstraps. */
    fun invalidate() {
        sessionToken = null
        sessionId = null
    }

    private suspend fun bootstrap(): String = withContext(Dispatchers.IO) {
        val request = buildBootstrapRequest()
        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw SessionBootstrapException(
                    "create-session failed with HTTP ${response.code}"
                )
            }
            val payload = response.body?.string()
                ?: throw SessionBootstrapException("create-session returned an empty body")
            cacheFrom(payload)
        }
    }

    private fun cacheFrom(payload: String): String {
        val parsed = SecurityJson.instance.decodeFromString(CreateSessionResponse.serializer(), payload)
        val token = parsed.sessionToken
            ?: throw SessionBootstrapException("create-session response missing session_token")
        sessionToken = token
        sessionId = parsed.sessionId
        return token
    }

    private fun buildBootstrapRequest(): Request {
        // Read the rotating metadata once so the header and body stay consistent.
        val metadata = delegate.getMetadata()
        val builder = Request.Builder()
            .url(endpoint.createSession())
            .post(bootstrapBody(metadata).toRequestBody(JSON_MEDIA_TYPE))
            .header(CONTENT_TYPE_HEADER, JSON_CONTENT_TYPE)
            .header(VoqalHeaders.TOKEN, delegate.getToken())
            .header(VoqalHeaders.VOQAL_KEY, apiKey)
            .header(VoqalHeaders.REQUEST_ID, requestId)
        metadata?.let { builder.header(VoqalHeaders.CLIENT_METADATA, it) }
        return builder.build()
    }

    private fun bootstrapBody(metadata: String?): String {
        val publicJwk = JsonObject(deviceKey.publicJwk().mapValues { JsonPrimitive(it.value) })
        val body = buildJsonObject {
            put("public_key", publicJwk)
            put("metadata", parseMetadata(metadata))
        }
        return SecurityJson.instance.encodeToString(JsonObject.serializer(), body)
    }

    private fun parseMetadata(metadata: String?): JsonObject {
        if (metadata.isNullOrBlank()) return JsonObject(emptyMap())
        return runCatching {
            SecurityJson.instance.decodeFromString(JsonObject.serializer(), metadata)
        }.getOrElse { JsonObject(emptyMap()) }
    }

    companion object {
        /** Max session re-bootstrap retries per failing request (single silent retry). */
        const val MAX_REFRESH_RETRIES: Int = 1

        private const val CONTENT_TYPE_HEADER = "Content-Type"
        private const val JSON_CONTENT_TYPE = "application/json"
        private val JSON_MEDIA_TYPE = JSON_CONTENT_TYPE.toMediaType()
    }
}

/** Raised when `create-session` returns a non-2xx status or an unusable body. */
class SessionBootstrapException(message: String) : Exception(message)

@Serializable
private data class CreateSessionResponse(
    @SerialName("session_token") val sessionToken: String? = null,
    @SerialName("session_id") val sessionId: String? = null,
)
