package ai.voqal.sdk.security

import java.security.PrivateKey
import java.security.PublicKey

/**
 * A device-bound EC P-256 key pair held in the Android Keystore, used for
 * proof-of-possession signing.
 *
 * The private key is non-exportable (hardware-backed where available); only its handle and
 * the public key leave the keystore. The public key is published once during session
 * bootstrap as a JWK and bound into the session token's `cnf.jkt`.
 *
 * Implementations must:
 * - Lazily create the key under a stable alias if absent, else load the existing one.
 * - Expose the public key as a JWK for [SessionManager] bootstrap.
 * - Sign digests via [ProofSigner] without ever exposing private key bytes.
 */
interface DeviceKey {

    /**
     * The non-exportable private key handle used for ES256 signing.
     *
     * @return The keystore-backed private key.
     */
    fun privateKey(): PrivateKey

    /**
     * The corresponding public key.
     *
     * @return The EC P-256 public key.
     */
    fun publicKey(): PublicKey

    /**
     * The public key as a JWK map for the `create-session` bootstrap body and proof header.
     *
     * Coordinates are the raw 32-byte big-endian field elements, base64url without padding.
     *
     * @return An ordered map `{"kty":"EC","crv":"P-256","x":"<b64url>","y":"<b64url>"}`.
     */
    fun publicJwk(): Map<String, String>

    /**
     * The public key encoded as a JWK JSON object string for the bootstrap body.
     *
     * @return A JWK string of the form
     *   `{"kty":"EC","crv":"P-256","x":"<b64url>","y":"<b64url>"}`.
     */
    fun publicKeyJwk(): String

    /**
     * The JWK SHA-256 thumbprint (RFC 7638), base64url-encoded. Matches the session token's
     * `cnf.jkt`.
     *
     * @return The base64url thumbprint string.
     */
    fun thumbprint(): String

    companion object {
        /** Stable Keystore alias for the device key. */
        const val KEY_ALIAS: String = "ai.voqal.sdk.device-key"

        /** Curve used for the device key. */
        const val CURVE: String = "secp256r1"
    }
}
