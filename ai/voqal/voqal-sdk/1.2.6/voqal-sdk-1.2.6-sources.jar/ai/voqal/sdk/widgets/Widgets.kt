package ai.voqal.sdk.widgets

import ai.voqal.sdk.model.ListRow
import ai.voqal.sdk.model.Trend
import ai.voqal.sdk.model.Widget
import ai.voqal.sdk.theme.ResolvedTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.json.JsonObject

/**
 * Renders a single [Widget] by dispatching to its type-specific Composable. Unknown widgets
 * ([Widget.Unknown]) render nothing — the renderer must never crash on a type it doesn't know.
 *
 * @param widget The widget to render.
 * @param theme The resolved theme for colors/shape.
 * @param onConfirm Invoked when a [Widget.Confirm] CTA is tapped, with its opaque execute
 *   payload. Null disables confirmation (the CTA still renders but does nothing).
 * @param onAddToCart Invoked with `(productId, quantity)` when a [Widget.Products] "Add" button
 *   is tapped. Null leaves product buttons inert.
 */
@Composable
fun WidgetView(
    widget: Widget,
    theme: ResolvedTheme,
    onConfirm: ((JsonObject) -> Unit)? = null,
    onAddToCart: ((String, Int) -> Unit)? = null,
) {
    when (widget) {
        is Widget.Stat -> StatWidget(widget, theme)
        is Widget.ListWidget -> ListWidgetView(widget, theme)
        is Widget.Card -> CardWidget(widget, theme)
        is Widget.Progress -> ProgressWidget(widget, theme)
        is Widget.Chart -> ChartWidget(widget, theme)
        is Widget.Markdown -> MarkdownWidget(widget, theme)
        is Widget.Confirm -> ConfirmWidget(widget, theme, onConfirm)
        is Widget.Products -> ProductsWidget(widget, theme, onAddToCart)
        Widget.Unknown -> Unit
    }
}

/**
 * Renders a [Widget.Stat]: a mono eyebrow label over a large monospaced value (the hero number),
 * with an optional trend-tinted delta below.
 */
@Composable
fun StatWidget(widget: Widget.Stat, theme: ResolvedTheme) {
    WidgetSurface(theme, theme.surface) {
        Column(Modifier.padding(WidgetTokens.CARD_PADDING)) {
            Eyebrow(widget.label, theme)
            Spacer(Modifier.height(6.dp))
            DirectionalText(
                text = widget.value,
                color = theme.textPrimary,
                fontSize = WidgetTokens.STAT_VALUE_SIZE,
                fontWeight = FontWeight.Bold,
                letterSpacing = WidgetTokens.STAT_VALUE_TRACKING,
                mono = true,
            )
            widget.delta?.let { delta ->
                Spacer(Modifier.height(4.dp))
                DirectionalText(
                    text = delta,
                    color = trendColor(widget.trend, theme),
                    fontSize = WidgetTokens.DELTA_SIZE,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
    }
}

/** Up/down trends get a theme-aware tint; flat/unknown stays quiet at the secondary tier. */
private fun trendColor(trend: Trend?, theme: ResolvedTheme): Color = when (trend) {
    Trend.UP -> if (theme.isDark) UP_DARK else UP_LIGHT
    Trend.DOWN -> if (theme.isDark) DOWN_DARK else DOWN_LIGHT
    Trend.FLAT, null -> theme.textSecondary
}

private val UP_DARK = Color(0xFF34D399)
private val UP_LIGHT = Color(0xFF0A9E6E)
private val DOWN_DARK = Color(0xFFFF6B6B)
private val DOWN_LIGHT = Color(0xFFDB2626)

/** Renders a [Widget.ListWidget]: an optional eyebrow title over up to six hairline-split rows. */
@Composable
fun ListWidgetView(widget: Widget.ListWidget, theme: ResolvedTheme) {
    val rows = widget.rows.take(WidgetTokens.MAX_LIST_ROWS)
    WidgetSurface(theme, theme.surface) {
        Column(Modifier.padding(WidgetTokens.CARD_PADDING)) {
            widget.title?.let { title ->
                Eyebrow(title, theme, Modifier.padding(bottom = 10.dp))
            }
            rows.forEachIndexed { index, row ->
                if (index > 0) Hairline(theme)
                ListRowView(row, theme)
            }
        }
    }
}

@Composable
private fun ListRowView(row: ListRow, theme: ResolvedTheme) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            DirectionalText(
                text = row.title,
                color = theme.textPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
            )
            row.meta?.let { meta ->
                DirectionalText(
                    text = meta,
                    color = theme.textTertiary,
                    fontSize = 10.5.sp,
                    mono = true,
                )
            }
        }
        row.trailing?.let { trailing ->
            Spacer(Modifier.width(12.dp))
            DirectionalText(
                text = trailing,
                color = theme.textPrimary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Medium,
                mono = true,
            )
        }
    }
}

/** Renders a [Widget.Card]: a title over label/value rows with an optional footer caption. */
@Composable
fun CardWidget(widget: Widget.Card, theme: ResolvedTheme) {
    WidgetSurface(theme, theme.surface) {
        Column(
            modifier = Modifier.padding(WidgetTokens.CARD_PADDING),
            verticalArrangement = Arrangement.spacedBy(WidgetTokens.ROW_SPACING),
        ) {
            DirectionalText(
                text = widget.title,
                color = theme.textPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
            )
            widget.rows.forEach { pair -> KeyValueRow(pair, theme, valueMono = true) }
            widget.footer?.let { footer ->
                DirectionalText(
                    text = footer,
                    color = theme.textTertiary,
                    fontSize = WidgetTokens.FOOTER_SIZE,
                )
            }
        }
    }
}

/**
 * A label/value row: secondary-tinted label on the leading edge, primary value on the trailing.
 *
 * @param pair A `[label, value]` pair; entries beyond two are ignored, missing ones blank.
 * @param valueMono Render the value with monospaced digits (true for cards' numeric values).
 */
@Composable
internal fun KeyValueRow(pair: List<String>, theme: ResolvedTheme, valueMono: Boolean = false) {
    val label = pair.getOrElse(0) { "" }
    val value = pair.getOrElse(1) { "" }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        DirectionalText(
            text = label,
            color = theme.textSecondary,
            fontSize = WidgetTokens.ROW_LABEL_SIZE,
            modifier = Modifier.weight(1f),
        )
        Spacer(Modifier.width(12.dp))
        DirectionalText(
            text = value,
            color = theme.textPrimary,
            fontSize = WidgetTokens.ROW_LABEL_SIZE,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End,
            mono = valueMono,
        )
    }
}

/** Renders a [Widget.Progress]: title with trailing ETA, an accent bar, and eyebrow step labels. */
@Composable
fun ProgressWidget(widget: Widget.Progress, theme: ResolvedTheme) {
    WidgetSurface(theme, theme.surface) {
        Column(
            modifier = Modifier.padding(WidgetTokens.CARD_PADDING),
            verticalArrangement = Arrangement.spacedBy(13.dp),
        ) {
            ProgressHeader(widget.title, widget.eta, theme)
            VoqalBar(widget.value, theme)
            StepLabels(widget.steps, widget.stepActive, theme)
        }
    }
}

@Composable
private fun ProgressHeader(title: String, eta: String?, theme: ResolvedTheme) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        DirectionalText(
            text = title,
            color = theme.textPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
        )
        eta?.let {
            DirectionalText(
                text = it,
                color = theme.textPrimary,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.SemiBold,
                mono = true,
            )
        }
    }
}

@Composable
private fun StepLabels(steps: List<String>, stepActive: Int?, theme: ResolvedTheme) {
    if (steps.isEmpty()) return
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        steps.forEachIndexed { index, step ->
            val isActive = index == (stepActive ?: 1)
            Eyebrow(step, theme, color = if (isActive) theme.accent else theme.textTertiary)
        }
    }
}

/**
 * Renders a [Widget.Confirm]: an opaque card of details, an optional emphasized total, and a
 * full-width high-contrast CTA. Never shows biometric iconography; the CTA forwards
 * [Widget.Confirm.execute] to [onConfirm].
 */
@Composable
fun ConfirmWidget(
    widget: Widget.Confirm,
    theme: ResolvedTheme,
    onConfirm: ((JsonObject) -> Unit)?,
) {
    ConfirmSurface(theme) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            DirectionalText(
                text = widget.title,
                color = theme.textPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
            )
            widget.rows.forEach { pair -> KeyValueRow(pair, theme) }
            widget.price?.let { price -> TotalRow(price, theme) }
            ConfirmButton(widget, theme, onConfirm)
        }
    }
}

@Composable
private fun TotalRow(price: String, theme: ResolvedTheme) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Eyebrow("Total", theme, Modifier.weight(1f), color = theme.textTertiary)
        DirectionalText(
            text = price,
            color = theme.textPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            mono = true,
        )
    }
}
