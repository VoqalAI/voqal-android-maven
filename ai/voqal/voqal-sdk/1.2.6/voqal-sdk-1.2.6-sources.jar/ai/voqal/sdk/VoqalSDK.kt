package ai.voqal.sdk

import ai.voqal.sdk.diagnostics.LogcatSink
import ai.voqal.sdk.diagnostics.VoqalLog
import ai.voqal.sdk.diagnostics.VoqalLogSink
import ai.voqal.sdk.experience.VoqalSessionHolder
import ai.voqal.sdk.experience.VoqalSheetActivity
import android.content.Intent
import androidx.activity.ComponentActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * The Voqal SDK entry point.
 *
 * Lifecycle:
 * 1. [setup] once at app launch with a [VoqalConfiguration].
 * 2. [prewarm] (optional but recommended) to open the session and warm the engine so the
 *    first real turn is fast.
 * 3. [present] to show the full-screen assistant sheet.
 *
 * Thread-safety: [setup]/[addLogSink] are expected to be called from the main thread during
 * app startup. [prewarm]/[present] are safe to call from the main thread; network work is
 * dispatched off the main thread internally.
 */
object VoqalSDK {

    @Volatile
    private var configuration: VoqalConfiguration? = null

    private val log = VoqalLog

    private val prewarmScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    /**
     * Configure the SDK. Must be called before [prewarm] or [present].
     *
     * Installs the default [LogcatSink] on first call so diagnostics are visible out of the
     * box; hosts can add their own sinks via [addLogSink].
     *
     * @param configuration The immutable SDK configuration.
     */
    fun setup(configuration: VoqalConfiguration) {
        this.configuration = configuration
        log.addSink(LogcatSink())
        log.event("sdk_setup", mapOf("hasApiKey" to (configuration.apiKey != null)))
    }

    /**
     * Open the session and warm the engine ahead of time. Fire-and-forget.
     *
     * Bootstraps the session (device key + proof + `create-session`) and triggers the
     * engine's background MCP warm + prompt-cache prime, so the first user turn avoids the
     * cold-start penalty. Errors are surfaced via [VoqalDelegate.onError] but never thrown.
     *
     * @param delegate Supplies the live token/metadata for the session bootstrap.
     * @throws IllegalStateException if [setup] has not been called.
     */
    fun prewarm(delegate: VoqalDelegate) {
        val config = requireConfigured()
        log.event("sdk_prewarm")
        val session = VoqalSessionHolder.ensure(config, delegate)
        prewarmScope.launch {
            try {
                session.prewarm()
            } catch (error: Exception) {
                log.error("sdk_prewarm_failed", error)
                delegate.onError(error)
            }
        }
    }

    /**
     * Present the full-screen themed assistant sheet over [activity].
     *
     * The SDK owns all chrome (scrim, rounded-top card, drag-to-dismiss). The host only
     * provides the launching activity and the [delegate] for live credentials and callbacks.
     *
     * @param activity The activity to present over. Must be a [ComponentActivity] so the SDK
     *   can host its own lifecycle-aware UI and ViewModel.
     * @param delegate Supplies live token/metadata and receives result/error callbacks.
     * @throws IllegalStateException if [setup] has not been called.
     */
    fun present(activity: ComponentActivity, delegate: VoqalDelegate) {
        val config = requireConfigured()
        log.event("sdk_present")
        VoqalSessionHolder.ensure(config, delegate)
        activity.startActivity(
            Intent(activity, VoqalSheetActivity::class.java)
                .putExtra(VoqalSheetActivity.EXTRA_REQUEST_ID, config.requestId),
        )
        activity.overridePendingTransition(0, 0)
    }

    /**
     * Register an additional diagnostics sink (e.g. a Sentry bridge).
     *
     * @param sink The sink to receive every subsequent [VoqalLog] event and error.
     */
    fun addLogSink(sink: VoqalLogSink) {
        log.addSink(sink)
    }

    /** Returns the active configuration or throws if [setup] was never called. */
    private fun requireConfigured(): VoqalConfiguration =
        configuration ?: throw IllegalStateException(
            "VoqalSDK.setup(configuration) must be called before using the SDK",
        )
}
